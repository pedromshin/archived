//
//  PropsiteSwiftApp.swift
//  PropsiteSwift
//
//  Created by Pedro Shin on 24/03/24.
//

import SwiftUI

@main
struct PropsiteSwiftApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
