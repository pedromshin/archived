const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export const structuredData = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "venda.",
  url: siteUrl, // Use the variable consistently
  description:
    "venda. is a social marketplace on a mission to reduce waste and raise income by enabling people to offer unused goods to friends and family.",
  potentialAction: {
    "@type": "SearchAction",
    target: `${siteUrl}/search?q={search_term_string}`, // Ensure consistency
    "query-input": "required name=search_term_string",
  },
};

export const siteConfig = {
  name: "venda.",
  url: process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000",
  description:
    "venda. is a social marketplace on a mission to reduce waste and raise income by enabling people to offer unused goods to friends and family.",
};

export type SiteConfig = typeof siteConfig;
