export default function HowItWorks() {
  return (
    <section className="mx-auto mb-16 max-w-7xl px-4 md:mt-24 md:px-8">
      <h2 className="mb-8 text-center text-4xl font-semibold">how it works</h2>
      <div className="flex flex-col items-center justify-around gap-4 lg:flex-row">
        <div className="mb-8 flex-1 text-center lg:mb-0 lg:text-left">
          <h3 className="mb-2 text-2xl font-semibold">
            1.{" "}
            <span className="text-primary">
              connect with friends and family
            </span>
          </h3>
          <p className="text-lg text-muted-foreground">
            add people you trust to your network.
          </p>
        </div>
        <div className="mb-8 flex-1 text-center lg:mb-0 lg:text-left">
          <h3 className="mb-2 text-2xl font-semibold">
            2. <span className="text-primary">post your items for sale </span>
          </h3>
          <p className="text-lg text-muted-foreground">
            receive offers from people interested in your items.
          </p>
        </div>
        <div className="flex-1 text-center lg:text-left">
          <h3 className="mb-2 text-2xl font-semibold">
            3. <span className="text-primary">receive offers</span>
          </h3>
          <p className="text-lg text-muted-foreground">
            accept or refuse offers, earn money, reduce trash.
          </p>
        </div>
      </div>
    </section>
  );
}
