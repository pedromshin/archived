import { AuthShowcase } from "~/app/_components/auth-showcase";
import { structuredData } from "~/config/site";
import { HydrateClient } from "~/trpc/server";
import { About } from "./components/About";
import ConnectWithFriends from "./components/connect-with-friends";
import { Cta } from "./components/Cta";
import { FAQ } from "./components/FAQ";
import { Features } from "./components/Features";
import { Footer } from "./components/Footer";
import HowItWorks from "./components/how-it-works";
import { HowItWorks as HowItWorks2 } from "./components/HowItWorks";
import { Pricing } from "./components/Pricing";
import { Services } from "./components/Services";
import { Sponsors } from "./components/Sponsors";
import { Team } from "./components/Team";
import { Testimonials } from "./components/Testimonials";

export default async function LandingPage() {
  return (
    <HydrateClient>
      <main>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
        />
        <AuthShowcase />
        <ConnectWithFriends />
        <HowItWorks />
        {/* <Sponsors /> */}
        <About />
        <HowItWorks2 />
        <Features />
        <Services />
        <Cta />
        <Testimonials />
        <Team />
        <Pricing />
        <FAQ />
        <Footer />
      </main>
    </HydrateClient>
  );
}
