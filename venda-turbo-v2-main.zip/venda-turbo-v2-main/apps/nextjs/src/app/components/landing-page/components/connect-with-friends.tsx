import Link from "next/link";

import { Button } from "@venda/ui/button";

export default function ConnectWithFriends() {
  return (
    <section className="max-w-8xl mx-auto mb-16 mt-8 px-4 md:mt-24 md:px-8">
      <div className="mx-auto max-w-5xl text-center text-5xl font-semibold sm:text-5xl lg:text-7xl">
        <h1>connect with friends</h1>
        <h1 className="text-primary">
          <span className="text-foreground">+</span> earn money{" "}
        </h1>
        <h1 className="text-primary">
          <span className="text-foreground">+</span> reduce trash
        </h1>
        <p className="mx-auto mt-8 w-[90%] text-lg font-normal text-muted-foreground lg:text-2xl">
          <span className="text-primary">venda</span>. is a{" "}
          <span className="text-primary">social marketplace</span> on a mission
          to <span className="text-primary">reduce waste</span> and{" "}
          <span className="text-primary">raise income</span> by enabling people
          to offer unused goods to friends and family.
        </p>
      </div>
      <div className="mt-16 text-center">
        <Link href={"/search"}>
          <Button className="p-6 text-xl">get started!</Button>
        </Link>
      </div>
    </section>
  );
}
