import baseConfig, { restrictEnvAccess } from "@venda/eslint-config/base";
import nextjsConfig from "@venda/eslint-config/nextjs";
import reactConfig from "@venda/eslint-config/react";

/** @type {import('typescript-eslint').Config} */
export default [
  {
    ignores: [".next/**"],
  },
  ...baseConfig,
  ...reactConfig,
  ...nextjsConfig,
  ...restrictEnvAccess,
];
