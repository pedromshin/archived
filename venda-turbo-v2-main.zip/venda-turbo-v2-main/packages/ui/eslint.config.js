import baseConfig from "@venda/eslint-config/base";
import reactConfig from "@venda/eslint-config/react";

/** @type {import('typescript-eslint').Config} */
export default [
  {
    ignores: ["dist/**"],
  },
  ...baseConfig,
  ...reactConfig,
];
