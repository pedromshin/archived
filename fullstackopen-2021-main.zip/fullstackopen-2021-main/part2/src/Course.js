import React from 'react'

const Course = (props) => {
  return(
    <div>
      {props.content}
    </div>
  )
}

export default Course