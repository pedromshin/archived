Solutions of part 1 exercises to this folder, one app per folder

eg. the project unicafe for exercises 1.6.-1.11 as folder unicafe