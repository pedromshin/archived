Exercises for the course on https://fullstackopen.com/en

Learning basic Git alongside with course, so there are some mistakes in commits and branches.

Part_0 was submitted to branch Master, while Part1 was commited to branch Main. As of when I am writing this, these are the only parts I have completed.
Will figure out how to put both parts on the same branch.
