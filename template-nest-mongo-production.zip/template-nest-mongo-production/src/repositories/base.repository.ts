import {
  Body,
  Delete,
  Get,
  HttpException,
  HttpStatus,
  Param,
  Patch,
  Post,
  Query,
  Controller,
} from '@nestjs/common';
import { Model, FilterQuery, QueryOptions, UpdateQuery } from 'mongoose';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiQuery,
  ApiParam,
  ApiBody,
} from '@nestjs/swagger';

@Controller('base')
@ApiTags('base')
export class BaseRepository<T> {
  constructor(private readonly model: Model<T>) {}

  @Post()
  @ApiOperation({ summary: 'Create a new document' })
  @ApiBody({ type: Object, description: 'Document to create' })
  @ApiResponse({ status: 201, description: 'Document successfully created.' })
  @ApiResponse({ status: 400, description: 'Bad request.' })
  async create(@Body() createDto: Partial<T>): Promise<T> {
    try {
      return await this.model.create(createDto);
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  @Get()
  @ApiOperation({ summary: 'Find all documents' })
  @ApiQuery({
    name: 'filter',
    required: false,
    description: 'Filter query in JSON format',
    type: String,
  })
  @ApiQuery({
    name: 'options',
    required: false,
    description: 'Options query in JSON format',
    type: String,
  })
  @ApiResponse({ status: 200, description: 'List of documents' })
  @ApiResponse({ status: 400, description: 'Bad request.' })
  async findAll(
    @Query('filter') filterQuery: string = '{}',
    @Query('options') optionsQuery: string = '{}',
  ): Promise<T[]> {
    try {
      const filter: FilterQuery<T> = JSON.parse(filterQuery);
      const options: QueryOptions = JSON.parse(optionsQuery);

      return await this.model.find(filter, null, options).exec();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  @Get(':_id')
  @ApiOperation({ summary: 'Find a document by ID' })
  @ApiParam({
    name: '_id',
    type: String,
    description: 'ID of the document to retrieve',
  })
  @ApiQuery({
    name: 'options',
    required: false,
    description: 'Options query in JSON format',
    type: String,
  })
  @ApiResponse({ status: 200, description: 'Document found' })
  @ApiResponse({ status: 404, description: 'Document not found.' })
  @ApiResponse({ status: 400, description: 'Bad request.' })
  async findById(
    @Param('_id') _id: string,
    @Query('options') optionsQuery: string = '{}',
  ) {
    try {
      const options: QueryOptions = JSON.parse(optionsQuery);
      return await this.model.findById(_id, null, options).exec();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  @Patch(':_id')
  @ApiOperation({ summary: 'Update a document by ID' })
  @ApiParam({
    name: '_id',
    type: String,
    description: 'ID of the document to update',
  })
  @ApiBody({ type: Object, description: 'Document fields to update' })
  @ApiQuery({
    name: 'options',
    required: false,
    description: 'Options query in JSON format',
    type: String,
  })
  @ApiResponse({ status: 200, description: 'Document successfully updated' })
  @ApiResponse({ status: 404, description: 'Document not found.' })
  @ApiResponse({ status: 400, description: 'Bad request.' })
  async update(
    @Param('_id') _id: string = '',
    @Body() updateDto: UpdateQuery<T>,
    @Query('options') optionsQuery: string = '{}',
  ) {
    try {
      const options: QueryOptions = JSON.parse(optionsQuery);
      const result = await this.model
        .findByIdAndUpdate(_id, updateDto, {
          new: true,
          ...options,
        })
        .exec();
      if (!result) {
        throw new HttpException('Document not found', HttpStatus.NOT_FOUND);
      }
      return result;
    } catch (error) {
      throw new HttpException(
        {
          status: HttpStatus.BAD_REQUEST,
          error: 'Error updating document',
        },
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  @Delete(':_id')
  @ApiOperation({ summary: 'Delete a document by ID' })
  @ApiParam({
    name: '_id',
    type: String,
    description: 'ID of the document to delete',
  })
  @ApiResponse({ status: 200, description: 'Document successfully deleted' })
  @ApiResponse({ status: 404, description: 'Document not found.' })
  @ApiResponse({ status: 400, description: 'Bad request.' })
  async delete(@Param('_id') _id: string) {
    try {
      return await this.model.deleteOne({ _id }).exec();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }
}
