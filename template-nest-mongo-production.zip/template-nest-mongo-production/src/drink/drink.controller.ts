import { Controller } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Drink } from './drink.schema';
import { Model } from 'mongoose';
import { BaseRepository } from '../repositories/base.repository';

@Controller('drink')
export class DrinkController extends BaseRepository<Drink> {
  constructor(@InjectModel(Drink.name) private drinkModel: Model<Drink>) {
    super(drinkModel);
  }
}
