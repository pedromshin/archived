export class Drink {}
