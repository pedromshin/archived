export class CreateDrinkDto {}
