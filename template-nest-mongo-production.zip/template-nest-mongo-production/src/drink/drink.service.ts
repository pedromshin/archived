import { Model } from 'mongoose';
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Drink } from './drink.schema';

@Injectable()
export class DrinkService {
  constructor(@InjectModel(Drink.name) private drinkModel: Model<Drink>) {}
}
