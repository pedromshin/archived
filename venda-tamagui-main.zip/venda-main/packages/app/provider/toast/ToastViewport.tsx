import { ToastViewport as ToastViewportOg } from '@my/ui'

export const ToastViewport = () => {
  return <ToastViewportOg left={10} right={10} top={10} />
}
