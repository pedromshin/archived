// noop
export const SafeAreaProvider = ({ children }: { children: React.ReactNode }) => <>{children}</>
