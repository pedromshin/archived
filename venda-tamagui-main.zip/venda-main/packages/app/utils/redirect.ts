export const redirect = (url: string) => {
  location.href = url
}
