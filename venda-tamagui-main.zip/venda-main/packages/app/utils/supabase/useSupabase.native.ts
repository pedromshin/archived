import { supabase } from './client'

export const useSupabase = () => {
  return supabase
}
