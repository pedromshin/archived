export { useSafeAreaInsets } from 'react-native-safe-area-context'
