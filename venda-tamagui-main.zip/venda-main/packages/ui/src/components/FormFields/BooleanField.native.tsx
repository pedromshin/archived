export { BooleanSwitchField as BooleanField } from './BooleanSwitchField'
