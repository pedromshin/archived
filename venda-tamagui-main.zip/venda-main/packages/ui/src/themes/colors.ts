/**
 * change this export to update the colors
 *
 * 1. './colors-default' - the default tamagui theme
 * 2. './colors-neon' - based on the default theme, less saturated
 * 2. './colors-pastel' - based on the default theme, more saturated
 */

export * from './colors-default'
