import { ProfileScreen } from 'app/features/profile/screen'

export default function Screen() {
  return <ProfileScreen />
}
