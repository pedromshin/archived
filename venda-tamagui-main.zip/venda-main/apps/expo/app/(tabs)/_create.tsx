/**
 * dummy tab:
 * the _layout.tsx file will prevent rendering of this tab
 * instead, the user will be navigated to a modal
 */
export default function Screen() {
  return <></>
}
