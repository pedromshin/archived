import 'react-native-url-polyfill/auto'
import 'expo-router/entry'
