module.exports = {
  extends: 'next',
  root: true,
}
