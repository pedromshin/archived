export type AmplifyDependentResourcesAttributes = {
    "api": {
        "barFinder": {
            "GraphQLAPIKeyOutput": "string",
            "GraphQLAPIIdOutput": "string",
            "GraphQLAPIEndpointOutput": "string"
        }
    }
}