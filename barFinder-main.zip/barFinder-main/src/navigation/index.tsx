import * as React from "react";

import {
  NavigationContainer,
  DefaultTheme,
  DarkTheme,
} from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { ColorSchemeName } from "react-native";

import ModalScreen from "./components/screens/ModalScreen";
import NotFoundScreen from "./components/screens/NotFoundScreen";

import { RootStackParamList } from "../../types";
import LinkingConfiguration from "./LinkingConfiguration";
import { BottomTabNavigator } from "./components/BottomTabNavigator";
import BarScreen from "./components/screens/BarScreen";

import { Amplify } from "aws-amplify";
import awsconfig from "../aws-exports";


Amplify.configure(awsconfig);

export default function Navigation({
  colorScheme,
}: {
  colorScheme: ColorSchemeName;
}) {
  const Stack = createNativeStackNavigator<RootStackParamList>();

  return (
    <NavigationContainer
      linking={LinkingConfiguration}
      theme={colorScheme === "dark" ? DarkTheme : DefaultTheme}
    >
      <Stack.Navigator>
        <Stack.Screen
          name="Root"
          component={BottomTabNavigator}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="NotFound"
          component={NotFoundScreen}
          options={{ title: "Oops!" }}
        />
        <Stack.Group screenOptions={{ presentation: "modal" }}>
          <Stack.Screen name="ModalScreen" component={ModalScreen} />
          <Stack.Screen name="BarScreen" component={BarScreen} />
        </Stack.Group>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
