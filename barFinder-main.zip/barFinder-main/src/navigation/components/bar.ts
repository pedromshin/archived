const Bar = [
  {
    name: "La Fraternité",
    coordinates: {
      latitude: -23.608103,
      longitude: -46.670113,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    },
    id: 1,
    type: "Chopperia",
    price: "$$$$",
    hours: "17h - 01h",
    socialNetworks: {
      instagram: "instagram.com",
    },
    contacts: {
      telephone: "11 9 99999999",
    },
    address: "Alameda Jauaperi, 1413 - Indianópolis, São Paulo - SP, 04523-015",
  },
  {
    name: "Jura RIP",
    coordinates: {
      latitude: -23.6087414,
      longitude: -46.6708149,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    },
    id: 2,
    type: "Bar de sinuca",
    price: "$$",
    hours: "15h - 00h",
    socialNetworks: {
      instagram: "instagram.com",
    },
    contacts: {
      telephone: "11 9 99999999",
    },
    address: "Alameda Jauaperi, 1413 - Indianópolis, São Paulo - SP, 04523-015",
  },
  {
    name: "Benê Bar",
    coordinates: {
      latitude: -23.5625932,
      longitude: -46.6941773,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    },
    id: 3,
    type: "Bar e drinks",
    price: "$$$",
    hours: "15h - 00h",
    socialNetworks: {
      instagram: "instagram.com",
    },
    contacts: {
      telephone: "11 9 99999999",
    },
    address:
      "R. Padre Garcia Velho, 158 - Pinheiros, São Paulo - SP, 05421-030",
  },
  {
    name: "Bario",
    coordinates: {
      latitude: -23.561297,
      longitude: -46.693948,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    },
    id: 4,
    type: "Bar de jogos com máquinas de pinball",
    price: "$$$$",
    hours: "15h - 00h",
    socialNetworks: {
      instagram: "instagram.com",
    },
    contacts: {
      telephone: "11 9 99999999",
    },
    address: "Rua Coropé, 41 - Pinheiros, São Paulo - SP, 05426-010",
  },
];

export default Bar;
