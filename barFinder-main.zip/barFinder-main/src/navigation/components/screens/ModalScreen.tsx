import React, { useState } from "react";
import { Pressable, StyleSheet } from "react-native";
import { RootTabScreenProps } from "../../../../types";

import { Text, View } from "../../../components/Themed";

import { DataStore } from "aws-amplify";
import { Bar } from "../../../models";

export default function ModalScreen({
  navigation,
}: RootTabScreenProps<"ModalScreen">) {
  const [barList, setBarList] = useState<Bar[]>([]);

  React.useEffect(() => {
    const subscription = DataStore.observeQuery(Bar).subscribe((snapshot) => {
      const { items } = snapshot;
      setBarList(items);
    });

    return function cleanup() {
      subscription.unsubscribe();
    };
  }, []);

  return (
    <View style={styles.container}>
      {barList.map((bar: any) => {
        return (
          <Pressable
            onPress={() => {
              navigation.navigate("BarScreen", {
                selectedBar: bar,
              });
            }}
            style={({ pressed }) => ({
              opacity: pressed ? 0.5 : 1,
            })}
            key={bar.id}
          >
            <View
              style={{
                paddingVertical: 10,
                paddingHorizontal: 30,
                backgroundColor: "#fff",
                borderColor: "#eee",
                borderWidth: 1,
                borderRadius: 5,
                elevation: 10,
                marginHorizontal: 25,
                marginVertical: 10,
              }}
            >
              <Text>{bar.name}</Text>
              <Text>{bar.type}</Text>
              <Text>{bar.hours}</Text>
              <Text>{bar.price}</Text>
            </View>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
  },
  separator: {
    marginVertical: 30,
    height: 1,
    width: "80%",
  },
});
