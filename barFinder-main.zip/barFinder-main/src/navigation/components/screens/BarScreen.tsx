import React from "react";

import { Text, View } from "../../../components/Themed";

export default function BarScreen(bar: any) {
  return (
    <View
      style={{
        paddingVertical: 10,
        paddingHorizontal: 30,
        backgroundColor: "#fff",
        borderColor: "#eee",
        borderWidth: 1,
        borderRadius: 5,
        elevation: 10,
        marginHorizontal: 25,
        marginVertical: 10,
      }}
    >
      <Text>{bar.route.params.selectedBar.name}</Text>
      <Text>
        Instagram: {bar.route.params.selectedBar.socialNetworks.instagram}
      </Text>
      <Text>Contato: {bar.route.params.selectedBar.contact.telephone}</Text>
      <Text>Endereço: {bar.route.params.selectedBar.address}</Text>
    </View>
  );
}
