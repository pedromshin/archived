import React, { useState } from "react";
import { StyleSheet, Dimensions, Pressable } from "react-native";

import MapView from "react-native-map-clustering";
import { Marker } from "react-native-maps";

import { Text, View } from "../../../components/Themed";
import { RootTabScreenProps } from "../../../../types";

import { DataStore } from "aws-amplify";
import { Bar } from "../../../models";

export default function TabOneScreen({
  navigation,
}: RootTabScreenProps<"TabOne">) {
  const [barList, setBarList] = useState<Bar[]>([]);

  React.useEffect(() => {
    const subscription = DataStore.observeQuery(Bar).subscribe((snapshot) => {
      const { items } = snapshot;
      setBarList(items);
    });

    return function cleanup() {
      subscription.unsubscribe();
    };
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tab One</Text>
      <View
        style={styles.separator}
        lightColor="#eee"
        darkColor="rgba(255,255,255,0.1)"
      />
      <MapView
        style={{
          width: Dimensions.get("window").width,
          height: Dimensions.get("window").height,
        }}
        initialRegion={{
          latitude: -23.608103,
          longitude: -46.670113,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
      >
        {barList.map((bar: any) => {
          return (
            <Marker coordinate={bar.coordinates} key={bar.id}>
              <Pressable
                onPress={() => {
                  navigation.navigate("BarScreen", {
                    selectedBar: bar,
                  });
                }}
                style={({ pressed }) => ({
                  opacity: pressed ? 0.5 : 1,
                })}
              >
                <View
                  style={{
                    paddingVertical: 10,
                    paddingHorizontal: 30,
                    backgroundColor: "#F6EF16",
                    borderColor: "#eee",
                    borderRadius: 5,
                    elevation: 10,
                  }}
                >
                  <Text>{bar.name}</Text>
                </View>
              </Pressable>
            </Marker>
          );
        })}
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
  },
  separator: {
    marginVertical: 30,
    height: 1,
    width: "80%",
  },
});
