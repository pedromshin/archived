import { ModelInit, MutableModel } from "@aws-amplify/datastore";

export declare class Coordinates {
  readonly latitude?: number | null;
  readonly longitude?: number | null;
  readonly latitudeDelta?: number | null;
  readonly longitudeDelta?: number | null;
  constructor(init: ModelInit<Coordinates>);
}

export declare class Contacts {
  readonly telephone?: string | null;
  constructor(init: ModelInit<Contacts>);
}

export declare class SocialNetworks {
  readonly instagram?: string | null;
  constructor(init: ModelInit<SocialNetworks>);
}

type BarMetaData = {
  readOnlyFields: 'createdAt' | 'updatedAt';
}

export declare class Bar {
  readonly id: string;
  readonly name?: string | null;
  readonly type?: string | null;
  readonly description?: string | null;
  readonly price?: string | null;
  readonly address?: string | null;
  readonly socialNetworks?: SocialNetworks | null;
  readonly contact?: Contacts | null;
  readonly coordinates?: Coordinates | null;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
  constructor(init: ModelInit<Bar, BarMetaData>);
  static copyOf(source: Bar, mutator: (draft: MutableModel<Bar, BarMetaData>) => MutableModel<Bar, BarMetaData> | void): Bar;
}