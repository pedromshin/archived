// @ts-check
import { initSchema } from '@aws-amplify/datastore';
import { schema } from './schema';



const { Bar, Coordinates, Contacts, SocialNetworks } = initSchema(schema);

export {
  Bar,
  Coordinates,
  Contacts,
  SocialNetworks
};