import React from "react";
import { View, StyleSheet, SafeAreaView, ScrollView } from "react-native";
import Header from "../Header";
import Nav from "../Nav";

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <SafeAreaView style={styles.container}>
      <Header />
      <ScrollView contentContainerStyle={styles.content}>{children}</ScrollView>
      <Nav />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    margin: 20,
  },
});

export default Layout;
