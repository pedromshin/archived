import React, {
  createContext,
  useState,
  useContext,
  PropsWithChildren,
  useEffect,
  Dispatch,
} from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import axios from "axios";
import { endpoint } from "../utils";
import { jwtDecode, JwtPayload } from "jwt-decode";

export const accessTokenKey = "access_token";

type DecodedTokenType = JwtPayload & {
  username: string;
  user: {
    _id: string;
    _subscribableIds: string[];
    name: string;
    email: string;
    phoneNumber: string;
    username: string;
  };
};

export type AuthContextType = {
  auth:
    | {
        access_token: string;
        decodedToken: DecodedTokenType;
      }
    | undefined;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  verifyAuth: (callback: () => Promise<void>) => void;
  setDecodedToken: (access_token: string) => void;
};

export const AuthContext = createContext<AuthContextType | undefined>(
  undefined
);

export const AuthProvider = ({ children }: PropsWithChildren) => {
  const [auth, setAuth] = useState<AuthContextType["auth"] | undefined>(
    undefined
  );

  const setDecodedToken = (access_token: string) => {
    const decodedToken: DecodedTokenType = jwtDecode(access_token);
    setAuth({ access_token, decodedToken });
  };

  const login = async (username: string, password: string) => {
    const response = await axios.post(`${endpoint}/user/login`, {
      username,
      password,
    });
    const { access_token } = response.data;
    await AsyncStorage.setItem(accessTokenKey, access_token);
    setDecodedToken(access_token);
  };

  const logout = async () => {
    await AsyncStorage.removeItem(accessTokenKey);
    setAuth(undefined);
  };

  const verifyAuth = (callback: () => Promise<void>) => {
    if (!auth) {
      alert("É necessário fazer login para realizar esta ação!");
      return;
    } else {
      callback();
    }
  };

  useEffect(() => {
    const loadToken = async () => {
      const token = await AsyncStorage.getItem(accessTokenKey);
      if (token) {
        try {
          setDecodedToken(token);
        } catch (error) {
          console.error("Token decoding error:", error);
        }
      }
    };

    loadToken();
  }, []);

  return (
    <AuthContext.Provider
      value={{ auth, login, logout, verifyAuth, setDecodedToken }}
    >
      {children}
    </AuthContext.Provider>
  );
};
