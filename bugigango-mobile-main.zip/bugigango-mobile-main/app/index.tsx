import React from "react";
import Navigation from "./navigation";
import { AuthProvider } from "./providers/AuthProvider";
import { UserProvider } from "./context/UserContext";

const App = () => {
  return (
    <AuthProvider>
      <UserProvider>
        <Navigation />
      </UserProvider>
    </AuthProvider>
  );
};

export default App;
