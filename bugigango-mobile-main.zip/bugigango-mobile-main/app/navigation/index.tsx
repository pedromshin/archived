// src/navigation/RootNavigator.tsx

import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { NavigationContainer } from "@react-navigation/native";

// Import screens
import HomeScreen from "../screens/main/HomeScreen";
import MessagesScreen from "../screens/main/MessagesScreen";
// import NotificationsScreen from "../screens/main/NotificationsScreen";
// import ProfileScreen from "../screens/main/ProfileScreen";
// import RegisterScreen from "../screens/auth/RegisterScreen";
// import LoginScreen from "../screens/auth/LoginScreen";

// Import layout HOC
import withLayout from "../components/withLayout";

// Define routes
export const routes = {
  pageRoot: "Root",
  pageHome: "Home",
  pageMessages: "Messages",
  pageNotifications: "Notifications",
  pageProfile: "Profile",
  pageRegister: "Register",
  pageLogin: "Login",
} as const;

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const TabNavigator = () => {
  return (
    <Tab.Navigator>
      <Tab.Screen name={routes.pageHome} component={withLayout(HomeScreen)} />
      <Tab.Screen
        name={routes.pageMessages}
        component={withLayout(MessagesScreen)}
      />
      {/* <Tab.Screen
        name={routes.pageNotifications}
        component={withLayout(NotificationsScreen)}
      />
      <Tab.Screen
        name={routes.pageProfile}
        component={withLayout(ProfileScreen)}
      /> */}
    </Tab.Navigator>
  );
};

const AppNavigator = () => {
  return (
    <Stack.Navigator initialRouteName={routes.pageRoot}>
      <Stack.Screen
        name={routes.pageRoot}
        component={TabNavigator}
        options={{ headerShown: false }}
      />
      {/* <Stack.Screen
        name={routes.pageRegister}
        component={withLayout(RegisterScreen)}
      />
      <Stack.Screen
        name={routes.pageLogin}
        component={withLayout(LoginScreen)}
      /> */}
    </Stack.Navigator>
  );
};

const RootNavigator = () => {
  return (
    <NavigationContainer>
      <AppNavigator />
    </NavigationContainer>
  );
};

export default RootNavigator;
