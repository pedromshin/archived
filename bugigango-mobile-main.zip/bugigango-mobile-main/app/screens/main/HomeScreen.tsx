// src/screens/main/HomeScreen.tsx

import React, { useState } from "react";
import {
  View,
  Text,
  FlatList,
  Image,
  TextInput,
  TouchableOpacity,
} from "react-native";
import { StyleSheet } from "react-native";

import { useNavigation } from "@react-navigation/native";
import { useUserContext } from "../../hooks/useUserContext";
import { useSnackbar } from "../../hooks/useSnackbar";
import Api from "../../api/trpc";

const HomeScreen = () => {
  const navigation = useNavigation();
  const { user } = useUserContext();
  const { showSnackbar } = useSnackbar();
  const [comment, setComment] = useState("");
  const [offer, setOffer] = useState(0);

  const {
    data: posts,
    isLoading,
    refetch,
  } = Api.postData.findMany.useQuery({
    where: { user: { followsAsFollower: { some: { followerId: user?.id } } } },
    include: {
      user: true,
      commentsAsPost: {
        include: { user: true, replys: { include: { user: true } } },
      },
      likesAsPost: true,
    },
  });

  const { mutateAsync: likePost } = Api.like.create.useMutation();
  const { mutateAsync: createComment } = Api.comment.create.useMutation();
  const { mutateAsync: createReply } = Api.reply.create.useMutation();
  const { mutateAsync: createOffer } = Api.offer.create.useMutation();

  const handleLike = async (postId: string) => {
    try {
      await likePost({ data: { postId, userId: user?.id } });
      refetch();
    } catch (error) {
      showSnackbar("Failed to like post", "error");
    }
  };

  const handleComment = async (postId: string) => {
    try {
      await createComment({
        data: { postId, userId: user?.id, content: comment },
      });
      setComment("");
      refetch();
    } catch (error) {
      showSnackbar("Failed to comment", "error");
    }
  };

  const handleReply = async (commentId: string, content: string) => {
    try {
      await createReply({ data: { commentId, userId: user?.id, content } });
      refetch();
    } catch (error) {
      showSnackbar("Failed to reply", "error");
    }
  };

  const handleBuyNow = async (postId: string) => {
    try {
      await createOffer({
        data: {
          productId: postId,
          offeredByUserId: user?.id,
          offerAmount: offer,
        },
      });
      setOffer(0);
      showSnackbar("Offer made successfully", "success");
      refetch();
    } catch (error) {
      showSnackbar("Failed to make offer", "error");
    }
  };

  const renderItem = ({ item: post }: any) => (
    <View style={styles.postContainer}>
      <View style={styles.postHeader}>
        <Image source={{ uri: post.user?.pictureUrl }} style={styles.avatar} />
        <Text style={styles.username}>{post.user?.name}</Text>
        <TouchableOpacity
          onPress={() => handleBuyNow(post.id)}
          style={styles.buyButton}
        >
          <Text style={styles.buyButtonText}>Buy Now</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.postContent}>{post.content}</Text>
      {post.imageUrl && (
        <Image source={{ uri: post.imageUrl }} style={styles.postImage} />
      )}
      <Text style={styles.price}>Price: ${post.price?.toString()}</Text>
      <View style={styles.actionsContainer}>
        <TouchableOpacity
          onPress={() => handleLike(post.id)}
          style={styles.actionButton}
        >
          <Text>{post.likesAsPost?.length} Likes</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton}>
          <Text>{post.commentsAsPost?.length} Comments</Text>
        </TouchableOpacity>
      </View>
      <TextInput
        style={styles.commentInput}
        placeholder="Add a comment"
        value={comment}
        onChangeText={setComment}
        onSubmitEditing={() => handleComment(post.id)}
      />
    </View>
  );

  if (isLoading) {
    return <Text>Loading...</Text>;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Feed</Text>
      <Text style={styles.subtitle}>Posts from users you follow</Text>
      <FlatList
        data={posts}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 16,
  },
  postContainer: {
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 16,
  },
  postHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 8,
  },
  username: {
    flex: 1,
    fontWeight: "bold",
  },
  buyButton: {
    backgroundColor: "blue",
    padding: 8,
    borderRadius: 4,
  },
  buyButtonText: {
    color: "white",
  },
  postContent: {
    marginBottom: 8,
  },
  postImage: {
    width: "100%",
    height: 200,
    marginBottom: 8,
  },
  price: {
    fontWeight: "bold",
    marginBottom: 8,
  },
  actionsContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: 8,
  },
  actionButton: {
    padding: 8,
  },
  commentInput: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 8,
  },
});

export default HomeScreen;
