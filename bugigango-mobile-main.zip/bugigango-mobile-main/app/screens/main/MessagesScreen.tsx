// src/screens/main/MessagesScreen.tsx

import React, { useState } from "react";
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  Image,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { useUserContext } from "../../hooks/useUserContext";
import { useSnackbar } from "../../hooks/useSnackbar";
import Api from "../../api/trpc";
import { StyleSheet } from "react-native";

const MessagesScreen = () => {
  const navigation = useNavigation();
  const { user } = useUserContext();
  const { showSnackbar } = useSnackbar();
  const [searchTerm, setSearchTerm] = useState("");
  const [message, setMessage] = useState("");
  const [selectedUserId, setSelectedUserId] = useState(null);

  const { data: users, isLoading: isLoadingUsers } = Api.user.findMany.useQuery(
    {
      include: {
        followsAsFollower: { include: { followee: true } },
        followsAsFollowee: { include: { follower: true } },
        directMessagesAsSender: { include: { receiver: true } },
        directMessagesAsReceiver: { include: { sender: true } },
      },
    }
  );

  const {
    data: directMessages,
    isLoading: isLoadingMessages,
    refetch: refetchMessages,
  } = Api.directMessage.findMany.useQuery({
    where: {
      OR: [{ senderId: user?.id }, { receiverId: user?.id }],
    },
    include: {
      sender: true,
      receiver: true,
    },
  });

  const { mutateAsync: sendMessage } = Api.directMessage.create.useMutation();

  const handleSendMessage = async () => {
    if (selectedUserId && message.trim()) {
      await sendMessage({
        data: {
          message,
          senderId: user?.id,
          receiverId: selectedUserId,
        },
      });
      setMessage("");
      refetchMessages();
      showSnackbar("Message sent!", "success");
    }
  };

  const filteredUsers = users?.filter((u: any) =>
    u.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderUserItem = ({ item }: any) => (
    <TouchableOpacity
      onPress={() => setSelectedUserId(item.id)}
      style={styles.userItem}
    >
      <Image source={{ uri: item.pictureUrl }} style={styles.avatar} />
      <View>
        <Text style={styles.username}>{item.name}</Text>
        <Text>{item.email}</Text>
      </View>
    </TouchableOpacity>
  );

  const renderMessageItem = ({ item: msg }: any) => (
    <View style={styles.messageItem}>
      <Text style={styles.messageSender}>
        {msg.senderId === user?.id ? "You" : msg.sender?.name}
      </Text>
      <Text>{msg.message}</Text>
      <Text style={styles.messageTime}>
        {new Date(msg.timestamp).toLocaleString()}
      </Text>
    </View>
  );

  if (isLoadingUsers || isLoadingMessages) {
    return <Text>Loading...</Text>;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Direct Messages</Text>
      <Text>Continue existing chats or start new ones.</Text>
      <TextInput
        style={styles.searchInput}
        placeholder="Search users"
        value={searchTerm}
        onChangeText={setSearchTerm}
      />
      <View style={styles.contentContainer}>
        <View style={styles.userList}>
          <FlatList
            data={filteredUsers}
            renderItem={renderUserItem}
            keyExtractor={(item) => item.id}
          />
        </View>
        <View style={styles.chatContainer}>
          {selectedUserId ? (
            <>
              <FlatList
                data={directMessages?.filter(
                  (msg: { senderId: any; receiverId: any }) =>
                    msg.senderId === selectedUserId ||
                    msg.receiverId === selectedUserId
                )}
                renderItem={renderMessageItem}
                keyExtractor={(item) => item.id}
              />
              <TextInput
                style={styles.messageInput}
                value={message}
                onChangeText={setMessage}
                placeholder="Type your message..."
                multiline
              />
              <TouchableOpacity
                onPress={handleSendMessage}
                style={styles.sendButton}
              >
                <Text style={styles.sendButtonText}>Send</Text>
              </TouchableOpacity>
            </>
          ) : (
            <Text>Select a user to start chatting</Text>
          )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 8,
  },
  searchInput: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 8,
    marginBottom: 16,
  },
  contentContainer: {
    flexDirection: "row",
    flex: 1,
  },
  userList: {
    flex: 1,
    marginRight: 16,
  },
  chatContainer: {
    flex: 2,
  },
  userItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 8,
  },
  username: {
    fontWeight: "bold",
  },
  messageItem: {
    marginBottom: 8,
  },
  messageSender: {
    fontWeight: "bold",
  },
  messageTime: {
    fontSize: 12,
    color: "#888",
  },
  messageInput: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 8,
    marginTop: 16,
  },
  sendButton: {
    backgroundColor: "blue",
    padding: 8,
    alignItems: "center",
    marginTop: 8,
  },
  sendButtonText: {
    color: "white",
  },
});

export default MessagesScreen;
