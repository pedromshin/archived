// src/hooks/useSnackbar.ts

import { useCallback } from "react";
import { Alert } from "react-native";

type SnackbarVariant = "success" | "error" | "info" | "warning";

export const useSnackbar = () => {
  const showSnackbar = useCallback(
    (message: string, variant: SnackbarVariant) => {
      let title;
      switch (variant) {
        case "success":
          title = "Success";
          break;
        case "error":
          title = "Error";
          break;
        case "info":
          title = "Information";
          break;
        case "warning":
          title = "Warning";
          break;
        default:
          title = "Message";
      }

      Alert.alert(title, message);
    },
    []
  );

  return { showSnackbar };
};
