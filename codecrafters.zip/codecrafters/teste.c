#include <stdio.h>

int main()
{
    printf("Hello, World! This is a native C program compiled on the command line.\n");
    return 0;
}