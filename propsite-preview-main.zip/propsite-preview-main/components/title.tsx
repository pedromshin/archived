"use client"
import { useSearchParams } from "next/navigation";

export default function Title({data}: {data: any}) {
    const searchParams = useSearchParams()
    const title = data?.title ?? searchParams.get('title')
    const subtitle = data?.subtitle ?? searchParams.get('subtitle')

    return (
        <>
            <span className='font-medium'>{title}</span>
            <span className='text-xs'>{subtitle}</span>
        </>
    )
}