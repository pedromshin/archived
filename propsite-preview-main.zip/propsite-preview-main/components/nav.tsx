import { TooltipProvider } from './ui/tooltip'
import { cn } from '@/lib/utils'
import { INavLink, SideLink, sidelinks } from '@/data/sidelinks'
import { useCallback, useEffect, useState } from 'react'
import { NavLinkIconDropdown } from './navigation/NavLinkIconDropdown'
import { NavLinkIcon } from './navigation/NavLinkIcon'
import { NavLinkDropdown } from './navigation/NavLinkDropdown'
import { NavLink } from './navigation/NavLink'

import update from 'immutability-helper'
import { IconLayoutDashboard } from '@tabler/icons-react'
import { useSearchParams } from 'next/navigation'

export interface NavLinkProps extends SideLink {
  subLink?: boolean
  closeNav: () => void
  index: number
  moveCard: (dragIndex: number, hoverIndex: number) => void
}

export const ItemTypes = {
  NavItem: "NavItem"
}


export interface DragItem extends INavLink {
  index: number
}

interface NavProps extends React.HTMLAttributes<HTMLDivElement> {
  isCollapsed: boolean
  closeNav: () => void
  pages: {
    id: number,
    name: string,
    title: string,
    subtitle: string,
    description: string,
    propsiteId: number,
    order: number
}[]
}

export default function Nav({
  isCollapsed,
  className,
  closeNav,
  pages
}: NavProps) {
  const searchParams = useSearchParams()
  const [links, setLinks] = useState<SideLink[]>(sidelinks)

  const moveCard = useCallback((dragIndex: number, hoverIndex: number) => {
    setLinks((prevCards: SideLink[]) =>
      update(prevCards, {
        $splice: [
          [dragIndex, 1],
          [hoverIndex, 0, prevCards[dragIndex] as SideLink],
        ],
      }),
    )
  }, [])

  const renderLink = ({ sub, ...rest }: SideLink, index: number) => {
    const key = `${rest.title}-${rest.href}`

    const props = { closeNav, index, moveCard }

    if (isCollapsed && sub) {
      return (
        <NavLinkIconDropdown
          {...rest}
          sub={sub}
          key={key}
          closeNav={closeNav}
          index={index}
          moveCard={moveCard}
        />
      )
    }

    if (isCollapsed) {
      return <NavLinkIcon {...rest} {...props} key={key}/>
    }

    if (sub) {
      return (
        <NavLinkDropdown {...rest} {...props} sub={sub} key={key}/>
      )
    }

    return <NavLink {...rest} {...props} key={key}/>
  }

  useEffect(() => {
    const queryParamPages = searchParams.get('pages')?.split(",").map((item) => ({name: item}))
    setLinks([...(queryParamPages ?? pages ?? [])?.map(item => ({title: item.name, href: "/", icon: <IconLayoutDashboard size={18} />})), ...sidelinks])
  }, [pages])

  return (
    <div
      data-collapsed={isCollapsed}
      className={cn(
        'group border-b bg-background py-2 transition-[max-height,padding] duration-500 data-[collapsed=true]:py-2 md:border-none',
        className
      )}
    >
      <TooltipProvider delayDuration={0}>
        <nav className='grid gap-1 group-[[data-collapsed=true]]:justify-center group-[[data-collapsed=true]]:px-2'>
          {links.map(renderLink)}
        </nav>
      </TooltipProvider>
    </div>
  )
}

