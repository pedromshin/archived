import type { Identifier, XYCoord } from 'dnd-core'

import { IconChevronDown } from '@tabler/icons-react'
import {  buttonVariants } from '../custom/button'
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '../ui/collapsible'

import { cn } from '@/lib/utils'
import { useDrag, useDrop } from 'react-dnd'
import { DragItem, ItemTypes, NavLinkProps } from '../nav'
import { NavLink } from './NavLink'
import { useRef } from 'react'

export function NavLinkDropdown({ title, icon, label, sub, closeNav, index, moveCard }: NavLinkProps) {
  const ref = useRef<HTMLDivElement>(null)

  const [{ handlerId }, drop] = useDrop<
      DragItem,
      void,
      { handlerId: Identifier | null }
  >({
      accept: ItemTypes.NavItem,
      collect(monitor) {
          return {
              handlerId: monitor.getHandlerId(),
          }
      },
      hover(item: DragItem, monitor) {
          if (!ref.current) {
              return
          }
          const dragIndex = item.index
          const hoverIndex = index
          if (dragIndex === hoverIndex) {
              return
          }
          const hoverBoundingRect = ref.current?.getBoundingClientRect()
          const hoverMiddleY =
              (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2
          const clientOffset = monitor.getClientOffset()
          const hoverClientY = (clientOffset as XYCoord).y - hoverBoundingRect.top
          if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
              return
          }
          if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
              return
          }
          moveCard(dragIndex, hoverIndex)
          item.index = hoverIndex
      },
  })

  const [{ isDragging }, drag] = useDrag(() => ({
      type: ItemTypes.NavItem,
      item: { title },
      end: (item, monitor) => {
          const dropResult = monitor.getDropResult<any>()
          if (item && dropResult) {
              alert(`You dropped ${item.title} into ${dropResult.name}!`)
          }
      },
      collect: (monitor) => ({
          isDragging: monitor.isDragging(),
          handlerId: monitor.getHandlerId(),
      }),
  }))

  const opacity = isDragging ? 0 : 1
  drag(drop(ref))
  
    return (
      <div ref={ref} data-handler-id={handlerId} style={{ opacity }}>
        <Collapsible>
          <CollapsibleTrigger
            className={cn(
              buttonVariants({ variant: 'ghost', size: 'sm' }),
              'group h-12 w-full justify-start rounded-none px-6'
            )}
          >
            <div className='mr-2'>{icon}</div>
            {title}
            {label && (
              <div className='ml-2 rounded-lg bg-primary px-1 text-[0.625rem] text-primary-foreground'>
                {label}
              </div>
            )}
            <span
              className={cn(
                'ml-auto transition-all group-data-[state="open"]:-rotate-180'
              )}
            >
              <IconChevronDown stroke={1} />
            </span>
          </CollapsibleTrigger>
          <CollapsibleContent className='collapsibleDropdown' asChild>
            <ul>
              {sub!.map((sublink) => (
                <li key={sublink.title} className='my-1 ml-8'>
                  <NavLink {...sublink} subLink closeNav={closeNav} index={index} moveCard={moveCard}/>
                </li>
              ))}
            </ul>
          </CollapsibleContent>
        </Collapsible>
      </div>
    )
  }
  