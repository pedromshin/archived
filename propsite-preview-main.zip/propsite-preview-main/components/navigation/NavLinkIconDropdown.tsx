import type { Identifier, XYCoord } from 'dnd-core'

import { IconChevronDown } from '@tabler/icons-react'
import { Button } from '../custom/button'

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '../ui/tooltip'

import { useDrag, useDrop } from 'react-dnd'

import { DragItem, ItemTypes, NavLinkProps } from '../nav'
import { useRef } from 'react'

export function NavLinkIconDropdown({ title, icon, label, sub, index, moveCard }: NavLinkProps) {
  const ref = useRef<HTMLDivElement>(null)

  const [{ handlerId }, drop] = useDrop<
      DragItem,
      void,
      { handlerId: Identifier | null }
  >({
      accept: ItemTypes.NavItem,
      collect(monitor) {
          return {
              handlerId: monitor.getHandlerId(),
          }
      },
      hover(item: DragItem, monitor) {
          if (!ref.current) {
              return
          }
          const dragIndex = item.index
          const hoverIndex = index
          if (dragIndex === hoverIndex) {
              return
          }
          const hoverBoundingRect = ref.current?.getBoundingClientRect()
          const hoverMiddleY =
              (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2
          const clientOffset = monitor.getClientOffset()
          const hoverClientY = (clientOffset as XYCoord).y - hoverBoundingRect.top
          if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
              return
          }
          if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
              return
          }
          moveCard(dragIndex, hoverIndex)
          item.index = hoverIndex
      },
  })

  const [{ isDragging }, drag] = useDrag(() => ({
      type: ItemTypes.NavItem,
      item: { title },
      end: (item, monitor) => {
          const dropResult = monitor.getDropResult<any>()
          if (item && dropResult) {
              alert(`You dropped ${item.title} into ${dropResult.name}!`)
          }
      },
      collect: (monitor) => ({
          isDragging: monitor.isDragging(),
          handlerId: monitor.getHandlerId(),
      }),
  }))

  const opacity = isDragging ? 0 : 1
  drag(drop(ref))
  
    return (
      <div ref={ref} data-handler-id={handlerId} style={{ opacity }}>
        <DropdownMenu>
          <Tooltip delayDuration={0}>
            <TooltipTrigger asChild>
              <DropdownMenuTrigger asChild>
                <Button
                  variant={'secondary'}
                  size='icon'
                  className='h-12 w-12'
                >
                  {icon}
                </Button>
              </DropdownMenuTrigger>
            </TooltipTrigger>
            <TooltipContent side='right' className='flex items-center gap-4'>
              {title}
              {label && (
                <span className='ml-auto text-muted-foreground'>{label}</span>
              )}
              <IconChevronDown
                size={18}
                className='-rotate-90 text-muted-foreground'
              />
            </TooltipContent>
          </Tooltip>
          <DropdownMenuContent side='right' align='start' sideOffset={4}>
            <DropdownMenuLabel>
              {title} {label ? `(${label})` : ''}
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            {sub!.map(({ title, icon, label, href }) => (
              <DropdownMenuItem key={`${title}-${href}`} asChild>
                <a
                  href={href}
                  className={'bg-secondary'}
                >
                  {icon} <span className='ml-2 max-w-52 text-wrap'>{title}</span>
                  {label && <span className='ml-auto text-xs'>{label}</span>}
                </a>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    )
  }