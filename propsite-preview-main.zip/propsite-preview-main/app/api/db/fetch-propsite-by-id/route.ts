import prisma from '@/lib/prisma'
import { notFound } from 'next/navigation'

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url)
    const name = searchParams.get('name') ?? undefined

    const propsite = await prisma.propsite.findFirst({
        where: {
                name
            },
        include: { pages: { where: { propsiteId: { equals: name || undefined } } } },
    })

    if (!propsite) {
        notFound()
    }

    return Response.json(propsite)
}