"use client"
import Sidebar from "@/components/sidebar";
import useIsCollapsed from "@/hooks/use-is-collapsed";
import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";

function Home() {
  const [data, setData] = useState<any>()
  const [isCollapsed, setIsCollapsed] = useIsCollapsed()
  const searchParams = useSearchParams()
  const name = searchParams.get('name')

  useEffect(() => {
    (async () => {
     const propsite = await fetch(`${process.env.NEXT_PUBLIC_URL}/api/db/fetch-propsite-by-id?name=${name}`, { method: "GET" }).then((res) => res.json())

      setData(propsite)
    })()
  }, [])

  return (
<div className='relative h-full overflow-hidden bg-background'>
      <Sidebar isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} data={data} />
      <main
        id='content'
        className={`overflow-x-hidden pt-16 transition-[margin] md:overflow-y-hidden md:pt-0 ${isCollapsed ? 'md:ml-14' : 'md:ml-64'} h-full`}
      >
        {/* <Outlet /> */}
      </main>
    </div>
  );
}

export default function Page() {
  return <Suspense><Home /></Suspense>
}