import { RegisterLink } from "@kinde-oss/kinde-auth-nextjs/components";

export default function Home() {
  return (
    <>
      <section className="max-w-8xl mx-auto px-4 md:px-8 mb-16 mt-4 md:mt-32">
        <div className="max-w-5xl mx-auto text-center font-semibold text-3xl sm:text-5xl lg:text-6xl">
          <h1>Connect with friends +</h1>
          <h1 className="text-primary">
            earn money <span className="text-black">+</span> reduce trash
          </h1>
          <p className="mt-5 text-base lg:text-lg text-muted-foreground font-normal w-[90%] mx-auto">
            <span className="text-primary">Venda</span> is a{" "}
            <span className="text-primary">social marketplace</span> on a
            mission to <span className="text-primary">reduce waste</span> and{" "}
            <span className="text-primary">raise income</span> by enabling
            people to offer unused goods to friends and family.
          </p>
        </div>
        <div className="text-center mt-16">
          <RegisterLink className="inline-block bg-primary text-white py-2 px-4 rounded-lg text-lg font-semibold hover:bg-primary-dark transition">
            Get started!
          </RegisterLink>
        </div>
      </section>
      <section className="max-w-7xl mx-auto px-4 md:px-8 md:mt-32 mb-16">
        <h2 className="text-center text-3xl font-semibold mb-8">
          How it works
        </h2>
        <div className="flex flex-col lg:flex-row justify-around items-center gap-4">
          <div className="text-center lg:text-left mb-8 lg:mb-0 flex-1">
            <h3 className="text-xl font-semibold mb-2">
              1.
              <span className="text-primary">
                Connect with friends and family
              </span>
            </h3>
            <p className="text-base text-muted-foreground">
              Add people you trust to your network.
            </p>
          </div>
          <div className="text-center lg:text-left mb-8 lg:mb-0 flex-1">
            <h3 className="text-xl font-semibold mb-2">
              2.<span className="text-primary"> Post your items for sale </span>
            </h3>
            <p className="text-base text-muted-foreground">
              Receive offers from people interested in your items.
            </p>
          </div>
          <div className="text-center lg:text-left flex-1">
            <h3 className="text-xl font-semibold mb-2">
              3.<span className="text-primary"> Receive offers</span>
            </h3>
            <p className="text-base text-muted-foreground">
              Accept or refuse offers, earn money, reduce trash.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
