import { ChefHat, LampFloor, PartyPopper, CircuitBoard, BookOpen, Bed, Brush, Dices, Dumbbell, Watch, Box } from "lucide-react";
import { ReactNode } from "react";

interface iAppProps {
  name: string;
  title: string;
  image: ReactNode;
  id: number;
}

export const categoryItems: iAppProps[] = [
  {
    id: 0,
    name: "decoration",
    title: "Decoration",
    image: <LampFloor />,
  },
  {
    id: 1,
    name: "kitchen",
    title: "Kitchen",
    image: <ChefHat />,
  },
  {
    id: 2,
    name: "party",
    title: "Party",
    image: <PartyPopper />,
  },
  {
    id: 3,
    name: "electronic",
    title: "Electronics",
    image: <CircuitBoard />,
  },
  {
    id: 4,
    name: "books",
    title: "Books",
    image: <BookOpen />,
  },
  {
    id: 5,
    name: "furniture",
    title: "Furniture",
    image: <Bed />,
  },
  {
    id: 6,
    name: "art",
    title: "Art & Crafts",
    image: <Brush />,
  },
  {
    id: 7,
    name: "toys",
    title: "Toys",
    image: <Dices />,
  },
  {
    id: 8,
    name: "vintage",
    title: "Vintage Items",
    image: <Watch />,
  },
  {
    id: 9,
    name: "sports",
    title: "Sports Equipment",
    image: <Dumbbell />,
  },
  {
    id: 10,
    name: "other",
    title: "Other",
    image: <Box />,
  },
];
