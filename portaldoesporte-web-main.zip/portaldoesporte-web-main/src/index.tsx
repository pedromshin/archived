import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import Pages from "./pages";
import { AuthProvider } from "./providers/AuthProvider";
import { SpeedInsights } from "@vercel/speed-insights/react";
import { Analytics } from "@vercel/analytics/react";

const rootElement = document.getElementById("root");

if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <AuthProvider>
      <Pages />
      <SpeedInsights />
      <Analytics />
    </AuthProvider>
  );
} else {
  console.error("Root element not found");
}
