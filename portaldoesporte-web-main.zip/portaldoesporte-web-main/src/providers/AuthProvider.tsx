import {
  createContext,
  useState,
  PropsWithChildren,
  useEffect,
  useCallback,
  Dispatch,
  SetStateAction,
} from "react";
import { jwtDecode, JwtPayload } from "jwt-decode";
import { useApiRequest } from "../hooks/useApiRequest";

export const access_token = localStorage.getItem("access_token");

export type AuthContextType = {
  auth:
    | {
        access_token: string;
        decodedToken: JwtPayload & AuthContextType["user"];
      }
    | undefined;
  user:
    | {
        _id: string;
        _subscribableIds: string[];
        _representativesIds: string[];
        name: string;
        email: string;
        phoneNumber: string;
        username: string;
        password: string;
      }
    | undefined;
  login: (
    username: string,
    password: string
  ) => Promise<AuthContextType["user"]>;
  logout: () => void;
  verifyAuth: (callback: () => Promise<void>) => void;
  setDecodedToken: (access_token: string) => void;
  refetchUser: () => void;
  setUser: Dispatch<SetStateAction<AuthContextType["user"] | undefined>>;
  fetchProfilePicture: () => Promise<void>;
  profilePicUrl: string;
};

export const AuthContext = createContext<AuthContextType | undefined>(
  undefined
);

export const AuthProvider = ({ children }: PropsWithChildren) => {
  const { post, get } = useApiRequest();

  const [auth, setAuth] = useState<AuthContextType["auth"]>(undefined);

  const [user, setUser] = useState<AuthContextType["user"]>(undefined);

  const [profilePicUrl, setProfilePicUrl] = useState<string>("");

  const fetchProfilePicture = async () => {
    if (!user?._id) return;
    const response = await get(`aws/images/profile-picture/${user?._id}`);

    setProfilePicUrl(response?.preSignedUrl);
  };

  const setDecodedToken = (access_token: string) => {
    localStorage.setItem("access_token", access_token);

    const decodedToken: JwtPayload & AuthContextType["user"] =
      jwtDecode(access_token);

    setAuth({ access_token, decodedToken });
    setUser(decodedToken);
    return decodedToken;
  };

  const refetchUser = useCallback(async () => {
    if (auth) {
      try {
        const response = await get(`user/${auth.decodedToken._id}`);
        setUser(response);
      } catch (error) {
        console.error("Failed to fetch user:", error);
      }
    }
  }, [auth]);

  const login = async (username: string, password: string) => {
    try {
      const response = await post(`user/login`, {
        username,
        password,
      });

      if (response.statusCode !== 500) {
        const { access_token, user } = response;

        setDecodedToken(access_token);
        setUser(user);
      }

      return response.user;
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  const logout = () => {
    localStorage.removeItem("access_token");
    setAuth(undefined);
    setUser(undefined);
  };

  const verifyAuth = (callback: () => Promise<void>) => {
    if (!auth) {
      alert("É necessário fazer login para realizar esta ação!");
      return;
    } else {
      callback();
    }
  };

  useEffect(() => {
    if (access_token) {
      try {
        setDecodedToken(access_token);
      } catch (error) {
        console.error("Token decoding error:", error);
      }
    }
  }, []);

  useEffect(() => {
    if (!user) refetchUser();
  }, [auth, refetchUser]);

  return (
    <AuthContext.Provider
      value={{
        auth,
        user,
        profilePicUrl,
        login,
        logout,
        verifyAuth,
        setDecodedToken,
        refetchUser,
        setUser,
        fetchProfilePicture,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
