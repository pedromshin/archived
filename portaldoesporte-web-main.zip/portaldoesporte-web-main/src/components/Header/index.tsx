import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import styled from "styled-components";
import { routes } from "../../pages";
import { IconTrophy } from "@tabler/icons-react";
import ButtonProfile from "../ButtonProfile";

const HeaderWrapper = styled.div`
  padding: 0 16px;
  display: flex;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  min-height: 44px;
  background-color: #ffffff;
  justify-content: space-between;
  align-items: center;
  position: sticky;
  top: 0;
  z-index: 1000;
`;

const LogoLink = styled(Link)`
  display: flex;
  align-items: center;
  text-decoration: none;
  color: black;

  svg {
    stroke: black;
  }
`;

const AuthActions = styled.div`
  display: flex;
  align-items: center;

  p {
    margin: 0 10px;
    font-size: 16px;
    color: black;
  }
`;

const BaseButton = styled.button`
  padding: 8px 12px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;
`;

const Button = styled(BaseButton)`
  background-color: #0095f6;
  color: white;

  &:hover {
    background-color: #007bb5;
  }
`;

const Header: React.FC = () => {
  const { auth, user } = useAuth();
  const navigate = useNavigate();

  return (
    <HeaderWrapper>
      <LogoLink to={routes.pageFeed}>
        <IconTrophy size={24} />
      </LogoLink>
      <AuthActions>
        {!auth ? (
          <>
            <Button
              onClick={() => navigate(routes.pageLogin)}
              style={{ marginRight: "8px" }}
            >
              Login
            </Button>
            <Button onClick={() => navigate(routes.pageRegister)}>
              Cadastrar
            </Button>
          </>
        ) : (
          <>
            <p>{user?.username}</p>
            <ButtonProfile />
          </>
        )}
      </AuthActions>
    </HeaderWrapper>
  );
};

export default Header;
