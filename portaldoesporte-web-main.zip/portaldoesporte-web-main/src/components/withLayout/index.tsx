import React from "react";
import Layout from "../Layout";

const withLayout = (Component: React.FC) => {
  return () => (
    <Layout>
      <Component />
    </Layout>
  );
};

export default withLayout;
