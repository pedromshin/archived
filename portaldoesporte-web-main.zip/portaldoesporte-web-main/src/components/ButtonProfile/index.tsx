import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";
import { useAuth } from "../../hooks/useAuth";
import { routes } from "../../pages";
import { IconUser } from "@tabler/icons-react";
import { ProfilePicture } from "../ProfilePicture";

const DropdownContainer = styled.div`
  position: relative;
  display: inline-block;
`;

const DropdownMenu = styled.ul<{ $show: boolean }>`
  display: ${(props) => (props.$show ? "block" : "none")};
  position: absolute;
  background-color: #f8f9fa;
  min-width: 160px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  z-index: 1;
  right: 0;
  padding: 8px 0;
  margin: 0;
  list-style-type: none;
`;

const DropdownItem = styled.li`
  padding: 12px 16px;
  cursor: pointer;
  font-size: 14px;
  color: black;

  // &:hover {
  //   background-color: #f0f0f0;
  // }
`;

const ConfirmLogout = styled.button`
  background-color: crimson;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;

  &:hover {
    background-color: #d32f2f;
  }
`;

const ButtonProfile: React.FC = () => {
  const { user, profilePicUrl } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [confirmLogout, setConfirmLogout] = useState(false);
  const menuRef = useRef<HTMLUListElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const { logout, setUser } = useAuth();
  const navigate = useNavigate();

  const handleToggle = () => setIsOpen(!isOpen);

  const handleLogout = () => {
    setConfirmLogout(false);
    logout();
    setUser(undefined);
    navigate(routes.pageLogin);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (confirmLogout) {
      buttonRef?.current?.focus();
    }
  }, [confirmLogout]);

  return (
    <DropdownContainer>
      <ProfilePicture
        name={user?.name ?? ""}
        size={24}
        onClick={handleToggle}
        source={profilePicUrl}
      />
      <DropdownMenu ref={menuRef} $show={isOpen}>
        <DropdownItem onClick={() => navigate(routes.pageProfile)}>
          Perfil
        </DropdownItem>
        <DropdownItem onClick={() => navigate(routes.pageSettings)}>
          Configurações
        </DropdownItem>
        {!confirmLogout ? (
          <DropdownItem onClick={() => setConfirmLogout(true)}>
            Logout
          </DropdownItem>
        ) : (
          <ConfirmLogout
            ref={buttonRef}
            onClick={handleLogout}
            onBlur={() => setConfirmLogout(false)}
          >
            Confirmar Logout
          </ConfirmLogout>
        )}
      </DropdownMenu>
    </DropdownContainer>
  );
};

export default ButtonProfile;
