import React from "react";
import styled from "styled-components";

const ComponentDivider = styled.div<DividerProps>`
  background: rgb(219, 219, 219);

  ${({ orientation }) =>
    orientation === "vertical" && "width: 1px; height: 100%;"}

  ${({ orientation }) =>
    orientation === "horizontal" && "width: 100%; height: 1px;"}


  ${({ appearAt }) =>
    appearAt &&
    `
      display: none; 
      @media screen and (min-width: ${appearAt}px)  { 
        display: block; 
      }
    `}


  ${({ removeAt }) =>
    removeAt &&
    `
    @media screen and (min-width: ${removeAt}px) {
        display: none;
      }
    `}
`;

export interface DividerProps {
  orientation?: "horizontal" | "vertical";
  removeAt?: number;
  appearAt?: number;
}

export const Divider = (props: DividerProps) => {
  return <ComponentDivider {...props} />;
};
