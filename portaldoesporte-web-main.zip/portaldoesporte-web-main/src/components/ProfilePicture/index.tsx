import {
  Container,
  ImageWrapper,
  NameWrapper,
  NameInitials,
  ProfilePictureHover,
  EditCircle,
  EditButtonsWrapper,
} from "./styled";
import { IconPencil, IconTrash } from "@tabler/icons-react";

type ProfilePictureProps = {
  name: string;
  size: number;
  source?: string;
  enableedit?: boolean;
  style?: React.CSSProperties | undefined;
  editCallback?: () => void;
  deleteCallback?: () => void;
  onClick?: () => void;
};

const nameInitials = (name = "") => {
  const nameSplited = name.split(" ");
  const firstName = nameSplited[0] || "";
  const lastName = nameSplited[1] || "";

  return `${firstName[0] || ""}${lastName[0] || ""}`;
};

const ProfilePicture = ({
  name,
  size,
  source,
  enableedit,
  style,
  editCallback,
  deleteCallback,
  onClick,
}: ProfilePictureProps) => {
  return (
    <Container
      enableedit={!!enableedit}
      size={size}
      onClick={onClick}
      style={style}
    >
      {enableedit && (
        <ProfilePictureHover size={size}>
          <EditButtonsWrapper>
            <EditCircle
              size={size * (1 / 3)}
              onClick={() => {
                editCallback && editCallback();
              }}
            >
              <IconPencil
                fill="transparent"
                size={size * 0.25}
                stroke="white"
              />
            </EditCircle>
            {!!source && (
              <EditCircle size={size * (1 / 3)} onClick={deleteCallback}>
                <IconTrash fill="transparent" size={size * 0.25} />
              </EditCircle>
            )}
          </EditButtonsWrapper>
        </ProfilePictureHover>
      )}
      {source ? (
        <ImageWrapper size={size}>
          <img src={source} alt="profile" />
        </ImageWrapper>
      ) : (
        <NameWrapper size={size}>
          <NameInitials size={size}>
            {name ? nameInitials(name) : ""}
          </NameInitials>
        </NameWrapper>
      )}
    </Container>
  );
};

export { ProfilePicture };
export type { ProfilePictureProps };
