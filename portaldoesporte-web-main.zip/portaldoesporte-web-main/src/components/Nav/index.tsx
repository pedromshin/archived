import { Link, useLocation } from "react-router-dom";
import styled from "styled-components";
import { IconComponents, IconHome, IconSubtask } from "@tabler/icons-react";
import { routes } from "../../../src/pages";

const Container = styled.nav`
  position: fixed;
  bottom: 0;
  width: 100%;
  background: #ffffff;
  border-top: 1px solid #dbdbdb;
  box-shadow: 0 -1px 5px rgba(0, 0, 0, 0.1);
  z-index: 1000;
`;

const List = styled.ul`
  display: flex;
  padding: 0;
  margin: 0;
  justify-content: space-around;
`;

const Item = styled.li<{ selected: boolean }>`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 12px 0;
  color: ${({ selected }) => (selected ? "#000" : "#8e8e8e")};
  // background-color: ${({ selected }) =>
    selected ? "#FFAD05" : "transparent"};

  svg {
    stroke: ${({ selected }) => (selected ? "#FFAD05" : "#000")};
    // fill: ${({ selected }) => (selected ? "#000" : "none")};
    transition: all 0.3s ease;
  }

  &:hover {
    transform: scale(105%);
  }
`;

export default () => {
  const location = useLocation();
  const pathname = location.pathname;

  return (
    <Container>
      <List>
        <Item selected={pathname === routes.pageFeed}>
          <Link to={routes.pageFeed}>
            <IconHome size={24} />
          </Link>
        </Item>
        <Item selected={pathname === routes.pageForums}>
          <Link to={routes.pageForums}>
            <IconSubtask size={24} />
          </Link>
        </Item>
        <Item selected={pathname === routes.pageMemberships}>
          <Link to={routes.pageMemberships}>
            <IconComponents size={24} />
          </Link>
        </Item>
      </List>
    </Container>
  );
};
