import React from "react";
import styled from "styled-components";
import { useApiRequest } from "../../hooks/useApiRequest";
import { useAuth } from "../../hooks/useAuth";

const CarouselContainer = styled.div`
  display: flex;
  max-width: 100vw;
  overflow-x: auto;
  gap: 20px;
  padding: 10px 0;
  scroll-behavior: smooth;

  // Grid layout for larger screens
  @media (min-width: 1024px) {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    overflow-x: hidden; // Hide horizontal scroll on larger screens
  }
`;

const Card = styled.div`
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  box-sizing: border-box;
  flex: 0 0 300px; // For mobile layout

  // Adjust width based on the grid layout
  @media (min-width: 1024px) {
    max-width: none; // Override max-width for grid layout
  }
`;

const CardTitle = styled.h3`
  margin: 0 0 10px;
`;

const Button = styled.button`
  background-color: #0095f6;
  color: white;
  border: none;
  padding: 8px 12px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;
  &:hover {
    background-color: #007bb5;
  }
`;

export default function SubscribablesCarousel({ data }: any) {
  const { user, verifyAuth, refetchUser } = useAuth();
  const { patch } = useApiRequest();

  const onSubscribe = (subscribableId: string) => {
    verifyAuth(() =>
      patch(`user/${user?._id}/subscribe/${subscribableId}`).then(() =>
        refetchUser()
      )
    );
  };

  const onUnsubscribe = (subscribableId: string) => {
    verifyAuth(() =>
      patch(`user/${user?._id}/unsubscribe/${subscribableId}`).then(() =>
        refetchUser()
      )
    );
  };

  return (
    <CarouselContainer>
      {data.map((item: any) => (
        <Card key={item._id}>
          <CardTitle>{item.name}</CardTitle>
          <Button
            onClick={() => {
              user?._subscribableIds?.includes(item._id)
                ? onUnsubscribe(item._id)
                : onSubscribe(item._id);
            }}
          >
            {user?._subscribableIds?.includes(item._id) ? `Seguindo` : `Seguir`}
          </Button>
        </Card>
      ))}
    </CarouselContainer>
  );
}
