import styled from "styled-components";

const Container = styled.div`
  padding: 0 16px;
  margin-bottom: 14px;
`;

export default function PostContent({ subscribable, content }: any) {
  return <Container>{content}</Container>;
}
