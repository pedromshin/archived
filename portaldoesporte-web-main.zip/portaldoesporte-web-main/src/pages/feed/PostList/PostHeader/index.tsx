import styled from "styled-components";
import { ProfilePicture } from "../../../../components/ProfilePicture";
import { Link } from "react-router-dom";
import { routes } from "../../..";
import { useAuth } from "../../../../hooks/useAuth";
import { useApiRequest } from "../../../../hooks/useApiRequest";

const Container = styled(Link)`
  display: flex;
  align-items: center;
  padding: 14px 16px;
  text-decoration: none;
  color: inherit;

  &:hover {
    text-decoration: none;
    color: inherit;
  }

  &:visited {
    color: inherit;
    text-decoration: none;
  }

  &:active {
    color: inherit;
    text-decoration: none;
  }
`;

const TextsWrapper = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  width: 100%;
  height: 100%;
  gap: 4px;
`;

const Name = styled.span`
  margin: 0;
  font-size: 14px;
  font-weight: 600;
`;
const Button = styled.button<{ following: boolean }>`
  border: 0;
  background: 0;
  padding: 0;
  color: ${({ following }) => (following ? `#1DB632` : `#4D9DE0`)};
  font-weight: 600;
  cursor: pointer;
`;

export default function PostHeader({ subscribable }: any) {
  const { user, verifyAuth, refetchUser } = useAuth();

  const { name } = subscribable;
  const { patch } = useApiRequest();

  const onSubscribe = (subscribableId: string) => {
    verifyAuth(() =>
      patch(`user/${user?._id}/subscribe/${subscribableId}`).then(() =>
        refetchUser()
      )
    );
  };

  const onUnsubscribe = (subscribableId: string) => {
    verifyAuth(() =>
      patch(`user/${user?._id}/unsubscribe/${subscribableId}`).then(() =>
        refetchUser()
      )
    );
  };

  const following = user?._subscribableIds?.includes(subscribable._id);
  return (
    <Container to={routes.pageFeed}>
      <ProfilePicture name={name} size={32} style={{ marginRight: "12px" }} />
      <TextsWrapper>
        <Name>{name}</Name>
        <span style={{ color: "rgb(115, 115, 115)" }}>•</span>
        <Button
          following={!!following}
          onClick={() => {
            user?._subscribableIds?.includes(subscribable._id)
              ? onUnsubscribe(subscribable._id)
              : onSubscribe(subscribable._id);
          }}
        >
          {following ? `Seguindo` : `Seguir`}
        </Button>
      </TextsWrapper>
    </Container>
  );
}
