import styled from "styled-components";
import PostHeader from "./PostHeader";
import { Divider } from "../../../components/Divider";
import PostContent from "./PostContent";

const PostContainer = styled.div`
  width: 100%;
`;

export default function PostList({ data }: any) {
  return (
    <>
      {data?.map((item: any) => (
        <PostContainer key={item._id}>
          <PostHeader {...item} />
          <PostContent {...item} />
          <Divider orientation="horizontal" />
        </PostContainer>
      ))}
    </>
  );
}
