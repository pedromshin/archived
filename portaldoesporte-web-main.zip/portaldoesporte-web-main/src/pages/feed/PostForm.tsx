import { useForm } from "react-hook-form";
import { useApiRequest } from "../../hooks/useApiRequest";
import { useAuth } from "../../hooks/useAuth";
import styled from "styled-components";
import { useDataFetcher } from "../../hooks/useDataFetcher";

const FormContainer = styled.div`
  width: 100%;
  max-width: 400px;
  background: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  padding: 10px;
  border: 1px solid #e0e0e0;
  position: relative;
  margin-bottom: 20px;
`;

const FormGroup = styled.div`
  margin-bottom: 10px;
`;

const Label = styled.label`
  display: block;
  font-size: 12px;
  color: #666;
  margin-bottom: 5px;
`;

const Select = styled.select`
  width: 100%;
  padding: 8px;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  font-size: 14px;
  box-sizing: border-box;
  margin-bottom: 10px;
`;

const Textarea = styled.textarea`
  width: 100%;
  padding: 8px;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  font-size: 14px;
  resize: none;
  min-height: 80px;
  box-sizing: border-box;
  margin-bottom: 10px;
`;

const Button = styled.button`
  background-color: #0095f6;
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;
  position: absolute;
  bottom: 10px;
  right: 10px;

  &:hover {
    background-color: #007bb5;
  }
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 16px;
  margin-bottom: 16px;

  &:focus {
    border-color: #007bff;
    outline: none;
  }
`;

export default function PostForm({ refetch }: any) {
  const { register, handleSubmit, reset } = useForm();
  const { post } = useApiRequest();
  const { user, verifyAuth } = useAuth();

  const { data: representedSubscribables } = useDataFetcher(
    `user/${user?._id}/represented-subscribables`,
    [user],
    { enabled: !!user }
  );

  const onSubmit = async ({ title, content, _subscribableId }: any) => {
    verifyAuth(() =>
      post("post", {
        _subscribableId,
        entity: representedSubscribables?.find(
          (item: any) => item._id === _subscribableId
        )?.entity,
        title,
        content,
      }).then(() => {
        reset();
        refetch();
      })
    );
  };

  return (
    <FormContainer>
      <form onSubmit={handleSubmit(onSubmit)}>
        <FormGroup>
          <Label>Postar representando:</Label>
          <Select {...register("_subscribableId", { required: true })}>
            {representedSubscribables?.map((item: any) => (
              <option key={item?._id} value={item?._id}>
                {item?.name}
              </option>
            ))}
          </Select>
        </FormGroup>
        <Input type="text" {...register("title")} placeholder="Título" />
        <Textarea
          placeholder="Escreva aqui..."
          {...register("content", { required: true })}
        />
        <Button type="submit">Postar</Button>
      </form>
    </FormContainer>
  );
}
