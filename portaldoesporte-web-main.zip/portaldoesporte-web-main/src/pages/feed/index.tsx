import styled from "styled-components";
import PostList from "./PostList";
import { useDataFetcher } from "../../hooks/useDataFetcher";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import { routes } from "..";

const Container = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const Button = styled.button``;

export default function Feed() {
  const navigate = useNavigate();
  const { auth, user } = useAuth();
  const [showFollowing, setShowFollowing] = useState(false);

  const { data: feedData } = useDataFetcher(`post/${user?._id}/feed`, [user], {
    enabled: !!user,
  });

  const { data: postData, refetch } = useDataFetcher("post");

  const reversedFeed = useMemo(() => feedData?.slice().reverse(), [feedData]);
  const reversedPost = useMemo(() => postData?.slice().reverse(), [postData]);

  const handleToggle = () => {
    setShowFollowing((prev) => !prev);
  };

  return (
    <Container>
      <PostList data={reversedPost} />
      {showFollowing ? (
        !auth ? (
          <div>
            <Button onClick={() => navigate(routes.pageLogin)}>Log In</Button>
            <Button onClick={() => navigate(routes.pageRegister)}>
              Sign Up
            </Button>
            <p>to follow your favorite creators!</p>
          </div>
        ) : (
          <PostList data={reversedFeed} />
        )
      ) : (
        <PostList data={reversedPost} />
      )}
    </Container>
  );
}
