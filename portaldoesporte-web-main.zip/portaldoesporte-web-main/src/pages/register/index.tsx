import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { useAuth } from "../../hooks/useAuth";
import styled from "styled-components";
import { useApiRequest } from "../../hooks/useApiRequest";

const fixedText = "@";

// Styles for the registration page
const PageWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 50vw;

  padding: 20px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  background-color: #ffffff;
  border-radius: 8px;
`;

const Title = styled.h1`
  margin-bottom: 20px;
  font-size: 24px;
  color: #333;
`;

const Form = styled.form`
  width: 100%;
  display: flex;
  flex-direction: column;
`;

const FormGroup = styled.div`
  margin-bottom: 15px;
`;

const Label = styled.label`
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
  color: #333;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 16px;

  &:focus {
    border-color: #007bff;
    outline: none;
  }
`;

const Button = styled.button`
  margin-top: 10px;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s;

  &.submit {
    background-color: #007bff;
    color: white;

    &:hover {
      background-color: #0056b3;
    }
  }

  &.back {
    background-color: #6c757d;
    color: white;

    &:hover {
      background-color: #5a6268;
    }
  }
`;

const ErrorMessage = styled.p`
  margin-top: 5px;
  color: red;
  font-size: 14px;
`;

const Register = () => {
  const { post } = useApiRequest();
  const { setDecodedToken } = useAuth();
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();
  const navigate = useNavigate();

  const handleUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (!value.startsWith(fixedText)) {
      setValue("username", fixedText + value);
    } else {
      setValue("username", value);
    }
  };

  const onSubmit = async (data: any) => {
    try {
      const { access_token } = await post(`user`, data);

      setDecodedToken(access_token);
      navigate(-1);
    } catch (error: any) {
      console.error("Registration error:", error?.response?.data);
      alert("Registration failed. Please try again.");
    }
  };

  return (
    <PageWrapper>
      <Title>Criar uma conta</Title>
      <Form onSubmit={handleSubmit(onSubmit)}>
        <FormGroup>
          <Label htmlFor="username">Username</Label>
          <Input
            id="username"
            type="text"
            {...register("username", { required: "Username is required." })}
            onChange={handleUsernameChange}
            placeholder="@"
          />
          {errors.username && (
            <ErrorMessage>{String(errors.username.message)}</ErrorMessage>
          )}
        </FormGroup>
        <FormGroup>
          <Label htmlFor="name">Nome</Label>
          <Input
            id="name"
            type="text"
            {...register("name", { required: "Name is required." })}
            placeholder="Nome"
          />
          {errors.name && (
            <ErrorMessage>{String(errors.name.message)}</ErrorMessage>
          )}
        </FormGroup>
        <FormGroup>
          <Label htmlFor="email">E-mail</Label>
          <Input
            id="email"
            type="email"
            placeholder="E-mail"
            {...register("email", {
              required: "Email is required.",
              pattern: {
                value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
                message: "Enter a valid email address.",
              },
            })}
          />
          {errors.email && (
            <ErrorMessage>{String(errors.email.message)}</ErrorMessage>
          )}
        </FormGroup>
        <FormGroup>
          <Label htmlFor="phoneNumber">Celular</Label>
          <Input
            id="phoneNumber"
            type="tel"
            placeholder="Celular"
            {...register("phoneNumber", {
              required: "Phone number is required.",
              pattern: {
                value: /^\d{10,15}$/,
                message: "Enter a valid phone number (10-15 digits).",
              },
            })}
          />
          {errors.phoneNumber && (
            <ErrorMessage>{String(errors.phoneNumber.message)}</ErrorMessage>
          )}
        </FormGroup>
        <FormGroup>
          <Label htmlFor="otp">Código de verificação</Label>
          <Input
            id="otp"
            type="text"
            placeholder="Código de verificação enviado ao e-mail ou celular"
            disabled
            {...register("otp")}
          />
        </FormGroup>
        <FormGroup>
          <Label htmlFor="password">Senha</Label>
          <Input
            id="password"
            type="password"
            {...register("password", {
              required: "Password is required.",
              minLength: {
                value: 8,
                message: "Password must be at least 8 characters long.",
              },
            })}
            placeholder="Crie uma senha (mínimo 8 caracteres)"
          />
          {errors.password && (
            <ErrorMessage>{String(errors.password.message)}</ErrorMessage>
          )}
        </FormGroup>

        <Button type="submit" className="submit">
          Confirmar cadastro
        </Button>
        <Button type="button" onClick={() => navigate(-1)} className="back">
          Voltar
        </Button>
      </Form>
    </PageWrapper>
  );
};

export default Register;
