import styled from "styled-components";
import { useAuth } from "../../hooks/useAuth";
import { useDataFetcher } from "../../hooks/useDataFetcher";
import { PageWrapper, Title } from "../../styles";
import ForumCard from "./ForumCard";
import SubscribablesCarousel from "../../components/SubscribablesCarousel";

const ForumCardContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`;

const Forums = () => {
  const { user } = useAuth();
  const { data } = useDataFetcher(`subscribable/${user?._id}/forums`, [user], {
    enabled: !!user,
  });

  const { data: subscribables } = useDataFetcher(`subscribable`);

  return (
    <PageWrapper>
      <Title>Fóruns</Title>
      <SubscribablesCarousel data={subscribables} />
      <ForumCardContainer>
        {data.map((forum: any) => (
          <ForumCard key={forum._id} forum={forum} />
        ))}
      </ForumCardContainer>
    </PageWrapper>
  );
};

export default Forums;
