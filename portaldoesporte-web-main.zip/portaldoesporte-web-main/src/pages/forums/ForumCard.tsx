import React from "react";
import styled from "styled-components";
import { useNavigate } from "react-router-dom";
import { routes } from "..";

const Card = styled.div`
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
  display: flex;
  flex-direction: column;
  align-items: start;
`;

const CardTitle = styled.h3`
  margin: 0 0 10px;
`;

const CardType = styled.p`
  margin: 0 0 10px;
  color: #666;
`;

const Button = styled.button`
  background-color: #0095f6;
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;

  &:hover {
    background-color: #007bb5;
  }
`;

const ForumCard = ({ forum }: any) => {
  const navigate = useNavigate();

  return (
    <Card>
      <CardTitle>{forum.name}</CardTitle>
      <CardType>Tipo: {forum.entity}</CardType>
      <Button onClick={() => navigate(routes.pageForum(forum._id))}>
        Ir para a página de {forum.name}
      </Button>
    </Card>
  );
};

export default ForumCard;
