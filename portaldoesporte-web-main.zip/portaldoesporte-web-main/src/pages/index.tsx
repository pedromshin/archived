import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
} from "react-router-dom";
import Feed from "./feed";
import PrivacyPolicy from "./privacy-policy";
import Forums from "./forums";
import Map from "./map";
import Memberships from "./memberships";
import Register from "./register";
import Login from "./login";
import CreateSubscribable from "./create-subscribable";
import withLayout from "../components/withLayout";
import { useAuth } from "../hooks/useAuth";
import Forum from "./forum";
import Profile from "./profile";
import Settings from "./settings";

export const routes = {
  pageRoot: "/memberships",
  pageFeed: "/feed",
  pageForum: (_subscribableId: string) => `/forum/${_subscribableId}`,
  pageForums: "/forums",
  pageMap: "/map",
  pageMemberships: "/memberships",
  pageRegister: "/register",
  pageLogin: "/login",
  pageProfile: "/profile",
  pageSettings: "/settings",
  pageCreateSubscribable: "/create-subscribable",
  pagePrivacyPolicy: "/privacy-policy",
} as const;

const Pages: React.FC = () => {
  const { auth } = useAuth();

  return (
    <Router>
      <Routes>
        <Route
          path="*"
          element={
            auth?.access_token ? (
              <Navigate to={routes.pageFeed} replace />
            ) : (
              <Navigate to={routes.pageRoot} replace />
            )
          }
        />
        <Route path={routes.pageRoot} element={withLayout(Memberships)()} />
        <Route path={routes.pageFeed} element={withLayout(Feed)()} />
        <Route
          path={routes.pageForum(":_subscribableId")}
          element={withLayout(Forum)()}
        />
        <Route path={routes.pageForums} element={withLayout(Forums)()} />
        <Route path={routes.pageMap} element={withLayout(Map)()} />
        <Route
          path={routes.pageRegister}
          element={
            auth?.access_token ? (
              <Navigate to={routes.pageFeed} replace />
            ) : (
              withLayout(Register)()
            )
          }
        />
        <Route
          path={routes.pageLogin}
          element={
            auth?.access_token ? (
              <Navigate to={routes.pageFeed} replace />
            ) : (
              withLayout(Login)()
            )
          }
        />
        <Route
          path={routes.pageCreateSubscribable}
          element={withLayout(CreateSubscribable)()}
        />
        <Route
          path={routes.pagePrivacyPolicy}
          element={withLayout(PrivacyPolicy)()}
        />
        <Route path={routes.pageProfile} element={withLayout(Profile)()} />
        <Route path={routes.pageSettings} element={withLayout(Settings)()} />
      </Routes>
    </Router>
  );
};

export default Pages;
