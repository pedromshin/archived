import { useAuth } from "../../hooks/useAuth";
import { useDataFetcher } from "../../hooks/useDataFetcher";
import { PageWrapper, Title } from "../../styles";
import Representations from "./Representations";
import SubscribablesCarousel from "../../components/SubscribablesCarousel";
import { routes } from "..";
import { Link } from "react-router-dom";

const MainPage = () => {
  const { user } = useAuth();
  const { data: subscribables } = useDataFetcher("subscribable");
  const { data: representedSubscribables } = useDataFetcher(
    `user/${user?._id}/represented-subscribables`,
    [user],
    { enabled: !!user }
  );

  return (
    <PageWrapper>
      <Link to={routes.pageCreateSubscribable}>
        Clique aqui para criar sua própria página oficial!
      </Link>
      {!!representedSubscribables.length && user && (
        <>
          <Title>Minhas Representações</Title>
          <Representations
            representedSubscribables={representedSubscribables}
          />
        </>
      )}
      <Title>Descubra e Siga</Title>
      <SubscribablesCarousel data={subscribables} />
    </PageWrapper>
  );
};

export default MainPage;
