import React, { useState } from "react";
import styled from "styled-components";
import { useApiRequest } from "../../hooks/useApiRequest";
import { useAuth } from "../../hooks/useAuth";
import { useDataFetcher } from "../../hooks/useDataFetcher";

const CardContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  margin-top: 20px;
`;

const Card = styled.div`
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  flex: 1 1 calc(33.333% - 20px);
  box-sizing: border-box;
  position: relative;
`;

const CardTitle = styled.h3`
  margin: 0 0 10px;
`;

const MultiSelectWrapper = styled.div`
  position: relative;
  margin-top: 10px;
`;

const SelectedItems = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  padding: 5px;
  border: 1px solid #ddd;
  border-radius: 4px;
  min-height: 40px;
  cursor: pointer;
`;

const SelectedItem = styled.span`
  background-color: #e0e0e0;
  padding: 2px 8px;
  border-radius: 4px;
  display: flex;
  align-items: center;
`;

const RemoveButton = styled.button`
  background: none;
  border: none;
  color: #888;
  margin-left: 5px;
  cursor: pointer;
`;

const DropdownList = styled.ul`
  position: absolute;
  width: 100%;
  max-height: 150px;
  overflow-y: auto;
  list-style-type: none;
  padding: 0;
  margin: 0;
  border: 1px solid #ddd;
  border-top: none;
  border-radius: 0 0 4px 4px;
  background-color: white;
  z-index: 1;
`;

const DropdownItem = styled.li`
  padding: 8px 12px;
  cursor: pointer;

  &:hover {
    background-color: #f0f0f0;
  }
`;

const MultiSelect = ({ options, onChange }: any) => {
  const [selectedItems, setSelectedItems] = useState<any>([]);
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (option: any) => {
    const newSelectedItems = [...selectedItems, option];
    setSelectedItems(newSelectedItems);
    onChange(newSelectedItems);
  };

  const handleRemove = (optionToRemove: any) => {
    const newSelectedItems = selectedItems.filter(
      (item: any) => item._id !== optionToRemove._id
    );
    setSelectedItems(newSelectedItems);
    onChange(newSelectedItems);
  };

  return (
    <MultiSelectWrapper>
      <SelectedItems onClick={() => setIsOpen(!isOpen)}>
        {selectedItems.map((item: any) => (
          <SelectedItem key={item._id}>
            {item.username}
            <RemoveButton onClick={() => handleRemove(item)}>×</RemoveButton>
          </SelectedItem>
        ))}
      </SelectedItems>
      {isOpen && (
        <DropdownList>
          {options
            .filter((option: any) => !selectedItems.includes(option))
            .map((option: any) => (
              <DropdownItem
                key={option._id}
                onClick={() => handleSelect(option)}
              >
                {option.username}
              </DropdownItem>
            ))}
        </DropdownList>
      )}
    </MultiSelectWrapper>
  );
};

export default function Representations({ representedSubscribables }: any) {
  const { user } = useAuth();
  const { patch } = useApiRequest();
  const { data: users } = useDataFetcher(`user`, [user], {
    enabled: !!user,
  });

  const onSubmit = async ({
    _subscribableId,
    selectedRepresentatives,
  }: any) => {
    const representatives = selectedRepresentatives.map((rep: any) => ({
      userId: rep._id,
    }));

    // Uncomment when ready to make API calls
    // const requests = representatives.map((rep) =>
    //   patch(`representation`, {
    //     _subscribableId,
    //     representativeId: rep.userId,
    //   })
    // );
    // await Promise.all(requests);
  };

  return (
    <CardContainer>
      {representedSubscribables?.map((item: any) => (
        <Card key={item._id}>
          <CardTitle>{item.name}</CardTitle>
          <MultiSelect
            options={users || []}
            onChange={(selectedRepresentatives: any) =>
              onSubmit({
                _subscribableId: item._id,
                selectedRepresentatives,
              })
            }
          />
        </Card>
      ))}
    </CardContainer>
  );
}
