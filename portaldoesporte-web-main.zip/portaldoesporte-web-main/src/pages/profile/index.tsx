import React, { useEffect, useState } from "react";
import styled from "styled-components";
import { useForm } from "react-hook-form";
import { useAuth } from "../../hooks/useAuth";
import { ProfilePicture } from "../../components/ProfilePicture";
import { endpoint, useApiRequest } from "../../hooks/useApiRequest";

const ProfileContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  background: #f1f1f1;
  min-height: 100vh;
`;

const ProfileWrapper = styled.div`
  width: 100%;
  max-width: 400px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-top: 20px;
`;

const ProfileForm = styled.form`
  width: 100%;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-top: 20px;
`;

const FormGroup = styled.div`
  margin-bottom: 16px;
`;

const Label = styled.label`
  display: block;
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 16px;
  box-sizing: border-box;
  transition: border-color 0.3s ease;

  &:focus {
    border-color: #007bff;
    outline: none;
  }
`;

const Button = styled.button`
  background-color: #0095f6;
  color: white;
  border: none;
  padding: 10px 16px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s;

  &:hover {
    background-color: #007bb5;
  }

  &:disabled {
    background-color: #ccc;
    cursor: not-allowed;
  }
`;

const Profile: React.FC = () => {
  const { user, profilePicUrl, setUser, refetchUser, fetchProfilePicture } =
    useAuth();
  const { get, post, patch } = useApiRequest();
  const [isEditing, setIsEditing] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();

  const [isLoading, setIsLoading] = useState(false);

  const onSubmit = async (formData: any) => {
    setIsLoading(true);
    try {
      await patch(`user/${user?._id}`, formData);
      setUser((prevUser: any) => ({ ...prevUser, ...formData }));
      refetchUser();
      setIsEditing(false);
    } catch (error) {
      console.error("Failed to update user info:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    reset();
    setIsEditing(false);
  };

  const handleFileChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      const formData = new FormData();
      formData.append("file", file);

      await fetch(`${endpoint}/aws/upload/profile-picture/${user?._id}`, {
        method: "POST",
        body: formData,
      });

      fetchProfilePicture();
    }
  };

  const handleEditClick = () => {
    const fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = "image/*";
    fileInput.onchange = (event: Event) => {
      const target = event.target as HTMLInputElement;
      if (target.files?.length) {
        handleFileChange({
          target: target as HTMLInputElement,
        } as React.ChangeEvent<HTMLInputElement>);
      }
    };
    fileInput.click();
  };

  useEffect(() => {
    if (user) {
      fetchProfilePicture();
      reset({
        name: user?.name,
        email: user?.email,
        phoneNumber: user?.phoneNumber,
        username: user?.username,
      });
    }
  }, [user, reset]);

  return (
    <ProfileContainer>
      <ProfilePicture
        name={user?.name ?? ""}
        size={100}
        source={profilePicUrl}
        editCallback={handleEditClick}
        deleteCallback={() => null}
        enableedit
      />

      {!isEditing ? (
        <ProfileWrapper>
          <p>Name: {user?.name}</p>
          <p>Email: {user?.email}</p>
          <p>Phone: {user?.phoneNumber}</p>
          <p>Username: {user?.username}</p>
          <Button onClick={() => setIsEditing(true)}>Edit Profile</Button>
        </ProfileWrapper>
      ) : (
        <ProfileForm onSubmit={handleSubmit(onSubmit)}>
          <FormGroup>
            <Label>Name</Label>
            <Input
              type="text"
              {...register("name", { required: "Name is required" })}
            />
            {errors.name && <p>{errors.name.message as any}</p>}
          </FormGroup>
          <FormGroup>
            <Label>Email</Label>
            <Input
              type="email"
              {...register("email", {
                required: "Email is required",
                pattern: {
                  value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                  message: "Invalid email address",
                },
              })}
            />
            {errors.email && <p>{errors?.email?.message as any}</p>}
          </FormGroup>
          <FormGroup>
            <Label>Phone Number</Label>
            <Input
              type="text"
              {...register("phoneNumber", {
                required: "Phone number is required",
                pattern: {
                  value: /^[0-9]{10,15}$/,
                  message: "Invalid phone number",
                },
              })}
            />
            {errors.phoneNumber && <p>{errors?.phoneNumber?.message as any}</p>}
          </FormGroup>
          <FormGroup>
            <Label>Username</Label>
            <Input
              type="text"
              {...register("username", { required: "Username is required" })}
            />
            {errors.username && <p>{errors?.username?.message as any}</p>}
          </FormGroup>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Saving..." : "Save Changes"}
          </Button>
          <Button type="button" onClick={handleCancel}>
            Cancel
          </Button>
        </ProfileForm>
      )}
    </ProfileContainer>
  );
};

export default Profile;
