import { useParams } from "react-router-dom";
import { useDataFetcher } from "../../hooks/useDataFetcher";

export default function Forum() {
  const { _subscribableId } = useParams();
  const { data } = useDataFetcher(`subscribable/${_subscribableId}`);

  return (
    <div>
      <h1>Fórum de {data?.[0]?.name}</h1>
      <p>Seguidores: {data?.[0]?._userIds?.length}</p>
    </div>
  );
}
