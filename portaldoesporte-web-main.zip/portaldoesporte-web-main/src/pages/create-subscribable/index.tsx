import Form from "./Form";

export default function Page() {
  return (
    <div>
      <h2>Abrir página oficial</h2>
      <div className="App">
        <Form />
      </div>
    </div>
  );
}
