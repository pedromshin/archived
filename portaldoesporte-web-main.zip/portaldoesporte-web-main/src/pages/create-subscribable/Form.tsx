import { useForm } from "react-hook-form";
import styled from "styled-components";
import { useApiRequest } from "../../hooks/useApiRequest";
import { useAuth } from "../../hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { routes } from "..";

const FormComponent = styled.form`
  max-width: 500px;
  margin: 20px auto;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 5px;
  background-color: #f9f9f9;
`;

const FormGroup = styled.div`
  margin-bottom: 15px;
`;

const Label = styled.label`
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-sizing: border-box;
`;

const Select = styled.select`
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-sizing: border-box;
`;

const Button = styled.button`
  background-color: #4caf50;
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #45a049;
  }
`;

const ButtonsWrapper = styled.div`
  display: flex;
  justify-content: space-between;
`;

export default function Form() {
  const navigate = useNavigate();
  const { user, refetchUser } = useAuth();
  const { register, handleSubmit } = useForm({
    defaultValues: { name: user?.name, entity: "athlete" },
  });

  const { post } = useApiRequest();
  const { verifyAuth } = useAuth();

  const onSubmit = async (data: any) => {
    verifyAuth(() =>
      post("subscribable", {
        name: data.name,
        entity: data.entity,
        userId: user?._id,
      }).then(() => {
        refetchUser();
        navigate(routes.pageMemberships);
      })
    );
  };

  return (
    <FormComponent onSubmit={handleSubmit(onSubmit)}>
      <FormGroup>
        <Label>Nome:</Label>
        <Input
          type="text"
          {...register("name", {
            required: true,
          })}
        />
      </FormGroup>
      <FormGroup>
        <Label>Tipo:</Label>
        <Select {...register("entity", { required: true })}>
          <option value="athlete">Atleta</option>
          <option value="gym">Gym</option>
        </Select>
      </FormGroup>
      <ButtonsWrapper>
        <Button
          type="button"
          style={{ background: "red" }}
          onClick={() => navigate(-1)}
        >
          Voltar
        </Button>
        <Button type="submit">Criar</Button>
      </ButtonsWrapper>
    </FormComponent>
  );
}
