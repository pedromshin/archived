export default () => {
  return <h2>Mapa</h2>;
};
