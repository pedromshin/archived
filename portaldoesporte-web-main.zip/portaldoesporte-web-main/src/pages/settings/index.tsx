export default function Settings() {
  return <></>;
}
