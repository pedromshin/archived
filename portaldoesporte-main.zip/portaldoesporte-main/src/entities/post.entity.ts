export class Post {
  _subscribableId: string;
  entity: string;
  title: string;
  content: string;
}
