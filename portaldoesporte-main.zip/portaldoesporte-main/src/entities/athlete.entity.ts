export class Athlete {
  name: string;
}
