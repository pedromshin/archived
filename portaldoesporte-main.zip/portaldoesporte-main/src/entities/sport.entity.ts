export class Sport {
  name: string;
}
