export class User {
  _id: string;
  _subscribableIds: string[];
  _representativesIds: string[];
  name: string;
  email: string;
  phoneNumber: string;
  username: string;
  password: string;

  constructor({
    _id,
    _subscribableIds,
    _representativesIds,
    name,
    email,
    phoneNumber,
    username,
    password,
  }) {
    this._id = _id;
    this._subscribableIds = _subscribableIds;
    this._representativesIds = _representativesIds;
    this.name = name;
    this.email = email;
    this.phoneNumber = phoneNumber;
    this.username = username;
    this.password = password;
  }
}
