export class Subscribable {
  _postIds: string[];
  _userIds: string[];
  _representativesId: string[];
  name: string;
  entity: string;
}
