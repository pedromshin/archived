export class Representatives {
  _userIds: string[];
  _subscribableId: string;
}
