export class Gym {
  name: string;
}
