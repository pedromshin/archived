import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Types } from 'mongoose';

export type RepresentativesDocument = HydratedDocument<Representatives>;

@Schema()
export class Representatives {
  @Prop({ type: [{ type: Types.ObjectId, ref: 'User' }] })
  _userIds: Types.ObjectId[];

  @Prop({ type: Types.ObjectId, ref: 'Subscribable' })
  _subscribableId: Types.ObjectId;
}

export const RepresentativesSchema =
  SchemaFactory.createForClass(Representatives);
