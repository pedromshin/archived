import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Types } from 'mongoose';

export type UserDocument = HydratedDocument<User>;

@Schema()
export class User {
  @Prop({ type: [{ type: Types.ObjectId, ref: 'Subscribable' }] })
  _subscribableIds: Types.ObjectId[];

  @Prop({ type: [{ type: Types.ObjectId, ref: 'Representatives' }] })
  _representativesIds: Types.ObjectId[];

  @Prop({ required: true })
  name: string;

  @Prop({ required: true, unique: true })
  email: string;

  @Prop({ required: true, unique: true })
  phoneNumber: string;

  @Prop({ required: true, unique: true })
  username: string;

  @Prop({ required: true })
  password: string;
}

export const UserSchema = SchemaFactory.createForClass(User);
