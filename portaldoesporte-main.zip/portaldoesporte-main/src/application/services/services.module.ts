import { Module } from '@nestjs/common';
import { UserModule } from './user/user.module';
import { SubscribableModule } from './subscribable/subscribable.module';
import { AthleteModule } from './athlete/athlete.module';
import { SportModule } from './sport/sport.module';
import { PostModule } from './post/post.module';
import { GymModule } from './gym/gym.module';
import { RepresentativesModule } from './representatives/representatives.module';
import { AWSModule } from './aws/aws.module';

@Module({
  imports: [
    UserModule,
    SubscribableModule,
    AthleteModule,
    SportModule,
    PostModule,
    GymModule,
    RepresentativesModule,
    AWSModule,
  ],
})
export class ServicesModule {}
