import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { GymSchema, Gym } from '@schemas/gym.schema';
import { AWSService } from './aws.service';
import { AWSController } from './aws.controller';

@Module({
  imports: [MongooseModule.forFeature([{ name: Gym.name, schema: GymSchema }])],
  controllers: [AWSController],
  providers: [AWSService],
})
export class AWSModule {}
