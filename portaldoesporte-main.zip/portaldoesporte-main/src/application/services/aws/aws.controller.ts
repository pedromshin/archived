import {
  Controller,
  Post,
  UseInterceptors,
  UploadedFile,
  Param,
  Get,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { AWSService } from './aws.service';

@Controller('aws')
export class AWSController {
  constructor(private readonly awsService: AWSService) {}

  @Post('upload/profile-picture/:userId')
  @UseInterceptors(FileInterceptor('file'))
  async uploadProfilePicture(
    @UploadedFile() file: Express.Multer.File,
    @Param('userId') userId: string,
  ) {
    return this.awsService.uploadImage(file, userId);
  }

  @Get('images/profile-picture/:userId')
  async getProfilePicture(@Param('userId') userId: string) {
    const preSignedUrl = await this.awsService.getPreSignedUrl(userId);
    return { preSignedUrl };
  }
}
