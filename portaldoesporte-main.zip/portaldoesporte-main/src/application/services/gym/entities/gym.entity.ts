export class Gym {}
