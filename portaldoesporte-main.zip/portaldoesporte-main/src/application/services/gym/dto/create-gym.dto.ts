export class CreateGymDto {}
