export class CreateAthleteDto {}
