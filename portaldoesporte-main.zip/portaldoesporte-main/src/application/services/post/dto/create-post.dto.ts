import { IsMongoId, IsNotEmpty, IsString, IsIn } from 'class-validator';
import { Types } from 'mongoose';

export class CreatePostDto {
  @IsMongoId()
  _subscribableId: Types.ObjectId;

  @IsString({ each: true })
  @IsIn(['sport', 'athlete', 'gym'], { each: true })
  entity: 'sport' | 'athlete' | 'gym';

  @IsString()
  @IsNotEmpty()
  title: string;

  @IsString()
  @IsNotEmpty()
  content: string;
}
