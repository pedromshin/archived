import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { User, UserSchema } from '@schemas/user.schema';
import { Subscribable, SubscribableSchema } from '@schemas/subscribable.schema';
import { JwtModule } from '@nestjs/jwt';
import {
  Representatives,
  RepresentativesSchema,
} from '@schemas/representatives.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Subscribable.name, schema: SubscribableSchema },
      { name: Representatives.name, schema: RepresentativesSchema },
    ]),
    JwtModule.register({
      secret: String(process.env.JWT_SECRET),
      signOptions: { expiresIn: '1h' },
    }),
  ],
  controllers: [UserController],
  providers: [UserService],
})
export class UserModule {}
