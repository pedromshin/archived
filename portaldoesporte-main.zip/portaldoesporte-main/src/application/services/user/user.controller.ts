import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post()
  create(@Body() createUserDto: CreateUserDto) {
    return this.userService.create(createUserDto);
  }

  @Post('login')
  async login(@Body() body: { username: string; password: string }) {
    const user = await this.userService.login(body.username, body.password);
    if (!user) {
      return { message: 'Invalid credentials' };
    }
    return user;
  }

  @Get()
  findAll() {
    return this.userService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.userService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateUserDto: UpdateUserDto) {
    return this.userService.update(id, updateUserDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.userService.remove(id);
  }

  @Patch(':id/subscribe/:subscribableId')
  subscribe(
    @Param('id') id: string,
    @Param('subscribableId') subscribableId: string,
  ) {
    return this.userService.subscribe(id, subscribableId);
  }

  @Patch(':id/unsubscribe/:subscribableId')
  unsubscribe(
    @Param('id') id: string,
    @Param('subscribableId') subscribableId: string,
  ) {
    return this.userService.unsubscribe(id, subscribableId);
  }

  @Get(':id/represented-subscribables')
  representedSubscribables(@Param('id') id: string) {
    return this.userService.representedSubscribables(id);
  }
}
