import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { Model, Types } from 'mongoose';
import { User } from '@entities/user.entity';
import { InjectModel } from '@nestjs/mongoose';
import { Subscribable } from '@entities/subscribable.entity';
import { compare, hash } from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
import { Representatives } from '@entities/representatives.entity';

@Injectable()
export class UserService {
  constructor(
    @InjectModel(User.name) private readonly userModel: Model<User>,
    @InjectModel(Subscribable.name)
    private readonly subscribableModel: Model<Subscribable>,
    @InjectModel(Representatives.name)
    private readonly representativesModel: Model<Representatives>,
    private readonly jwtService: JwtService,
  ) {}

  async validateUser(username: string, password: string) {
    try {
      const user = await this.userModel.findOne({ username }).exec();
      if (user && (await compare(password, user.password))) {
        const { password, ...result } = user.toObject();
        return result;
      }
      return null;
    } catch (error) {
      throw new HttpException(
        'Failed to validate user',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  async login(username: string, password: string) {
    try {
      const user = await this.validateUser(username, password);
      if (!user) {
        throw new HttpException('Invalid credentials', HttpStatus.UNAUTHORIZED);
      } else {
        try {
          const accessToken = this.jwtService.sign(user);
          return { access_token: accessToken, user };
        } catch (jwtError) {
          console.error('JWT signing error:', jwtError);
          throw new HttpException(
            'Failed to generate token',
            HttpStatus.INTERNAL_SERVER_ERROR,
          );
        }
      }
    } catch (error) {
      console.error('Login error:', error);
      throw new HttpException(
        `Login failed: ${error.message}`,
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  async create(
    createUserDto: CreateUserDto,
  ): Promise<{ access_token: string }> {
    const { username, password } = createUserDto;

    try {
      const existingUser = await this.userModel.findOne({ username });
      if (existingUser) {
        throw new HttpException('User already exists', HttpStatus.CONFLICT);
      }

      const hashedPassword = await hash(password, 10);

      const newUser = new this.userModel({
        ...createUserDto,
        password: hashedPassword,
      });

      await newUser.save();

      return this.login(username, password);
    } catch (error) {
      console.error('Error during registration:', error);
      throw new HttpException(
        'Failed to register user',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  async findAll(): Promise<User[]> {
    try {
      return await this.userModel.find().exec();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  async findOne(id: string): Promise<User> {
    try {
      return await this.userModel.findById(id).exec();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  async update(id: string, updateUserDto: UpdateUserDto): Promise<User> {
    try {
      const result = await this.userModel
        .findByIdAndUpdate(id, updateUserDto, { new: true })
        .exec();
      if (!result) {
        throw new HttpException('Document not found', HttpStatus.NOT_FOUND);
      }
      return result;
    } catch (error) {
      throw new HttpException(
        { status: HttpStatus.BAD_REQUEST, error: 'Error updating document' },
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  async remove(id: string) {
    try {
      return await this.userModel.deleteOne({ _id: id }).exec();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  async subscribe(id: string, subscribableId: string) {
    try {
      const [updatedUser, updatedSubscribable] = await Promise.all([
        this.userModel
          .findByIdAndUpdate(
            id,
            {
              $addToSet: {
                _subscribableIds: new Types.ObjectId(subscribableId),
              },
            },
            { new: true },
          )
          .exec(),
        this.subscribableModel

          .findByIdAndUpdate(
            subscribableId,
            { $addToSet: { _userIds: new Types.ObjectId(id) } },
            { new: true },
          )
          .exec(),
      ]);

      if (!updatedUser || !updatedSubscribable) {
        throw new HttpException('Document not found', HttpStatus.NOT_FOUND);
      }

      return [updatedUser, updatedSubscribable];
    } catch (error) {
      throw new HttpException(
        { status: HttpStatus.BAD_REQUEST, error: 'Error updating document' },
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  async unsubscribe(id: string, subscribableId: string) {
    try {
      const [updatedUser, updatedSubscribable] = await Promise.all([
        this.userModel
          .findByIdAndUpdate(
            id,
            {
              $pull: {
                _subscribableIds: new Types.ObjectId(subscribableId),
              },
            },
            { new: true },
          )
          .exec()
          .then((updatedUser) => {
            return updatedUser;
          }),
        this.subscribableModel
          .findByIdAndUpdate(
            subscribableId,
            { $pull: { _userIds: new Types.ObjectId(id) } },
            { new: true },
          )
          .exec()
          .then((updatedSubscribable) => {
            return updatedSubscribable;
          }),
      ]);

      if (!updatedUser || !updatedSubscribable) {
        throw new HttpException('Document not found', HttpStatus.NOT_FOUND);
      }

      return [updatedUser, updatedSubscribable];
    } catch (error) {
      throw new HttpException(
        { status: HttpStatus.BAD_REQUEST, error: 'Error updating document' },
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  async representedSubscribables(userId: string): Promise<Subscribable[]> {
    try {
      const representatives = await this.representativesModel
        .find({ _userIds: { $in: [new Types.ObjectId(userId)] } })
        .exec();

      const subscribableIds = representatives.map(
        (item) => new Types.ObjectId(item._subscribableId),
      );

      const subscribables = await this.subscribableModel.find({
        _id: { $in: subscribableIds },
      });

      return subscribables;
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }
}
