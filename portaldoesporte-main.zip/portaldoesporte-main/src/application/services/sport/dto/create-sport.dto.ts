export class CreateSportDto {}
