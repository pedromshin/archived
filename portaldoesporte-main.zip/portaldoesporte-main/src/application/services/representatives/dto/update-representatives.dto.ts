import { PartialType } from '@nestjs/mapped-types';
import { CreateRepresentativesDto } from './create-representatives.dto';

export class UpdateRepresentativesDto extends PartialType(
  CreateRepresentativesDto,
) {}
