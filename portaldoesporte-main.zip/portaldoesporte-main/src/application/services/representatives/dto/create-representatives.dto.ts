export class CreateRepresentativesDto {}
