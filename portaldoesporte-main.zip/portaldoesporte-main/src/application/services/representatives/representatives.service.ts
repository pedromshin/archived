import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { CreateRepresentativesDto } from './dto/create-representatives.dto';
import { UpdateRepresentativesDto } from './dto/update-representatives.dto';
import { Model } from 'mongoose';
import { Representatives } from '@entities/representatives.entity';
import { InjectModel } from '@nestjs/mongoose';

@Injectable()
export class RepresentativesService {
  constructor(
    @InjectModel(Representatives.name)
    private readonly representativesModel: Model<Representatives>,
  ) {}

  async create(
    createRepresentativesDto: CreateRepresentativesDto,
  ): Promise<Representatives> {
    try {
      return await this.representativesModel.create(createRepresentativesDto);
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  async findAll(): Promise<Representatives[]> {
    try {
      return await this.representativesModel.find().exec();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  async findOne(id: string): Promise<Representatives> {
    try {
      return await this.representativesModel.findById(id).exec();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  async update(
    id: string,
    updateRepresentativesDto: UpdateRepresentativesDto,
  ): Promise<Representatives> {
    try {
      const result = await this.representativesModel
        .findByIdAndUpdate(id, updateRepresentativesDto, { new: true })
        .exec();
      if (!result) {
        throw new HttpException('Document not found', HttpStatus.NOT_FOUND);
      }
      return result;
    } catch (error) {
      throw new HttpException(
        { status: HttpStatus.BAD_REQUEST, error: 'Error updating document' },
        HttpStatus.BAD_REQUEST,
      );
    }
  }

  async remove(id: string) {
    try {
      return await this.representativesModel.deleteOne({ _id: id }).exec();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }
}
