import { Module } from '@nestjs/common';
import { RepresentativesService } from './representatives.service';
import { RepresentativesController } from './representatives.controller';
import { MongooseModule } from '@nestjs/mongoose';
import {
  RepresentativesSchema,
  Representatives,
} from '@schemas/representatives.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Representatives.name, schema: RepresentativesSchema },
    ]),
  ],
  controllers: [RepresentativesController],
  providers: [RepresentativesService],
})
export class RepresentativesModule {}
