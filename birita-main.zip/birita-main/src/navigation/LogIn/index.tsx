import React from "react";
import {
  Pressable,
  SafeAreaView,
  StyleSheet,
  useWindowDimensions,
} from "react-native";

import { RootStackScreenProps } from "../../../types";
import CustomInput from "../../components/Input";

import { Text, View } from "../../components/Themed";
import { EMAIL_REGEX } from "../../utils/regex";

import { useForm } from "react-hook-form";

export default function Login({ navigation }: RootStackScreenProps<"Login">) {
  const { height } = useWindowDimensions();
  const { control, handleSubmit, watch } = useForm();

  return (
    <SafeAreaView style={styles.container}>
      <View style={{ ...styles.header, height: height * 0.23 }}>
        <Text style={styles.title}>Acesse sua conta</Text>
      </View>
      <View style={styles.content}>
        <View style={styles.wrapper}>
          <CustomInput
            name="email"
            control={control}
            placeholder="Email"
            rules={{
              required: "Email is required",
              pattern: { value: EMAIL_REGEX, message: "Email is invalid" },
            }}
          />
          <Pressable onPress={() => navigation.navigate("Signup")}>
            <Text style={styles.createAccountButton}>Criar uma conta</Text>
          </Pressable>
          <Pressable
            onPress={() => navigation.navigate("Login")}
            style={styles.primaryButton}
          >
            <Text style={styles.primaryButtonText}>Entrar</Text>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    backgroundColor: "#FFFFF",
    justifyContent: "center",
    paddingLeft: 28,
  },
  title: {
    fontWeight: "700",
    fontSize: 32,
  },
  content: {
    backgroundColor: "#FFD234",
    height: "100%",
    alignItems: "center",
  },
  wrapper: {
    maxWidth: "80%",
    height: "100%",
    alignItems: "center",
    justifyContent: "space-evenly",
    backgroundColor: "transparent",
    paddingBottom: 70,
  },
  createAccountButton: {
    color: "#000000",
    fontWeight: "700",
    fontSize: 16,
  },
  primaryButton: {
    backgroundColor: "#000",
    width: 233,
    height: 62,
    borderRadius: 75,
    alignItems: "center",
    justifyContent: "center",
  },
  primaryButtonText: {
    color: "#FFFFFF",
    fontWeight: "700",
    fontSize: 24,
  },
});
