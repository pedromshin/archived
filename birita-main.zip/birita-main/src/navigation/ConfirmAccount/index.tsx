import React, { BaseSyntheticEvent } from "react";
import {
  Alert,
  Pressable,
  SafeAreaView,
  StyleSheet,
  useWindowDimensions,
} from "react-native";

import { RootStackScreenProps } from "../../../types";
import CustomInput from "../../components/Input";

import { Text, View } from "../../components/Themed";
import { useForm } from "react-hook-form";
import { Auth } from "aws-amplify";

export default function ConfirmAccount({
  navigation,
  route,
}: RootStackScreenProps<"ConfirmAccount">) {
  const { height } = useWindowDimensions();
  const { control, handleSubmit, watch } = useForm();

  const onRegisterPressed = async (data: any) => {
    const { otp } = data;
    try {
      await Auth.confirmSignUp(route.params?.email, otp);

      navigation.navigate("Root");
    } catch (e) {
      console.log("erro");
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={{ ...styles.header, height: height * 0.23 }}>
        <Text style={styles.title}>Confirme o código</Text>
      </View>
      <View style={styles.content}>
        <View style={styles.wrapper}>
          <View style={styles.formContainer}>
            <CustomInput
              name="otp"
              control={control}
              placeholder="digite o código aqui"
            />
          </View>
          <View style={styles.divisor}>
            <View style={styles.line} />
            <Text style={{ marginHorizontal: 10 }}>ou</Text>
            <View style={styles.line} />
          </View>
          <Pressable onPress={() => navigation.navigate("Signup")}>
            <Text style={styles.loginButton}>voltar</Text>
          </Pressable>
          <Pressable
            onPress={handleSubmit(onRegisterPressed)}
            style={styles.primaryButton}
          >
            <Text style={styles.primaryButtonText}>Confirmar</Text>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    backgroundColor: "#FFFFF",
    justifyContent: "center",
    paddingLeft: 28,
  },
  title: {
    fontWeight: "700",
    fontSize: 32,
  },
  content: {
    backgroundColor: "#FFD234",
    height: "100%",
    alignItems: "center",
  },
  wrapper: {
    maxWidth: "80%",
    height: "100%",
    alignItems: "center",
    justifyContent: "space-evenly",
    backgroundColor: "transparent",
    paddingBottom: 120,
  },
  divisor: {
    display: "flex",
    flexDirection: "row",
    backgroundColor: "transparent",
    alignItems: "center",
  },
  line: {
    width: 80,
    height: 1,
    backgroundColor: "#000000",
  },
  formContainer: {
    backgroundColor: "transparent",
  },
  loginButton: {
    color: "#000000",
    fontWeight: "700",
    fontSize: 16,
  },
  primaryButton: {
    backgroundColor: "#000",
    width: 233,
    height: 62,
    borderRadius: 75,
    alignItems: "center",
    justifyContent: "center",
  },
  primaryButtonText: {
    color: "#FFFFFF",
    fontWeight: "700",
    fontSize: 24,
  },
});
