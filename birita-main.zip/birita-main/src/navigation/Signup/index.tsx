import React, { useState } from "react";
import {
  Alert,
  Pressable,
  SafeAreaView,
  StyleSheet,
  useWindowDimensions,
} from "react-native";

import { RootStackScreenProps } from "../../../types";
import CustomInput from "../../components/Input";

import { Text, View } from "../../components/Themed";
import { EMAIL_REGEX, TELEPHONE_REGEX } from "../../utils/regex";
import { useForm } from "react-hook-form";
import { Auth } from "aws-amplify";

export default function Signup({ navigation }: RootStackScreenProps<"Signup">) {
  const { height } = useWindowDimensions();
  const { control, handleSubmit, watch } = useForm();
  const [inputType, setInputType] = useState<"email" | "telephone">("email");

  const onRegisterPressed = async (data: any) => {
    const { password, email, name, birthdate, telephone } = data;
    try {
      await Auth.signUp({
        username: email,
        password,
        attributes: {
          email,
          name,
          preferred_username: email,
          birthdate: birthdate,
          phone_number: "+18885551234",
        },
      });

      navigation.navigate("ConfirmAccount", { email: email });
    } catch (e: any) {
      console.log("erro", e);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={{ ...styles.header, height: height * 0.23 }}>
        <Text style={styles.title}>Crie sua conta</Text>
      </View>
      <View style={styles.content}>
        <View style={styles.wrapper}>
          <View style={styles.formContainer}>
            {inputType === "email" && (
              <CustomInput
                name="email"
                control={control}
                placeholder="e-mail"
                rules={{
                  required: "Insira um e-mail ou telefone",
                  pattern: {
                    value: EMAIL_REGEX,
                    message: "O e-mail não está no formato correto!",
                  },
                }}
              />
            )}
            {inputType === "telephone" && (
              <CustomInput
                name="telephone"
                control={control}
                placeholder="telefone"
                rules={{
                  required: "Insira um número de telefone",
                  pattern: {
                    value: TELEPHONE_REGEX,
                    message: "O telefone não está no formato correto!",
                  },
                }}
              />
            )}
            <Pressable
              onPress={() =>
                setInputType(inputType === "email" ? "telephone" : "email")
              }
            >
              <Text>usar {inputType === "email" ? "telefone" : "e-mail"}</Text>
            </Pressable>
            <CustomInput
              name="password"
              control={control}
              placeholder="crie uma senha"
              secureTextEntry
              rules={{
                required: "Digite uma senha",
              }}
              customStyle={{ marginTop: 48 }}
            />
            <CustomInput
              name="birthdate"
              control={control}
              placeholder="Data de nascimento"
              rules={{
                required: "Sua data de nascimento",
              }}
              customStyle={{ marginTop: 48 }}
            />
          </View>
          <View style={styles.divisor}>
            <View style={styles.line} />
            <Text style={{ marginHorizontal: 10 }}>ou</Text>
            <View style={styles.line} />
          </View>
          <Pressable onPress={() => navigation.navigate("Login")}>
            <Text style={styles.loginButton}>fazer login</Text>
          </Pressable>
          <Pressable
            onPress={handleSubmit(onRegisterPressed)}
            style={styles.primaryButton}
          >
            <Text style={styles.primaryButtonText}>Continuar</Text>
          </Pressable>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    backgroundColor: "#FFFFF",
    justifyContent: "center",
    paddingLeft: 28,
  },
  title: {
    fontWeight: "700",
    fontSize: 32,
  },
  content: {
    backgroundColor: "#FFD234",
    height: "100%",
    alignItems: "center",
  },
  wrapper: {
    maxWidth: "80%",
    height: "100%",
    alignItems: "center",
    justifyContent: "space-evenly",
    backgroundColor: "transparent",
    paddingBottom: 120,
  },
  divisor: {
    display: "flex",
    flexDirection: "row",
    backgroundColor: "transparent",
    alignItems: "center",
  },
  line: {
    width: 80,
    height: 1,
    backgroundColor: "#000000",
  },
  formContainer: {
    backgroundColor: "transparent",
  },
  loginButton: {
    color: "#000000",
    fontWeight: "700",
    fontSize: 16,
  },
  primaryButton: {
    backgroundColor: "#000",
    width: 233,
    height: 62,
    borderRadius: 75,
    alignItems: "center",
    justifyContent: "center",
  },
  primaryButtonText: {
    color: "#FFFFFF",
    fontWeight: "700",
    fontSize: 24,
  },
});
