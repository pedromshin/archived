import * as React from "react";
import { useEffect, useState } from "react";

import {
  NavigationContainer,
  DefaultTheme,
  DarkTheme,
} from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { ActivityIndicator, ColorSchemeName } from "react-native";

import ModalScreen from "./Modal/ModalScreen";
import NotFoundScreen from "./NotFound";

import { RootStackParamList } from "../../types";
import LinkingConfiguration from "./LinkingConfiguration";
import Main from "./Main";
import Signup from "./Signup";
import { View } from "../components/Themed";

import { Auth, Hub } from "aws-amplify";
import { HubCapsule } from "@aws-amplify/core";
import Login from "./LogIn";
import ConfirmAccount from "./ConfirmAccount";

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function Navigation({
  colorScheme,
}: {
  colorScheme: ColorSchemeName;
}) {
  const [user, setUser] = useState(undefined);
  const [loading, setLoading] = useState(false);

  const checkUser = async () => {
    try {
      setLoading(true);
      const authUser = await Auth.currentAuthenticatedUser({
        bypassCache: true,
      });
      setLoading(false);
      setUser(authUser);
    } catch (e) {
      setLoading(false);
      setUser(undefined);
    }
  };

  useEffect(() => {
    checkUser();
  }, []);

  useEffect(() => {
    const listener = (data: HubCapsule) => {
      console.log(data);
      if (data.payload.event === "signIn" || data.payload.event === "signOut") {
        checkUser();
      }
    };

    Hub.listen("auth", listener);
    return () => Hub.remove("auth", listener);
  }, []);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator />
      </View>
    );
  }

  return (
    <NavigationContainer
      linking={LinkingConfiguration}
      theme={colorScheme === "dark" ? DarkTheme : DefaultTheme}
    >
      <Stack.Navigator>
        {user ? (
          <Stack.Screen
            name="Root"
            component={Main}
            options={{ headerShown: false }}
          />
        ) : (
          <>
            <Stack.Screen
              name="Signup"
              component={Signup}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Login"
              component={Login}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ConfirmAccount"
              component={ConfirmAccount}
              options={{ headerShown: false }}
            />
          </>
        )}
        <Stack.Screen
          name="NotFound"
          component={NotFoundScreen}
          options={{ title: "Oops!" }}
        />
        <Stack.Group screenOptions={{ presentation: "modal" }}>
          <Stack.Screen name="Modal" component={ModalScreen} />
        </Stack.Group>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
