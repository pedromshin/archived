import { ThemeCustomizer } from "./theme-customizer";

export async function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-screen-2xl items-center justify-between">
        <div className="absolute left-2/4 right-2/4 col-span-6 mx-auto hidden flex-1 items-center justify-center gap-x-2 lg:flex">
          {/* <ClientMutedLinkButton items={desktopNavbarLinks(username || '')} /> */}
        </div>
        <div className="flex flex-1 items-center justify-end space-x-2 lg:flex-none">
          <nav className="flex items-center gap-2">
            <div className={`ms-auto flex items-center gap-x-3 md:col-span-3`}>
              <ThemeCustomizer />
              {/* {user ? (
                <div className='flex flex-row items-center gap-4 lg:hidden'>
                  <MobileMenuNotifications />
                  <MenuMessages
                    trigger={
                      <SheetTrigger asChild>
                        <MessageCircle className='h-[1.4rem] w-[1.4rem]' />
                      </SheetTrigger>
                    }
                  />
                </div>
                <></>
              ) : (
                <div className='flex items-center gap-x-2'>
                  <Button asChild>
                    <LoginLink target='_blank'>login</LoginLink>
                  </Button>
                  <Button variant='secondary' asChild>
                    <RegisterLink target='_blank'>register</RegisterLink>
                  </Button>
                </div>
              )} */}
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}
