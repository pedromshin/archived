"use client";

import * as React from "react";
import { CheckIcon, MoonIcon, SunIcon } from "@radix-ui/react-icons";
import { useTheme } from "next-themes";

import { Button } from "@venda/ui/button";
import { cn } from "@venda/ui/components/cn";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@venda/ui/components/dropdown-menu";
import { Skeleton } from "@venda/ui/components/skeleton";
import { useConfig } from "@venda/ui/hooks/use-config";
import { baseColors } from "@venda/ui/registry/index";

export function ThemeCustomizer() {
  const { setTheme, resolvedTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);
  const [config, setConfig] = useConfig();

  React.useEffect(() => {
    setMounted(true);
  }, []);

  // Function to toggle between light and dark mode
  const toggleMode = () => {
    setTheme(resolvedTheme === "light" ? "dark" : "light");
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-8 w-8 px-0">
          <SunIcon className="h-[1.6rem] w-[1.6rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
          <MoonIcon className="absolute h-[1.6rem] w-[1.6rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          <span className="sr-only">Toggle theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <div className="p-1">
          <div className="flex items-center justify-between">
            <span className="text-sm">Mode</span>
            <Button
              variant="outline"
              size="sm"
              onClick={toggleMode}
              className={cn(
                resolvedTheme === "light" ? "border-2 border-primary" : "",
              )}
            >
              {resolvedTheme === "light" ? (
                <SunIcon className="mr-1" />
              ) : (
                <MoonIcon className="mr-1" />
              )}
              {resolvedTheme === "light" ? "Light" : "Dark"}
            </Button>
          </div>
          {mounted && (
            <div className="space-y-1">
              <span className="text-sm">Colors</span>
              <div className="grid grid-cols-3 gap-2">
                {baseColors.map((theme) => {
                  const isActive = config.theme === theme.name;

                  return mounted ? (
                    <Button
                      variant={"outline"}
                      size="sm"
                      key={theme.name}
                      onClick={() => {
                        setConfig({
                          ...config,
                          theme: theme.name,
                        });
                      }}
                      className={cn(
                        "justify-start",
                        isActive && "border-2 border-primary",
                      )}
                      style={
                        {
                          "--theme-primary": `hsl(${
                            theme?.activeColor[
                              resolvedTheme === "dark" ? "dark" : "light"
                            ]
                          })`,
                        } as React.CSSProperties
                      }
                    >
                      <span
                        className={cn(
                          "mr-1 flex h-5 w-5 shrink-0 -translate-x-1 items-center justify-center rounded-full bg-[--theme-primary]",
                        )}
                      >
                        {isActive && (
                          <CheckIcon className="h-4 w-4 text-white" />
                        )}
                      </span>
                      {theme.label}
                    </Button>
                  ) : (
                    <Skeleton className="h-8 w-full" key={theme.name} />
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
