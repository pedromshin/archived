import Link from "next/link";

import { Button } from "@venda/ui/components/index";
import { structuredData } from "@venda/ui/config/site";

export default async function LandingPage() {
  return (
    <main>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />
      <section className="max-w-8xl mx-auto mb-16 mt-8 px-4 md:mt-24 md:px-8">
        <div className="mx-auto max-w-5xl text-center text-5xl font-semibold sm:text-5xl lg:text-7xl">
          <h1>connect with friends</h1>
          <h1 className="text-primary">
            <span className="text-foreground">+</span> earn money{" "}
          </h1>
          <h1 className="text-primary">
            <span className="text-foreground">+</span> reduce trash
          </h1>
          <p className="mx-auto mt-8 w-[90%] text-lg font-normal text-muted-foreground lg:text-2xl">
            <span className="text-primary">venda</span>. is a{" "}
            <span className="text-primary">social marketplace</span> on a
            mission to <span className="text-primary">reduce waste</span> and{" "}
            <span className="text-primary">raise income</span> by enabling
            people to offer unused goods to friends and family.
          </p>
        </div>
        <div className="mt-16 text-center">
          {/* <RegisterLink
            target='_blank'
            className='hover:bg-primary-dark inline-block rounded-lg bg-primary px-4 py-2 text-base text-lg font-semibold text-primary-foreground transition'
          > */}
          <Link href={"/search"}>
            <Button className="p-6 text-xl">get started!</Button>
          </Link>
          {/* </RegisterLink> */}
        </div>
      </section>
      <section className="mx-auto mb-16 max-w-7xl px-4 md:mt-24 md:px-8">
        <h2 className="mb-8 text-center text-4xl font-semibold">
          how it works
        </h2>
        <div className="flex flex-col items-center justify-around gap-4 lg:flex-row">
          <div className="mb-8 flex-1 text-center lg:mb-0 lg:text-left">
            <h3 className="mb-2 text-2xl font-semibold">
              1.{" "}
              <span className="text-primary">
                connect with friends and family
              </span>
            </h3>
            <p className="text-lg text-muted-foreground">
              add people you trust to your network.
            </p>
          </div>
          <div className="mb-8 flex-1 text-center lg:mb-0 lg:text-left">
            <h3 className="mb-2 text-2xl font-semibold">
              2.<span className="text-primary"> post your items for sale </span>
            </h3>
            <p className="text-lg text-muted-foreground">
              receive offers from people interested in your items.
            </p>
          </div>
          <div className="flex-1 text-center lg:text-left">
            <h3 className="mb-2 text-2xl font-semibold">
              3.<span className="text-primary"> receive offers</span>
            </h3>
            <p className="text-lg text-muted-foreground">
              accept or refuse offers, earn money, reduce trash.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
