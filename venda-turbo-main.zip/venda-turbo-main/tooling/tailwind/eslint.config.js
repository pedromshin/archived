// FIXME: This kinda stinks...
/// <reference types="../../tooling/eslint/types.d.ts" />

import baseConfig from "@venda/eslint-config/base";

export default [...baseConfig];
