import { useAtom } from "jotai";
import { atomWithStorage } from "jotai/utils";

import { BaseColor, Style } from "../registry";

type Config = {
  style: Style["name"];
  theme: BaseColor["name"];
  radius: number;
};

const configAtom = atomWithStorage<Config>("config", {
  style: "new-york",
  theme: "green",
  radius: 0.5,
});

export function useConfig() {
  return useAtom(configAtom);
}
