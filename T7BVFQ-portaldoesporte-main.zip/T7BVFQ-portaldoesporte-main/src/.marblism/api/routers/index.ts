/* eslint-disable */
import type { unsetMarker, AnyRouter, AnyRootConfig, CreateRouterInner, Procedure, ProcedureBuilder, ProcedureParams, ProcedureRouterRecord, ProcedureType } from "@trpc/server";
import type { PrismaClient } from "@prisma/client";
import createAccountRouter from "./Account.router";
import createUserRouter from "./User.router";
import createSessionRouter from "./Session.router";
import createRoleRouter from "./Role.router";
import createPostDataRouter from "./PostData.router";
import createCommentRouter from "./Comment.router";
import createLikeRouter from "./Like.router";
import createEventRouter from "./Event.router";
import createSubscriptionRouter from "./Subscription.router";
import createAdvertisementRouter from "./Advertisement.router";
import createProductRouter from "./Product.router";
import createOrderRouter from "./Order.router";
import createSettingRouter from "./Setting.router";
import { ClientType as AccountClientType } from "./Account.router";
import { ClientType as UserClientType } from "./User.router";
import { ClientType as SessionClientType } from "./Session.router";
import { ClientType as RoleClientType } from "./Role.router";
import { ClientType as PostDataClientType } from "./PostData.router";
import { ClientType as CommentClientType } from "./Comment.router";
import { ClientType as LikeClientType } from "./Like.router";
import { ClientType as EventClientType } from "./Event.router";
import { ClientType as SubscriptionClientType } from "./Subscription.router";
import { ClientType as AdvertisementClientType } from "./Advertisement.router";
import { ClientType as ProductClientType } from "./Product.router";
import { ClientType as OrderClientType } from "./Order.router";
import { ClientType as SettingClientType } from "./Setting.router";

export type BaseConfig = AnyRootConfig;

export type RouterFactory<Config extends BaseConfig> = <
    ProcRouterRecord extends ProcedureRouterRecord
>(
    procedures: ProcRouterRecord
) => CreateRouterInner<Config, ProcRouterRecord>;

export type UnsetMarker = typeof unsetMarker;

export type ProcBuilder<Config extends BaseConfig> = ProcedureBuilder<
    ProcedureParams<Config, any, any, any, UnsetMarker, UnsetMarker, any>
>;

export function db(ctx: any) {
    if (!ctx.prisma) {
        throw new Error('Missing "prisma" field in trpc context');
    }
    return ctx.prisma as PrismaClient;
}

export function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({
        account: createAccountRouter(router, procedure),
        user: createUserRouter(router, procedure),
        session: createSessionRouter(router, procedure),
        role: createRoleRouter(router, procedure),
        postData: createPostDataRouter(router, procedure),
        comment: createCommentRouter(router, procedure),
        like: createLikeRouter(router, procedure),
        event: createEventRouter(router, procedure),
        subscription: createSubscriptionRouter(router, procedure),
        advertisement: createAdvertisementRouter(router, procedure),
        product: createProductRouter(router, procedure),
        order: createOrderRouter(router, procedure),
        setting: createSettingRouter(router, procedure),
    }
    );
}

export interface ClientType<AppRouter extends AnyRouter> {
    account: AccountClientType<AppRouter>;
    user: UserClientType<AppRouter>;
    session: SessionClientType<AppRouter>;
    role: RoleClientType<AppRouter>;
    postData: PostDataClientType<AppRouter>;
    comment: CommentClientType<AppRouter>;
    like: LikeClientType<AppRouter>;
    event: EventClientType<AppRouter>;
    subscription: SubscriptionClientType<AppRouter>;
    advertisement: AdvertisementClientType<AppRouter>;
    product: ProductClientType<AppRouter>;
    order: OrderClientType<AppRouter>;
    setting: SettingClientType<AppRouter>;
}
