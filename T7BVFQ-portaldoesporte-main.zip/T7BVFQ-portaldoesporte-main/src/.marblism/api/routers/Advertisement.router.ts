/* eslint-disable */
import { type RouterFactory, type ProcBuilder, type BaseConfig, db } from ".";
import * as _Schema from '@zenstackhq/runtime/zod/input';
const $Schema: typeof _Schema = (_Schema as any).default ?? _Schema;
import { checkRead, checkMutate } from '../helper';
import type { Prisma } from '@prisma/client';
import type { UseTRPCMutationOptions, UseTRPCMutationResult, UseTRPCQueryOptions, UseTRPCQueryResult, UseTRPCInfiniteQueryOptions, UseTRPCInfiniteQueryResult } from '@trpc/react-query/shared';
import type { TRPCClientErrorLike } from '@trpc/client';
import type { AnyRouter } from '@trpc/server';

export default function createRouter<Config extends BaseConfig>(router: RouterFactory<Config>, procedure: ProcBuilder<Config>) {
    return router({

        createMany: procedure.input($Schema.AdvertisementInputSchema.createMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).advertisement.createMany(input as any))),

        create: procedure.input($Schema.AdvertisementInputSchema.create).mutation(async ({ ctx, input }) => checkMutate(db(ctx).advertisement.create(input as any))),

        deleteMany: procedure.input($Schema.AdvertisementInputSchema.deleteMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).advertisement.deleteMany(input as any))),

        delete: procedure.input($Schema.AdvertisementInputSchema.delete).mutation(async ({ ctx, input }) => checkMutate(db(ctx).advertisement.delete(input as any))),

        findFirst: procedure.input($Schema.AdvertisementInputSchema.findFirst).query(({ ctx, input }) => checkRead(db(ctx).advertisement.findFirst(input as any))),

        findMany: procedure.input($Schema.AdvertisementInputSchema.findMany).query(({ ctx, input }) => checkRead(db(ctx).advertisement.findMany(input as any))),

        findUnique: procedure.input($Schema.AdvertisementInputSchema.findUnique).query(({ ctx, input }) => checkRead(db(ctx).advertisement.findUnique(input as any))),

        updateMany: procedure.input($Schema.AdvertisementInputSchema.updateMany).mutation(async ({ ctx, input }) => checkMutate(db(ctx).advertisement.updateMany(input as any))),

        update: procedure.input($Schema.AdvertisementInputSchema.update).mutation(async ({ ctx, input }) => checkMutate(db(ctx).advertisement.update(input as any))),

    }
    );
}

export interface ClientType<AppRouter extends AnyRouter, Context = AppRouter['_def']['_config']['$types']['ctx']> {
    createMany: {

        useMutation: <T extends Prisma.AdvertisementCreateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.AdvertisementCreateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.AdvertisementCreateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.AdvertisementCreateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    create: {

        useMutation: <T extends Prisma.AdvertisementCreateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.AdvertisementCreateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.AdvertisementGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.AdvertisementGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.AdvertisementCreateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.AdvertisementCreateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.AdvertisementGetPayload<T>, Context>) => Promise<Prisma.AdvertisementGetPayload<T>>
            };

    };
    deleteMany: {

        useMutation: <T extends Prisma.AdvertisementDeleteManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.AdvertisementDeleteManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.AdvertisementDeleteManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.AdvertisementDeleteManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    delete: {

        useMutation: <T extends Prisma.AdvertisementDeleteArgs>(opts?: UseTRPCMutationOptions<
            Prisma.AdvertisementDeleteArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.AdvertisementGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.AdvertisementGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.AdvertisementDeleteArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.AdvertisementDeleteArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.AdvertisementGetPayload<T>, Context>) => Promise<Prisma.AdvertisementGetPayload<T>>
            };

    };
    findFirst: {

        useQuery: <T extends Prisma.AdvertisementFindFirstArgs, TData = Prisma.AdvertisementGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.AdvertisementFindFirstArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.AdvertisementGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.AdvertisementFindFirstArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.AdvertisementFindFirstArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.AdvertisementGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.AdvertisementGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findMany: {

        useQuery: <T extends Prisma.AdvertisementFindManyArgs, TData = Array<Prisma.AdvertisementGetPayload<T>>>(
            input: Prisma.SelectSubset<T, Prisma.AdvertisementFindManyArgs>,
            opts?: UseTRPCQueryOptions<string, T, Array<Prisma.AdvertisementGetPayload<T>>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.AdvertisementFindManyArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.AdvertisementFindManyArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Array<Prisma.AdvertisementGetPayload<T>>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Array<Prisma.AdvertisementGetPayload<T>>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    findUnique: {

        useQuery: <T extends Prisma.AdvertisementFindUniqueArgs, TData = Prisma.AdvertisementGetPayload<T>>(
            input: Prisma.SelectSubset<T, Prisma.AdvertisementFindUniqueArgs>,
            opts?: UseTRPCQueryOptions<string, T, Prisma.AdvertisementGetPayload<T>, TData, Error>
        ) => UseTRPCQueryResult<
            TData,
            TRPCClientErrorLike<AppRouter>
        >;
        useInfiniteQuery: <T extends Prisma.AdvertisementFindUniqueArgs>(
            input: Omit<Prisma.SelectSubset<T, Prisma.AdvertisementFindUniqueArgs>, 'cursor'>,
            opts?: UseTRPCInfiniteQueryOptions<string, T, Prisma.AdvertisementGetPayload<T>, Error>
        ) => UseTRPCInfiniteQueryResult<
            Prisma.AdvertisementGetPayload<T>,
            TRPCClientErrorLike<AppRouter>
        >;

    };
    updateMany: {

        useMutation: <T extends Prisma.AdvertisementUpdateManyArgs>(opts?: UseTRPCMutationOptions<
            Prisma.AdvertisementUpdateManyArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.BatchPayload,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.BatchPayload, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.AdvertisementUpdateManyArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.AdvertisementUpdateManyArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.BatchPayload, Context>) => Promise<Prisma.BatchPayload>
            };

    };
    update: {

        useMutation: <T extends Prisma.AdvertisementUpdateArgs>(opts?: UseTRPCMutationOptions<
            Prisma.AdvertisementUpdateArgs,
            TRPCClientErrorLike<AppRouter>,
            Prisma.AdvertisementGetPayload<T>,
            Context
        >,) =>
            Omit<UseTRPCMutationResult<Prisma.AdvertisementGetPayload<T>, TRPCClientErrorLike<AppRouter>, Prisma.SelectSubset<T, Prisma.AdvertisementUpdateArgs>, Context>, 'mutateAsync'> & {
                mutateAsync:
                <T extends Prisma.AdvertisementUpdateArgs>(variables: T, opts?: UseTRPCMutationOptions<T, TRPCClientErrorLike<AppRouter>, Prisma.AdvertisementGetPayload<T>, Context>) => Promise<Prisma.AdvertisementGetPayload<T>>
            };

    };
}
