'use client'

import { Typography, Row, Col, Card, Spin } from 'antd'
import { UserOutlined, TrophyOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function AthleteDashboardPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const { data: athleteData, isLoading: isAthleteLoading } =
    Api.user.findUnique.useQuery({
      where: { id: user?.id },
      include: {
        posts: true,
        eventsAsOrganizer: true,
        subscriptions: true,
      },
    })

  if (isAthleteLoading) {
    return (
      <PageLayout layout="narrow">
        <Spin size="large" />
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Athlete Dashboard</Title>
      <Text>
        Track your performance and achievements, and connect with other athletes
        and organizations.
      </Text>

      <Row gutter={[16, 16]} style={{ marginTop: '20px' }}>
        <Col span={24}>
          <Card
            title="Performance and Achievements"
            bordered={false}
            icon={<TrophyOutlined />}
          >
            {athleteData?.posts?.length > 0 ? (
              athleteData.posts.map(post => (
                <Card
                  key={post.id}
                  type="inner"
                  title={dayjs(post.datePosted).format('MMMM D, YYYY')}
                >
                  <Text>{post.content}</Text>
                </Card>
              ))
            ) : (
              <Text>No performance data available.</Text>
            )}
          </Card>
        </Col>
        <Col span={24}>
          <Card title="Network" bordered={false} icon={<UserOutlined />}>
            {athleteData?.eventsAsOrganizer?.length > 0 ? (
              athleteData.eventsAsOrganizer.map(event => (
                <Card key={event.id} type="inner" title={event.name}>
                  <Text>{event.description}</Text>
                  <br />
                  <Text>{dayjs(event.date).format('MMMM D, YYYY')}</Text>
                </Card>
              ))
            ) : (
              <Text>No events organized yet.</Text>
            )}
          </Card>
        </Col>
      </Row>
    </PageLayout>
  )
}
