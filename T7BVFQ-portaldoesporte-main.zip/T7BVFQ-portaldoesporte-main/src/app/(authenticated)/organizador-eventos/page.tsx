'use client'

import { useState, useEffect } from 'react'
import { Prisma } from '@prisma/client'
import {
  Typography,
  Button,
  Form,
  Input,
  DatePicker,
  Space,
  Table,
  Popconfirm,
  Row,
  Col,
} from 'antd'
import { PlusOutlined, DeleteOutlined, EditOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function EventOrganizerDashboardPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const [events, setEvents] = useState<
    Prisma.EventGetPayload<{ include: { organizer: true } }>[] | null
  >(null)
  const [editingEvent, setEditingEvent] = useState<Prisma.EventGetPayload<{
    include: { organizer: true }
  }> | null>(null)
  const [form] = Form.useForm()

  const {
    data: fetchedEvents,
    isLoading,
    refetch,
  } = Api.event.findMany.useQuery({
    where: { organizerId: user?.id },
    include: { organizer: true },
  })

  const { mutateAsync: createEvent } = Api.event.create.useMutation()
  const { mutateAsync: updateEvent } = Api.event.update.useMutation()
  const { mutateAsync: deleteEvent } = Api.event.delete.useMutation()

  useEffect(() => {
    if (fetchedEvents) {
      setEvents(fetchedEvents)
    }
  }, [fetchedEvents])

  const handleCreateOrUpdateEvent = async (values: any) => {
    try {
      if (editingEvent) {
        await updateEvent({ where: { id: editingEvent.id }, data: values })
        enqueueSnackbar('Event updated successfully', { variant: 'success' })
      } else {
        await createEvent({ data: { ...values, organizerId: user?.id } })
        enqueueSnackbar('Event created successfully', { variant: 'success' })
      }
      form.resetFields()
      setEditingEvent(null)
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to save event', { variant: 'error' })
    }
  }

  const handleEditEvent = (
    event: Prisma.EventGetPayload<{ include: { organizer: true } }>,
  ) => {
    setEditingEvent(event)
    form.setFieldsValue({ ...event, date: dayjs(event.date) })
  }

  const handleDeleteEvent = async (id: string) => {
    try {
      await deleteEvent({ where: { id } })
      enqueueSnackbar('Event deleted successfully', { variant: 'success' })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to delete event', { variant: 'error' })
    }
  }

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description',
    },
    {
      title: 'Date',
      dataIndex: 'date',
      key: 'date',
      render: (date: string) => dayjs(date).format('YYYY-MM-DD'),
    },
    {
      title: 'Location',
      dataIndex: 'location',
      key: 'location',
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (
        _: any,
        record: Prisma.EventGetPayload<{ include: { organizer: true } }>,
      ) => (
        <Space size="middle">
          <Button
            icon={<EditOutlined />}
            onClick={() => handleEditEvent(record)}
          >
            Edit
          </Button>
          <Popconfirm
            title="Are you sure to delete this event?"
            onConfirm={() => handleDeleteEvent(record.id)}
          >
            <Button icon={<DeleteOutlined />} danger>
              Delete
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ]

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Event Organizer Dashboard</Title>
      <Paragraph>
        Manage your events and view their performance analytics.
      </Paragraph>
      <Row gutter={16}>
        <Col span={24}>
          <Form
            form={form}
            layout="vertical"
            onFinish={handleCreateOrUpdateEvent}
          >
            <Form.Item
              name="name"
              label="Event Name"
              rules={[
                { required: true, message: 'Please input the event name!' },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="description"
              label="Description"
              rules={[
                {
                  required: true,
                  message: 'Please input the event description!',
                },
              ]}
            >
              <Input.TextArea />
            </Form.Item>
            <Form.Item
              name="date"
              label="Date"
              rules={[
                { required: true, message: 'Please select the event date!' },
              ]}
            >
              <DatePicker />
            </Form.Item>
            <Form.Item
              name="location"
              label="Location"
              rules={[
                { required: true, message: 'Please input the event location!' },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" icon={<PlusOutlined />}>
                {editingEvent ? 'Update Event' : 'Create Event'}
              </Button>
            </Form.Item>
          </Form>
        </Col>
        <Col span={24}>
          <Table
            columns={columns}
            dataSource={events || []}
            rowKey="id"
            loading={isLoading}
          />
        </Col>
      </Row>
    </PageLayout>
  )
}
