'use client'

import { useState } from 'react'
import { Typography, Form, Input, Button, Upload, Space } from 'antd'
import { UploadOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function CreatePostPage() {
  const router = useRouter()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const { mutateAsync: createPost } = Api.post.create.useMutation()
  const { mutateAsync: upload } = useUploadPublic()

  const [form] = Form.useForm()
  const [fileList, setFileList] = useState([])

  const handleUpload = async ({ file }) => {
    try {
      const response = await upload({ file })
      return response.url
    } catch (error) {
      enqueueSnackbar('Failed to upload file', { variant: 'error' })
      return null
    }
  }

  const handleSubmit = async values => {
    try {
      const mediaUrl =
        fileList.length > 0
          ? await handleUpload({ file: fileList[0].originFileObj })
          : null
      const postData = {
        content: values.content,
        mediaUrl,
        userId: user.id,
      }
      await createPost({ data: postData })
      enqueueSnackbar('Post created successfully', { variant: 'success' })
      router.push('/feed')
    } catch (error) {
      enqueueSnackbar('Failed to create post', { variant: 'error' })
    }
  }

  const handleFileChange = ({ fileList }) => setFileList(fileList)

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Create a New Post</Title>
      <Text>Share your thoughts and media with your followers</Text>
      <Form form={form} layout="vertical" onFinish={handleSubmit}>
        <Form.Item
          name="content"
          label="Content"
          rules={[{ required: true, message: 'Please enter content' }]}
        >
          <Input.TextArea rows={4} placeholder="What's on your mind?" />
        </Form.Item>
        <Form.Item label="Upload Media">
          <Upload
            listType="picture"
            fileList={fileList}
            beforeUpload={() => false}
            onChange={handleFileChange}
          >
            <Button icon={<UploadOutlined />}>Upload Image/Video</Button>
          </Upload>
        </Form.Item>
        <Form.Item>
          <Space>
            <Button type="primary" htmlType="submit">
              Publish
            </Button>
            <Button type="default" onClick={() => router.push('/feed')}>
              Cancel
            </Button>
          </Space>
        </Form.Item>
      </Form>
    </PageLayout>
  )
}
