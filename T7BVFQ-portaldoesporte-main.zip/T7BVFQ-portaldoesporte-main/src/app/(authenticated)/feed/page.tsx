'use client'

import { useState } from 'react'
import { Typography, List, Card, Button, Space, Input, Row, Col } from 'antd'
import {
  LikeOutlined,
  CommentOutlined,
  ShareAltOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function FeedPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const {
    data: posts,
    isLoading,
    refetch,
  } = Api.post.findMany.useQuery({
    include: { user: true, comments: true, likes: true },
  })

  const { mutateAsync: likePost } = Api.like.create.useMutation()
  const { mutateAsync: commentPost } = Api.comment.create.useMutation()

  const [comment, setComment] = useState<string>('')

  const handleLike = async (postId: string) => {
    try {
      await likePost({ data: { postId, userId: user.id } })
      enqueueSnackbar('Post liked!', { variant: 'success' })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to like post', { variant: 'error' })
    }
  }

  const handleComment = async (postId: string) => {
    if (!comment.trim()) return
    try {
      await commentPost({ data: { postId, userId: user.id, content: comment } })
      enqueueSnackbar('Comment added!', { variant: 'success' })
      setComment('')
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to add comment', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Feed</Title>
      <Text>
        Stay updated with the latest content from athletes, academies, and
        organizations.
      </Text>
      <Row justify="center" style={{ marginTop: '20px' }}>
        <Col xs={24} sm={20} md={16} lg={12}>
          <List
            loading={isLoading}
            dataSource={posts}
            renderItem={post => (
              <List.Item key={post.id}>
                <Card
                  title={post.user?.name}
                  extra={dayjs(post.datePosted).format('DD/MM/YYYY')}
                >
                  <p>{post.content}</p>
                  {post.mediaUrl && (
                    <img
                      src={post.mediaUrl}
                      alt="Post media"
                      style={{ width: '100%' }}
                    />
                  )}
                  <Space style={{ marginTop: '10px' }}>
                    <Button
                      icon={<LikeOutlined />}
                      onClick={() => handleLike(post.id)}
                    >
                      {post.likes?.length.toString()}
                    </Button>
                    <Button icon={<CommentOutlined />}>
                      {post.comments?.length.toString()}
                    </Button>
                    <Button icon={<ShareAltOutlined />}>Share</Button>
                  </Space>
                  <div style={{ marginTop: '10px' }}>
                    <Input
                      placeholder="Add a comment"
                      value={comment}
                      onChange={e => setComment(e.target.value)}
                      onPressEnter={() => handleComment(post.id)}
                    />
                    <Button
                      type="primary"
                      onClick={() => handleComment(post.id)}
                      style={{ marginTop: '5px' }}
                    >
                      Comment
                    </Button>
                  </div>
                </Card>
              </List.Item>
            )}
          />
        </Col>
      </Row>
    </PageLayout>
  )
}
