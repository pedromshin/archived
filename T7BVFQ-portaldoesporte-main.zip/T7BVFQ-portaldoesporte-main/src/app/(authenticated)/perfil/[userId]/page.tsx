'use client'

import { Prisma } from '@prisma/client'
import { useState, useEffect } from 'react'
import { Typography, Row, Col, Card, Button, Input, Form, Spin } from 'antd'
import { EditOutlined, SaveOutlined, UserOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function ProfilePage() {
  const router = useRouter()
  const params = useParams<{ userId: string }>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [isEditing, setIsEditing] = useState(false)
  const [form] = Form.useForm()

  const {
    data: profile,
    isLoading,
    refetch,
  } = Api.user.findUnique.useQuery({
    where: { id: params.userId },
    include: {
      posts: { include: { comments: true, likes: true } },
      comments: { include: { post: true } },
      likes: { include: { post: true } },
      eventsAsOrganizer: true,
      subscriptions: true,
      advertisementsAsBrand: true,
      productsAsSeller: { include: { orders: true } },
      orders: { include: { product: true } },
      settings: true,
    },
  })

  const { mutateAsync: updateUser } = Api.user.update.useMutation()

  const handleEdit = () => {
    setIsEditing(true)
    form.setFieldsValue({
      name: profile?.name,
      email: profile?.email,
      pictureUrl: profile?.pictureUrl,
    })
  }

  const handleSave = async (values: Prisma.UserUpdateInput) => {
    try {
      await updateUser({ where: { id: profile?.id }, data: values })
      enqueueSnackbar('Profile updated successfully', { variant: 'success' })
      setIsEditing(false)
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to update profile', { variant: 'error' })
    }
  }

  if (isLoading) {
    return <Spin />
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>User Profile</Title>
      <Paragraph>View and manage your profile information and posts.</Paragraph>

      <Row justify="center">
        <Col span={24}>
          <Card
            title={profile?.name}
            extra={
              user?.id === profile?.id && (
                <Button
                  icon={isEditing ? <SaveOutlined /> : <EditOutlined />}
                  onClick={() => (isEditing ? form.submit() : handleEdit())}
                >
                  {isEditing ? 'Save' : 'Edit'}
                </Button>
              )
            }
          >
            {isEditing ? (
              <Form form={form} onFinish={handleSave} layout="vertical">
                <Form.Item
                  name="name"
                  label="Name"
                  rules={[
                    { required: true, message: 'Please input your name!' },
                  ]}
                >
                  <Input prefix={<UserOutlined />} />
                </Form.Item>
                <Form.Item
                  name="email"
                  label="Email"
                  rules={[
                    { required: true, message: 'Please input your email!' },
                  ]}
                >
                  <Input />
                </Form.Item>
                <Form.Item name="pictureUrl" label="Profile Picture URL">
                  <Input />
                </Form.Item>
              </Form>
            ) : (
              <>
                <Text strong>Name:</Text> <Text>{profile?.name}</Text>
                <br />
                <Text strong>Email:</Text> <Text>{profile?.email}</Text>
                <br />
                <Text strong>Profile Picture:</Text>{' '}
                <Text>{profile?.pictureUrl}</Text>
                <br />
                <Text strong>Joined:</Text>{' '}
                <Text>
                  {dayjs(profile?.dateCreated).format('MMMM D, YYYY')}
                </Text>
              </>
            )}
          </Card>
        </Col>
      </Row>

      <Row justify="center" gutter={[16, 16]} style={{ marginTop: '20px' }}>
        {profile?.posts?.map(post => (
          <Col key={post.id} span={24}>
            <Card
              title={dayjs(post.datePosted).format('MMMM D, YYYY')}
              bordered={false}
            >
              <Paragraph>{post.content}</Paragraph>
              {post.mediaUrl && (
                <img
                  src={post.mediaUrl}
                  alt="Post media"
                  style={{ maxWidth: '100%' }}
                />
              )}
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
