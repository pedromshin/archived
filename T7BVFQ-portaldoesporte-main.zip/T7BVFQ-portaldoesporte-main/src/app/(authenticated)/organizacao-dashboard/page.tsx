'use client'

import { Prisma } from '@prisma/client'
import { useState } from 'react'
import {
  Typography,
  Row,
  Col,
  Card,
  Button,
  Spin,
  Form,
  Input,
  Upload,
  message,
} from 'antd'
import { UploadOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function OrganizationDashboardPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [form] = Form.useForm()
  const [fileList, setFileList] = useState([])

  const {
    data: organization,
    isLoading,
    refetch,
  } = Api.user.findUnique.useQuery({
    where: { id: user?.id },
    include: {
      posts: true,
      eventsAsOrganizer: true,
    },
  })

  const { mutateAsync: updateOrganization } = Api.user.update.useMutation()
  const { mutateAsync: createPost } = Api.post.create.useMutation()
  const { mutateAsync: deletePost } = Api.post.delete.useMutation()
  const { mutateAsync: upload } = useUploadPublic()

  const handleUpdateProfile = async (values: Prisma.UserUpdateInput) => {
    try {
      await updateOrganization({ where: { id: user?.id }, data: values })
      enqueueSnackbar('Profile updated successfully', { variant: 'success' })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to update profile', { variant: 'error' })
    }
  }

  const handleCreatePost = async (values: Prisma.PostCreateInput) => {
    try {
      if (fileList.length > 0) {
        const file = fileList[0]
        const { url } = await upload({ file })
        values.mediaUrl = url
      }
      await createPost({ data: { ...values, userId: user?.id } })
      enqueueSnackbar('Post created successfully', { variant: 'success' })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to create post', { variant: 'error' })
    }
  }

  const handleDeletePost = async (postId: string) => {
    try {
      await deletePost({ where: { id: postId } })
      enqueueSnackbar('Post deleted successfully', { variant: 'success' })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to delete post', { variant: 'error' })
    }
  }

  const uploadProps = {
    onRemove: file => {
      setFileList(prev => prev.filter(item => item.uid !== file.uid))
    },
    beforeUpload: file => {
      setFileList([file])
      return false
    },
    fileList,
  }

  if (isLoading) {
    return (
      <PageLayout layout="narrow">
        <Spin />
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Organization Dashboard</Title>
      <Paragraph>
        Manage your profile and posts to engage with the community.
      </Paragraph>

      <Form
        form={form}
        layout="vertical"
        onFinish={handleUpdateProfile}
        initialValues={organization}
      >
        <Form.Item name="name" label="Organization Name">
          <Input />
        </Form.Item>
        <Form.Item name="email" label="Email">
          <Input />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Update Profile
          </Button>
        </Form.Item>
      </Form>

      <Title level={3}>Create a Post</Title>
      <Form layout="vertical" onFinish={handleCreatePost}>
        <Form.Item name="content" label="Content">
          <Input.TextArea rows={4} />
        </Form.Item>
        <Form.Item label="Upload Media">
          <Upload {...uploadProps}>
            <Button icon={<UploadOutlined />}>Select File</Button>
          </Upload>
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Create Post
          </Button>
        </Form.Item>
      </Form>

      <Title level={3}>Your Posts</Title>
      <Row gutter={[16, 16]}>
        {organization?.posts?.map(post => (
          <Col key={post.id} span={24}>
            <Card
              actions={[
                <EditOutlined key="edit" />,
                <DeleteOutlined
                  key="delete"
                  onClick={() => handleDeletePost(post.id)}
                />,
              ]}
            >
              <Paragraph>{post.content}</Paragraph>
              {post.mediaUrl && (
                <img
                  src={post.mediaUrl}
                  alt="media"
                  style={{ width: '100%' }}
                />
              )}
              <Text type="secondary">
                {dayjs(post.dateCreated).format('MMMM D, YYYY')}
              </Text>
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
