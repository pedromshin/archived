'use client'

import { Prisma } from '@prisma/client'
import { useState } from 'react'
import { Input, Row, Col, Card, Typography, Spin } from 'antd'
import { SearchOutlined, UserOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function DiscoverPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()
  const [searchTerm, setSearchTerm] = useState<string>('')

  const { data: users, isLoading: isLoadingUsers } = Api.user.findMany.useQuery(
    {
      include: {
        posts: true,
        eventsAsOrganizer: true,
        subscriptions: true,
      },
    },
  )

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value)
  }

  const filteredUsers = users?.filter(
    user =>
      user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.eventsAsOrganizer?.some(event =>
        event.name?.toLowerCase().includes(searchTerm.toLowerCase()),
      ) ||
      user.subscriptions?.some(subscription =>
        subscription.planName?.toLowerCase().includes(searchTerm.toLowerCase()),
      ),
  )

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Discover New Content and Profiles</Title>
      <Text>
        Explore new content and profiles to find interesting posts and people to
        follow.
      </Text>
      <Input
        placeholder="Search for athletes, events, or organizations"
        prefix={<SearchOutlined />}
        value={searchTerm}
        onChange={handleSearch}
        style={{ margin: '20px 0' }}
      />
      {isLoadingUsers ? (
        <Spin size="large" />
      ) : (
        <Row gutter={[16, 16]}>
          {filteredUsers?.map(user => (
            <Col xs={24} sm={12} md={8} lg={6} key={user.id}>
              <Card
                hoverable
                onClick={() => router.push(`/perfil/${user.id}`)}
                cover={
                  <img
                    alt={user.name}
                    src={user.pictureUrl || '/default-avatar.png'}
                  />
                }
              >
                <Card.Meta
                  avatar={<UserOutlined />}
                  title={user.name}
                  description={user.email}
                />
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </PageLayout>
  )
}
