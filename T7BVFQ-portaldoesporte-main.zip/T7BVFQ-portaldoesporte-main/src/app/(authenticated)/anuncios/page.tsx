'use client'

import { Prisma } from '@prisma/client'
import { Typography, Row, Col, Card, Button, Spin } from 'antd'
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons'
import { useState } from 'react'
const { Title, Text, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function AdvertisementsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const {
    data: advertisements,
    isLoading,
    refetch,
  } = Api.advertisement.findMany.useQuery({
    include: { brand: true },
  })

  const { mutateAsync: deleteAdvertisement } =
    Api.advertisement.delete.useMutation()

  const handleDelete = async (id: string) => {
    try {
      await deleteAdvertisement({ where: { id } })
      enqueueSnackbar('Advertisement deleted successfully', {
        variant: 'success',
      })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to delete advertisement', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Advertisements</Title>
      <Paragraph>
        Manage your advertisements to reach your target audience.
      </Paragraph>
      {isLoading ? (
        <Spin size="large" />
      ) : (
        <Row gutter={[16, 16]} style={{ marginTop: '20px' }}>
          {advertisements?.map(ad => (
            <Col key={ad.id} xs={24} sm={12} md={8} lg={6}>
              <Card
                title={ad.content}
                actions={[
                  <EditOutlined key="edit" onClick={() => handleEdit(ad.id)} />,
                  <DeleteOutlined
                    key="delete"
                    onClick={() => handleDelete(ad.id)}
                  />,
                ]}
              >
                <Text>Target Audience: {ad.targetAudience}</Text>
                <br />
                <Text>Start Date: {ad.startDate}</Text>
                <br />
                <Text>End Date: {ad.endDate}</Text>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </PageLayout>
  )
}
