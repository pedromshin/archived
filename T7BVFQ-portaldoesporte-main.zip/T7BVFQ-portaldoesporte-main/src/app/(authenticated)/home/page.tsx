'use client'

import { Typography, Row, Col, Card, Button } from 'antd'
import {
  HomeOutlined,
  AppstoreOutlined,
  UserOutlined,
  SettingOutlined,
} from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function HomePage() {
  const router = useRouter()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const navigateTo = (path: string) => {
    router.push(path)
  }

  return (
    <PageLayout layout="narrow">
      <Row justify="center" align="middle" style={{ minHeight: '100vh' }}>
        <Col span={24}>
          <Title level={2} style={{ textAlign: 'center' }}>
            Platform Overview
          </Title>
          <Paragraph style={{ textAlign: 'center' }}>
            Welcome to our platform! Here you can explore various features and
            functionalities designed to enhance your experience.
          </Paragraph>
          <Row gutter={[16, 16]} justify="center">
            <Col xs={24} sm={12} md={8}>
              <Card
                hoverable
                onClick={() => navigateTo('/feed')}
                cover={
                  <HomeOutlined
                    style={{
                      fontSize: '48px',
                      textAlign: 'center',
                      padding: '20px',
                    }}
                  />
                }
              >
                <Card.Meta
                  title="Feed"
                  description="Explore the latest posts and updates"
                />
              </Card>
            </Col>
            <Col xs={24} sm={12} md={8}>
              <Card
                hoverable
                onClick={() => navigateTo('/descobrir')}
                cover={
                  <AppstoreOutlined
                    style={{
                      fontSize: '48px',
                      textAlign: 'center',
                      padding: '20px',
                    }}
                  />
                }
              >
                <Card.Meta
                  title="Discover"
                  description="Find new content and users"
                />
              </Card>
            </Col>
            <Col xs={24} sm={12} md={8}>
              <Card
                hoverable
                onClick={() => navigateTo(`/perfil/${user?.id}`)}
                cover={
                  <UserOutlined
                    style={{
                      fontSize: '48px',
                      textAlign: 'center',
                      padding: '20px',
                    }}
                  />
                }
              >
                <Card.Meta
                  title="Profile"
                  description="View and edit your profile"
                />
              </Card>
            </Col>
            <Col xs={24} sm={12} md={8}>
              <Card
                hoverable
                onClick={() => navigateTo('/configuracoes')}
                cover={
                  <SettingOutlined
                    style={{
                      fontSize: '48px',
                      textAlign: 'center',
                      padding: '20px',
                    }}
                  />
                }
              >
                <Card.Meta
                  title="Settings"
                  description="Manage your account settings"
                />
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>
    </PageLayout>
  )
}
