'use client'

import { useState, useEffect } from 'react'
import { Prisma } from '@prisma/client'
import { Typography, Form, Input, Button, Switch, Row, Col, Spin } from 'antd'
import {
  UserOutlined,
  LockOutlined,
  EyeInvisibleOutlined,
  EyeTwoTone,
} from '@ant-design/icons'
const { Title, Text } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function SettingsPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const {
    data: userData,
    isLoading,
    refetch,
  } = Api.user.findUnique.useQuery({
    where: { id: user?.id },
    include: { settings: true },
  })
  const { mutateAsync: updateUser } = Api.user.update.useMutation()

  const [form] = Form.useForm()

  useEffect(() => {
    if (userData) {
      form.setFieldsValue({
        email: userData.email,
        name: userData.name,
        privacyLevel: userData.settings?.privacyLevel,
        notificationsEnabled: userData.settings?.notificationsEnabled,
      })
    }
  }, [userData, form])

  const handleFormSubmit = async (values: any) => {
    try {
      await updateUser({
        where: { id: user?.id },
        data: {
          email: values.email,
          name: values.name,
          settings: {
            update: {
              privacyLevel: values.privacyLevel,
              notificationsEnabled: values.notificationsEnabled,
            },
          },
        },
      })
      enqueueSnackbar('Settings updated successfully', { variant: 'success' })
      refetch()
    } catch (error) {
      enqueueSnackbar('Failed to update settings', { variant: 'error' })
    }
  }

  if (isLoading) {
    return (
      <PageLayout layout="narrow">
        <Spin size="large" />
      </PageLayout>
    )
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Account Settings</Title>
      <Text>
        Manage your account settings and customize your experience on the
        platform.
      </Text>
      <Form
        form={form}
        layout="vertical"
        onFinish={handleFormSubmit}
        style={{ marginTop: 20 }}
      >
        <Form.Item
          name="email"
          label="Email"
          rules={[{ required: true, message: 'Please input your email!' }]}
        >
          <Input prefix={<UserOutlined />} />
        </Form.Item>
        <Form.Item
          name="name"
          label="Name"
          rules={[{ required: true, message: 'Please input your name!' }]}
        >
          <Input prefix={<UserOutlined />} />
        </Form.Item>
        <Form.Item
          name="privacyLevel"
          label="Privacy Level"
          rules={[
            { required: true, message: 'Please select your privacy level!' },
          ]}
        >
          <Input prefix={<LockOutlined />} />
        </Form.Item>
        <Form.Item
          name="notificationsEnabled"
          label="Enable Notifications"
          valuePropName="checked"
        >
          <Switch />
        </Form.Item>
        <Form.Item>
          <Button type="primary" htmlType="submit">
            Save Changes
          </Button>
        </Form.Item>
      </Form>
    </PageLayout>
  )
}
