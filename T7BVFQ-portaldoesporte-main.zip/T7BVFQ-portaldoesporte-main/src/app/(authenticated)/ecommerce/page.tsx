'use client'

import { Prisma } from '@prisma/client'
import { useState } from 'react'
import {
  Typography,
  Row,
  Col,
  Card,
  Button,
  InputNumber,
  Form,
  Input,
  Modal,
} from 'antd'
import { ShoppingCartOutlined, PlusOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function EcommercePage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const {
    data: products,
    isLoading: isLoadingProducts,
    refetch: refetchProducts,
  } = Api.product.findMany.useQuery({})
  const { mutateAsync: createProduct } = Api.product.create.useMutation()
  const { mutateAsync: createOrder } = Api.order.create.useMutation()

  const [isModalVisible, setIsModalVisible] = useState(false)
  const [form] = Form.useForm()

  const handleAddProduct = async (values: Prisma.ProductCreateInput) => {
    try {
      await createProduct({ data: { ...values, sellerId: user.id } })
      enqueueSnackbar('Product added successfully!', { variant: 'success' })
      refetchProducts()
      setIsModalVisible(false)
      form.resetFields()
    } catch (error) {
      enqueueSnackbar('Failed to add product.', { variant: 'error' })
    }
  }

  const handlePurchase = async (productId: string, quantity: number) => {
    try {
      await createOrder({ data: { productId, userId: user.id, quantity } })
      enqueueSnackbar('Purchase successful!', { variant: 'success' })
      refetchProducts()
    } catch (error) {
      enqueueSnackbar('Failed to complete purchase.', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>E-commerce Platform</Title>
      <Paragraph>
        Browse and purchase sports-related products or list your own products
        for sale.
      </Paragraph>
      <Row gutter={[16, 16]} justify="center">
        {products?.map(product => (
          <Col key={product.id} xs={24} sm={12} md={8} lg={6}>
            <Card
              title={product.name}
              extra={<Text>${product.price?.toString()}</Text>}
              actions={[
                <Button
                  type="primary"
                  icon={<ShoppingCartOutlined />}
                  onClick={() => handlePurchase(product.id, 1)}
                >
                  Buy
                </Button>,
              ]}
            >
              <Paragraph>{product.description}</Paragraph>
              <Text>Stock: {product.stock?.toString()}</Text>
            </Card>
          </Col>
        ))}
      </Row>
      {user && (
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={() => setIsModalVisible(true)}
        >
          Add Product
        </Button>
      )}
      <Modal
        title="Add New Product"
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={null}
      >
        <Form form={form} onFinish={handleAddProduct}>
          <Form.Item
            name="name"
            label="Product Name"
            rules={[{ required: true }]}
          >
            <Input />
          </Form.Item>
          <Form.Item name="description" label="Description">
            <Input.TextArea />
          </Form.Item>
          <Form.Item name="price" label="Price" rules={[{ required: true }]}>
            <InputNumber min={0} />
          </Form.Item>
          <Form.Item name="stock" label="Stock" rules={[{ required: true }]}>
            <InputNumber min={0} />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Add Product
            </Button>
          </Form.Item>
        </Form>
      </Modal>
    </PageLayout>
  )
}
