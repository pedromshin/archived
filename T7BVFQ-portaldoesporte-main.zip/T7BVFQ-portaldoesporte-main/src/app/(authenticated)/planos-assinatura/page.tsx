'use client'

import { Typography, Row, Col, Card, Button, Spin } from 'antd'
import { CheckCircleOutlined } from '@ant-design/icons'
const { Title, Text, Paragraph } = Typography
import { useUserContext } from '@/core/context'
import { useRouter, useParams } from 'next/navigation'
import { useUploadPublic } from '@/core/hooks/upload'
import { useSnackbar } from 'notistack'
import dayjs from 'dayjs'
import { Api } from '@/core/trpc'
import { PageLayout } from '@/designSystem/layouts/Page.layout'

export default function SubscriptionPlansPage() {
  const router = useRouter()
  const params = useParams<any>()
  const { user } = useUserContext()
  const { enqueueSnackbar } = useSnackbar()

  const { data: products, isLoading } = Api.billing.findManyProducts.useQuery(
    {},
  )
  const { mutateAsync: createSubscription } =
    Api.billing.createSubscription.useMutation()

  const handleSubscribe = async (productId: string) => {
    try {
      await createSubscription({ data: { userId: user.id, productId } })
      enqueueSnackbar('Subscription successful!', { variant: 'success' })
      router.push('/home')
    } catch (error) {
      enqueueSnackbar('Subscription failed. Please try again.', {
        variant: 'error',
      })
    }
  }

  return (
    <PageLayout layout="narrow">
      <Title level={2}>Subscription Plans</Title>
      <Paragraph>
        Choose the plan that best fits your needs and enjoy exclusive features.
      </Paragraph>
      {isLoading ? (
        <Spin size="large" />
      ) : (
        <Row gutter={[16, 16]} justify="center">
          {products?.map(product => (
            <Col key={product.id} xs={24} sm={12} md={8} lg={6}>
              <Card
                title={product.name}
                bordered={false}
                actions={[
                  <Button
                    type="primary"
                    icon={<CheckCircleOutlined />}
                    onClick={() => handleSubscribe(product.id)}
                  >
                    Subscribe
                  </Button>,
                ]}
              >
                <Text>{product.description}</Text>
                <Paragraph>
                  <Text strong>Price: </Text>${product.price.toString()}
                </Paragraph>
                <Paragraph>
                  <Text strong>Duration: </Text>
                  {dayjs(product.duration).format('MM/DD/YYYY')}
                </Paragraph>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </PageLayout>
  )
}
