'use client'
import { LandingCTA } from '@/designSystem/landing/LandingCTA'
import { LandingContainer } from '@/designSystem/landing/LandingContainer'
import LandingFAQ from '@/designSystem/landing/LandingFAQ'
import { LandingFeatures } from '@/designSystem/landing/LandingFeatures'
import { LandingHero } from '@/designSystem/landing/LandingHero'
import { LandingHowItWorks } from '@/designSystem/landing/LandingHowItWorks'
import { LandingPainPoints } from '@/designSystem/landing/LandingPainPoints'
import { LandingPricing } from '@/designSystem/landing/LandingPricing'
import { LandingSocialProof } from '@/designSystem/landing/LandingSocialProof'
import { LandingSocialRating } from '@/designSystem/landing/LandingSocialRating'
import { LandingTestimonials } from '@/designSystem/landing/LandingTestimonials'
import {
  EditOutlined,
  UserOutlined,
  TeamOutlined,
  TrophyOutlined,
  DollarOutlined,
  ShoppingCartOutlined,
} from '@ant-design/icons'

export default function LandingPage() {
  const features = [
    {
      heading: 'Conecte-se com Atletas',
      description:
        'Encontre e siga atletas profissionais e amadores, acompanhe suas jornadas e interaja com eles diretamente.',
      icon: <UserOutlined />,
    },
    {
      heading: 'Descubra Academias',
      description:
        'Explore academias perto de você, veja avaliações e encontre a melhor opção para suas necessidades.',
      icon: <TeamOutlined />,
    },
    {
      heading: 'Organize e Participe de Eventos',
      description:
        'Crie e promova eventos esportivos, ou encontre eventos para participar e competir.',
      icon: <TrophyOutlined />,
    },
    {
      heading: 'Monetize seu Conteúdo',
      description:
        'Ganhe dinheiro com assinaturas premium, publicidade e parcerias com marcas esportivas.',
      icon: <DollarOutlined />,
    },
    {
      heading: 'E-commerce Esportivo',
      description:
        'Compre e venda produtos esportivos diretamente na plataforma.',
      icon: <ShoppingCartOutlined />,
    },
    {
      heading: 'Perfis Personalizáveis',
      description:
        'Crie um perfil único que destaque suas conquistas e interesses esportivos.',
      icon: <EditOutlined />,
    },
  ]

  const testimonials = [
    {
      name: 'Carlos Silva',
      designation: 'Atleta Profissional',
      content:
        'Essa plataforma mudou minha vida! Agora posso me conectar com outros atletas e promover meus eventos de maneira muito mais eficaz.',
      avatar: 'https://randomuser.me/api/portraits/men/5.jpg',
    },
    {
      name: 'Ana Pereira',
      designation: 'Dona de Academia',
      content:
        'Finalmente, uma rede social dedicada ao esporte! Aumentei minha clientela e consegui parcerias incríveis.',
      avatar: 'https://randomuser.me/api/portraits/women/6.jpg',
    },
    {
      name: 'João Souza',
      designation: 'Organizador de Eventos',
      content:
        'Organizar eventos nunca foi tão fácil. A plataforma me ajudou a alcançar um público muito maior.',
      avatar: 'https://randomuser.me/api/portraits/men/7.jpg',
    },
    {
      name: 'Mariana Lima',
      designation: 'Atleta Amadora',
      content:
        'Adoro poder seguir meus atletas favoritos e descobrir novas academias e eventos na minha região.',
      avatar: 'https://randomuser.me/api/portraits/men/12.jpg',
    },
    {
      name: 'Pedro Alves',
      designation: 'Treinador',
      content:
        'A plataforma me permitiu encontrar novos talentos e expandir meu negócio de treinamento.',
      avatar: 'https://randomuser.me/api/portraits/men/17.jpg',
    },
    {
      name: 'Fernanda Costa',
      designation: 'Vendedora de Produtos Esportivos',
      content:
        'Vender meus produtos nunca foi tão fácil. A plataforma me deu acesso a um público altamente engajado.',
      avatar: 'https://randomuser.me/api/portraits/women/27.jpg',
    },
  ]

  const navItems = [
    {
      title: 'Início',
      link: '/',
    },
    {
      title: 'Recursos',
      link: '#features',
    },
    {
      title: 'Preços',
      link: '#pricing',
    },
  ]

  const packages = [
    {
      title: 'Básico',
      description: 'Para usuários iniciantes',
      monthly: 9,
      yearly: 69,
      features: ['Acesso ao feed principal', 'Perfis personalizáveis'],
    },
    {
      title: 'Premium',
      description: 'Para usuários avançados',
      monthly: 19,
      yearly: 129,
      features: [
        'Tudo no Básico',
        'Monetização de conteúdo',
        'Acesso a eventos exclusivos',
      ],
      highlight: true,
    },
    {
      title: 'Profissional',
      description: 'Para atletas e organizações',
      monthly: 29,
      yearly: 199,
      features: [
        'Tudo no Premium',
        'Parcerias com marcas',
        'E-commerce esportivo',
      ],
    },
  ]

  const questionAnswers = [
    {
      question: 'Como posso criar uma conta?',
      answer:
        'Clique no botão "Get Started" e siga as instruções para criar sua conta.',
    },
    {
      question: 'Quais são os métodos de pagamento aceitos?',
      answer: 'Aceitamos cartões de crédito, débito e pagamentos via PayPal.',
    },
    {
      question: 'Posso cancelar minha assinatura a qualquer momento?',
      answer:
        'Sim, você pode cancelar sua assinatura a qualquer momento nas configurações da sua conta.',
    },
    {
      question: 'A plataforma está disponível em outros idiomas?',
      answer:
        'Atualmente, a plataforma está disponível apenas em português do Brasil, mas temos planos de expansão internacional.',
    },
  ]

  const logos = [
    { url: 'https://i.imgur.com/afwBIFK.png' },
    { url: 'https://i.imgur.com/LlloOPa.png' },
    { url: 'https://i.imgur.com/j8jPb4H.png' },
    { url: 'https://i.imgur.com/mJ1sZFv.png' },
  ]

  const steps = [
    {
      heading: 'Crie seu Perfil',
      description:
        'Personalize seu perfil com suas conquistas e interesses esportivos.',
    },
    {
      heading: 'Conecte-se com a Comunidade',
      description:
        'Siga atletas, academias e eventos para se manter atualizado.',
    },
    {
      heading: 'Compartilhe e Descubra Conteúdo',
      description:
        'Poste suas atualizações e descubra novos conteúdos no feed principal.',
    },
    {
      heading: 'Monetize e Cresça',
      description:
        'Aproveite as opções de monetização e parcerias para crescer na plataforma.',
    },
  ]

  const painPoints = [
    {
      emoji: '💔',
      title: 'Fragmentação do Setor Esportivo',
    },
    {
      emoji: '📉',
      title: 'Dificuldade de Promoção',
    },
    {
      emoji: '🔍',
      title: 'Falta de Conexão Direta',
    },
  ]

  const avatarItems = [
    {
      src: 'https://randomuser.me/api/portraits/men/51.jpg',
    },
    {
      src: 'https://randomuser.me/api/portraits/women/9.jpg',
    },
    {
      src: 'https://randomuser.me/api/portraits/women/52.jpg',
    },
    {
      src: 'https://randomuser.me/api/portraits/men/5.jpg',
    },
    {
      src: 'https://randomuser.me/api/portraits/men/4.jpg',
    },
  ]

  return (
    <LandingContainer navItems={navItems}>
      <LandingHero
        title="Conecte-se com o Mundo dos Esportes"
        subtitle="A plataforma definitiva para atletas, academias e eventos esportivos."
        buttonText="Get Started"
        buttonLink="/login"
        pictureUrl="https://marblism-dashboard-api--production-public.s3.us-west-1.amazonaws.com/T7BVFQ-portaldoesporte-0w6z"
        socialProof={
          <LandingSocialRating
            avatarItems={avatarItems}
            numberOfUsers={1000}
            suffixText="usuários felizes"
          />
        }
      />
      <LandingSocialProof logos={logos} title="Destaque em" />
      <LandingPainPoints
        title="Os Desafios do Setor Esportivo"
        painPoints={painPoints}
      />
      <LandingHowItWorks title="Como Funciona" steps={steps} />
      <LandingFeatures
        id="features"
        title="Recursos que Ajudam Você a Crescer"
        subtitle="Tudo o que você precisa para se conectar, promover e monetizar."
        features={features}
      />
      <LandingTestimonials
        title="Histórias de Sucesso"
        subtitle="Veja como ajudamos outros a alcançar seus sonhos."
        testimonials={testimonials}
      />
      <LandingPricing
        id="pricing"
        title="Planos Flexíveis para Todos"
        subtitle="Escolha o plano que melhor se adapta às suas necessidades."
        packages={packages}
      />
      <LandingFAQ
        id="faq"
        title="Perguntas Frequentes"
        subtitle="Tudo o que você precisa saber sobre nossa plataforma."
        questionAnswers={questionAnswers}
      />
      <LandingCTA
        title="Pronto para Transformar sua Jornada Esportiva?"
        subtitle="Junte-se a nós e comece hoje mesmo."
        buttonText="Get Started"
        buttonLink="/login"
      />
    </LandingContainer>
  )
}
