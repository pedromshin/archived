import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

const splitSql = (sql: string) => {
  return sql.split(';').filter(content => content.trim() !== '')
}

async function main() {
  const sql = `

INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "stripeCustomerId", "status", "password") VALUES ('ad63e71f-242d-40e9-99ba-c76dd99fc8ff', '1Mallory.Goldner@hotmail.com', 'Joo Silva', 'https://i.imgur.com/YfJQV5z.png?id=3', 'inv78901', 'cus_12345', 'suspenso', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "stripeCustomerId", "status", "password") VALUES ('94222af5-3406-4a6f-ac31-72c9b25244dd', '17Royce89@hotmail.com', 'Pedro Souza', 'https://i.imgur.com/YfJQV5z.png?id=19', 'inv12345', 'cus_78901', 'ativo', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "stripeCustomerId", "status", "password") VALUES ('780013b0-7f59-4406-b876-94a13c09c28a', '25Katheryn.McLaughlin73@gmail.com', 'Joo Silva', 'https://i.imgur.com/YfJQV5z.png?id=27', 'inv12345', 'cus_44556', 'suspenso', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "stripeCustomerId", "status", "password") VALUES ('99725a91-9338-4048-9f7f-244f98135eb0', '33Marguerite_Beahan39@gmail.com', 'Carlos Fernandes', 'https://i.imgur.com/YfJQV5z.png?id=35', 'inv11223', 'cus_78901', 'suspenso', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "stripeCustomerId", "status", "password") VALUES ('0689a340-0bd6-4086-8fea-b1a63092b5b8', '41Alvena.Donnelly88@yahoo.com', 'Pedro Souza', 'https://i.imgur.com/YfJQV5z.png?id=43', 'inv78901', 'cus_67890', 'suspenso', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "stripeCustomerId", "status", "password") VALUES ('1b6247a6-7f89-44db-8169-38f6bf464cc0', '49Emmett.Emard@yahoo.com', 'Ana Lima', 'https://i.imgur.com/YfJQV5z.png?id=51', 'inv67890', 'cus_12345', 'suspenso', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "stripeCustomerId", "status", "password") VALUES ('f51dfe31-01ca-48ad-bb50-b7a197057aa1', '57Ramona_Donnelly@gmail.com', 'Joo Silva', 'https://i.imgur.com/YfJQV5z.png?id=59', 'inv44556', 'cus_67890', 'pendente', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "stripeCustomerId", "status", "password") VALUES ('e2eb0337-0e1a-4612-95c1-b996cb2aca05', '65Ericka_Reinger@gmail.com', 'Pedro Souza', 'https://i.imgur.com/YfJQV5z.png?id=67', 'inv12345', 'cus_78901', 'inativo', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');
INSERT INTO "User" ("id", "email", "name", "pictureUrl", "tokenInvitation", "stripeCustomerId", "status", "password") VALUES ('722c9ab4-53ac-4a12-9a15-4dc3230ff3f0', '73Zachary.Carroll62@yahoo.com', 'Pedro Souza', 'https://i.imgur.com/YfJQV5z.png?id=75', 'inv12345', 'cus_44556', 'ativo', '$2b$10$ppubsZypHzkqW9dkhMB97ul2.wSsvaCoDE2CzqIHygddRMKXvpYUC');

INSERT INTO "PostData" ("id", "content", "mediaUrl", "datePosted", "userId") VALUES ('e41cd4cc-437c-4acd-9ae9-c5e626c4ffa8', 'Compartilhando momentos do ltimo jogo. ', 'https://i.imgur.com/YfJQV5z.png?id=82', '2024-02-05T04:07:31.381Z', '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0');
INSERT INTO "PostData" ("id", "content", "mediaUrl", "datePosted", "userId") VALUES ('009284af-5c6e-4127-8835-fe2ae1c3d426', 'Dicas de alongamento para evitar leses. ', 'https://i.imgur.com/YfJQV5z.png?id=86', '2024-03-07T09:15:17.136Z', '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0');
INSERT INTO "PostData" ("id", "content", "mediaUrl", "datePosted", "userId") VALUES ('5e78645f-aac3-46a4-a4b1-7c127ad33bcf', 'Preparao para o campeonato regional ', 'https://i.imgur.com/YfJQV5z.png?id=90', '2025-04-03T01:11:43.109Z', 'ad63e71f-242d-40e9-99ba-c76dd99fc8ff');
INSERT INTO "PostData" ("id", "content", "mediaUrl", "datePosted", "userId") VALUES ('d01e2e5c-4d25-46d7-92ef-0f86c0593658', 'Treino intenso hoje ', 'https://i.imgur.com/YfJQV5z.png?id=94', '2024-02-15T19:04:55.919Z', '0689a340-0bd6-4086-8fea-b1a63092b5b8');
INSERT INTO "PostData" ("id", "content", "mediaUrl", "datePosted", "userId") VALUES ('8205a829-6669-4c78-a48c-8ba379aa13cb', 'Preparao para o campeonato regional ', 'https://i.imgur.com/YfJQV5z.png?id=98', '2025-05-19T04:00:28.837Z', '94222af5-3406-4a6f-ac31-72c9b25244dd');
INSERT INTO "PostData" ("id", "content", "mediaUrl", "datePosted", "userId") VALUES ('072c266b-4faa-4a26-838c-825bffed2cc8', 'Compartilhando momentos do ltimo jogo. ', 'https://i.imgur.com/YfJQV5z.png?id=102', '2024-09-16T16:20:12.974Z', 'e2eb0337-0e1a-4612-95c1-b996cb2aca05');
INSERT INTO "PostData" ("id", "content", "mediaUrl", "datePosted", "userId") VALUES ('cb207929-5447-4287-92fd-4d74c88f92e3', 'Compartilhando momentos do ltimo jogo. ', 'https://i.imgur.com/YfJQV5z.png?id=106', '2024-02-05T10:34:10.644Z', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "PostData" ("id", "content", "mediaUrl", "datePosted", "userId") VALUES ('8eb21474-b2f1-439e-bd70-56dfaff169bc', 'Compartilhando momentos do ltimo jogo. ', 'https://i.imgur.com/YfJQV5z.png?id=110', '2024-12-19T18:30:55.265Z', '780013b0-7f59-4406-b876-94a13c09c28a');
INSERT INTO "PostData" ("id", "content", "mediaUrl", "datePosted", "userId") VALUES ('b3744449-ea37-4fd4-bfa5-0cd9e2452401', 'Dicas de alongamento para evitar leses. ', 'https://i.imgur.com/YfJQV5z.png?id=114', '2023-10-12T15:07:04.508Z', 'ad63e71f-242d-40e9-99ba-c76dd99fc8ff');
INSERT INTO "PostData" ("id", "content", "mediaUrl", "datePosted", "userId") VALUES ('796e6670-c9c0-4f85-99ae-6c8018301dc6', 'Preparao para o campeonato regional ', 'https://i.imgur.com/YfJQV5z.png?id=118', '2024-01-05T11:32:51.796Z', '1b6247a6-7f89-44db-8169-38f6bf464cc0');

INSERT INTO "Comment" ("id", "content", "dateCommented", "postId", "userId") VALUES ('f6312a13-f64f-4866-92c5-2986e12d2f1a', 'Qual  a prxima competio', '2024-03-09T19:29:17.492Z', 'd01e2e5c-4d25-46d7-92ef-0f86c0593658', '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0');
INSERT INTO "Comment" ("id", "content", "dateCommented", "postId", "userId") VALUES ('adade735-8222-41cb-a446-afdc0329e44c', 'Esse treino foi incrvel', '2024-09-13T15:53:36.596Z', '009284af-5c6e-4127-8835-fe2ae1c3d426', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Comment" ("id", "content", "dateCommented", "postId", "userId") VALUES ('1ad31793-0cc8-4503-a602-223152162f4f', 'Inspirao total', '2024-03-16T23:56:02.279Z', '009284af-5c6e-4127-8835-fe2ae1c3d426', '780013b0-7f59-4406-b876-94a13c09c28a');
INSERT INTO "Comment" ("id", "content", "dateCommented", "postId", "userId") VALUES ('5cfd38c6-1503-4b22-a06e-c3065d1a1497', 'Inspirao total', '2024-09-29T01:29:38.118Z', 'cb207929-5447-4287-92fd-4d74c88f92e3', 'f51dfe31-01ca-48ad-bb50-b7a197057aa1');
INSERT INTO "Comment" ("id", "content", "dateCommented", "postId", "userId") VALUES ('6aa99998-dd56-4ac7-9f9f-793caa2e44b9', 'Adorei esse post', '2025-03-03T04:24:18.301Z', 'd01e2e5c-4d25-46d7-92ef-0f86c0593658', '780013b0-7f59-4406-b876-94a13c09c28a');
INSERT INTO "Comment" ("id", "content", "dateCommented", "postId", "userId") VALUES ('989a49cc-f59a-4b16-a3d3-a8d9570bfaa2', 'Inspirao total', '2025-07-10T14:48:06.761Z', '5e78645f-aac3-46a4-a4b1-7c127ad33bcf', 'e2eb0337-0e1a-4612-95c1-b996cb2aca05');
INSERT INTO "Comment" ("id", "content", "dateCommented", "postId", "userId") VALUES ('c1ba3859-52f3-4085-8cdc-df0e9405b04d', 'Esse treino foi incrvel', '2024-04-06T20:35:57.263Z', '009284af-5c6e-4127-8835-fe2ae1c3d426', '0689a340-0bd6-4086-8fea-b1a63092b5b8');
INSERT INTO "Comment" ("id", "content", "dateCommented", "postId", "userId") VALUES ('5134ef23-61f4-4fbb-9550-8334cf55cf51', 'Esse treino foi incrvel', '2024-08-28T08:34:10.751Z', '5e78645f-aac3-46a4-a4b1-7c127ad33bcf', '94222af5-3406-4a6f-ac31-72c9b25244dd');
INSERT INTO "Comment" ("id", "content", "dateCommented", "postId", "userId") VALUES ('34f02b89-d406-42b1-bae6-782e8e2f0bb6', 'Inspirao total', '2024-07-22T14:20:11.321Z', 'e41cd4cc-437c-4acd-9ae9-c5e626c4ffa8', '94222af5-3406-4a6f-ac31-72c9b25244dd');
INSERT INTO "Comment" ("id", "content", "dateCommented", "postId", "userId") VALUES ('4679e036-3f16-4ff9-8293-1556873cc4d5', 'Qual  a prxima competio', '2025-05-07T13:14:31.753Z', '072c266b-4faa-4a26-838c-825bffed2cc8', '94222af5-3406-4a6f-ac31-72c9b25244dd');

INSERT INTO "Like" ("id", "postId", "userId") VALUES ('528744d6-00de-4e15-b258-8df1e0e0d348', '8eb21474-b2f1-439e-bd70-56dfaff169bc', '1b6247a6-7f89-44db-8169-38f6bf464cc0');
INSERT INTO "Like" ("id", "postId", "userId") VALUES ('cc56ad98-4786-417a-96fd-88c7ff670439', 'd01e2e5c-4d25-46d7-92ef-0f86c0593658', 'e2eb0337-0e1a-4612-95c1-b996cb2aca05');
INSERT INTO "Like" ("id", "postId", "userId") VALUES ('adf3b661-b776-4579-9a29-84d1ffd910cd', '072c266b-4faa-4a26-838c-825bffed2cc8', 'ad63e71f-242d-40e9-99ba-c76dd99fc8ff');
INSERT INTO "Like" ("id", "postId", "userId") VALUES ('471cbe37-56e5-4807-b121-4344f4ee6de0', 'd01e2e5c-4d25-46d7-92ef-0f86c0593658', '0689a340-0bd6-4086-8fea-b1a63092b5b8');
INSERT INTO "Like" ("id", "postId", "userId") VALUES ('c5f7c2eb-575e-4757-b8ec-c8179ebdbd6e', 'cb207929-5447-4287-92fd-4d74c88f92e3', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Like" ("id", "postId", "userId") VALUES ('9664c7f7-c07e-4614-8b2a-1f90b77b289d', '009284af-5c6e-4127-8835-fe2ae1c3d426', '780013b0-7f59-4406-b876-94a13c09c28a');
INSERT INTO "Like" ("id", "postId", "userId") VALUES ('295f3578-53c8-474b-8927-a3f210012699', '072c266b-4faa-4a26-838c-825bffed2cc8', '99725a91-9338-4048-9f7f-244f98135eb0');
INSERT INTO "Like" ("id", "postId", "userId") VALUES ('5e04ad1d-15f2-415f-aeba-efb7965711a9', 'b3744449-ea37-4fd4-bfa5-0cd9e2452401', '1b6247a6-7f89-44db-8169-38f6bf464cc0');
INSERT INTO "Like" ("id", "postId", "userId") VALUES ('23fd630b-1a4f-40f6-a65b-a243df3a5f20', 'b3744449-ea37-4fd4-bfa5-0cd9e2452401', '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0');
INSERT INTO "Like" ("id", "postId", "userId") VALUES ('2895b1bc-f660-4adb-a84d-aa906f93b030', '8eb21474-b2f1-439e-bd70-56dfaff169bc', '94222af5-3406-4a6f-ac31-72c9b25244dd');

INSERT INTO "Event" ("id", "name", "description", "date", "location", "organizerId") VALUES ('b5964af4-4d45-41d8-938c-8deabb0d50ca', 'Maratona do Rio de Janeiro', 'Festival de skate com diversas competies e demonstraes.', '2024-02-26T23:13:13.476Z', 'Avenida Paulista So Paulo', '99725a91-9338-4048-9f7f-244f98135eb0');
INSERT INTO "Event" ("id", "name", "description", "date", "location", "organizerId") VALUES ('28ead188-8ed4-4fbf-ab81-d06b62bb38fb', 'Torneio de Tnis de Mesa', 'Festival de skate com diversas competies e demonstraes.', '2025-08-06T16:23:30.413Z', 'Praia de Copacabana Rio de Janeiro', '780013b0-7f59-4406-b876-94a13c09c28a');
INSERT INTO "Event" ("id", "name", "description", "date", "location", "organizerId") VALUES ('c6392ca8-826b-4915-8d4a-157f47f31b6d', 'Maratona do Rio de Janeiro', 'Torneio de tnis de mesa com categorias amadoras e profissionais.', '2025-01-05T20:44:41.240Z', 'Praa Roosevelt So Paulo', '1b6247a6-7f89-44db-8169-38f6bf464cc0');
INSERT INTO "Event" ("id", "name", "description", "date", "location", "organizerId") VALUES ('694d8c69-faee-46fb-b65c-68c5e2c5dcce', 'Torneio de Tnis de Mesa', 'Uma corrida de rua emocionante pelas principais avenidas de So Paulo.', '2024-05-22T09:47:52.179Z', 'Praia de Copacabana Rio de Janeiro', '0689a340-0bd6-4086-8fea-b1a63092b5b8');
INSERT INTO "Event" ("id", "name", "description", "date", "location", "organizerId") VALUES ('9c900c6a-e082-47bb-b2e1-b3ad9c8757c2', 'Campeonato de Vlei de Praia', 'Maratona internacional com participantes de diversos pases.', '2024-03-27T10:27:20.522Z', 'Avenida Paulista So Paulo', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Event" ("id", "name", "description", "date", "location", "organizerId") VALUES ('9b4f53a7-256e-4fb7-8520-8c0a4c6e1944', 'Maratona do Rio de Janeiro', 'Competio de vlei de praia com os melhores atletas do Brasil.', '2023-10-11T16:48:19.718Z', 'Praia de Copacabana Rio de Janeiro', '0689a340-0bd6-4086-8fea-b1a63092b5b8');
INSERT INTO "Event" ("id", "name", "description", "date", "location", "organizerId") VALUES ('45c0d313-80bf-4412-a1c6-af1edb03cb42', 'Campeonato de Vlei de Praia', 'Festival de skate com diversas competies e demonstraes.', '2024-04-21T16:56:56.871Z', 'Parque do Flamengo Rio de Janeiro', '94222af5-3406-4a6f-ac31-72c9b25244dd');
INSERT INTO "Event" ("id", "name", "description", "date", "location", "organizerId") VALUES ('495d8c8a-af71-4b61-9616-eda201aeb3d0', 'Corrida de Rua So Paulo', 'Festival de skate com diversas competies e demonstraes.', '2023-09-01T19:32:49.405Z', 'Ginsio do Ibirapuera So Paulo', '1b6247a6-7f89-44db-8169-38f6bf464cc0');
INSERT INTO "Event" ("id", "name", "description", "date", "location", "organizerId") VALUES ('a4337069-2e6e-4a1e-a271-d1440735771c', 'Campeonato de Vlei de Praia', 'Uma corrida de rua emocionante pelas principais avenidas de So Paulo.', '2024-12-16T16:43:27.037Z', 'Parque do Flamengo Rio de Janeiro', 'f51dfe31-01ca-48ad-bb50-b7a197057aa1');
INSERT INTO "Event" ("id", "name", "description", "date", "location", "organizerId") VALUES ('d2f4b045-8299-4f14-aa89-fbed3fa8447c', 'Festival de Skateboard', 'Festival de skate com diversas competies e demonstraes.', '2024-08-28T17:43:36.822Z', 'Ginsio do Ibirapuera So Paulo', '94222af5-3406-4a6f-ac31-72c9b25244dd');

INSERT INTO "Subscription" ("id", "planName", "startDate", "endDate", "userId") VALUES ('52646a6d-b451-492b-ac61-dc259e057299', 'Platina', '2024-04-04T18:21:47.861Z', '2023-09-23T01:57:53.072Z', 'ad63e71f-242d-40e9-99ba-c76dd99fc8ff');
INSERT INTO "Subscription" ("id", "planName", "startDate", "endDate", "userId") VALUES ('6ef58064-5f93-4583-be01-065e2dd8d799', 'Platina', '2024-07-28T07:53:39.873Z', '2025-04-15T09:04:56.756Z', '99725a91-9338-4048-9f7f-244f98135eb0');
INSERT INTO "Subscription" ("id", "planName", "startDate", "endDate", "userId") VALUES ('1433ebbe-2355-49d5-884f-de4a7f3ec03d', 'Ouro', '2025-02-09T14:15:50.554Z', '2024-02-19T18:44:06.436Z', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Subscription" ("id", "planName", "startDate", "endDate", "userId") VALUES ('2c9eceb0-7022-4c97-bdb3-722c2d22833e', 'Diamante', '2025-07-08T09:30:11.687Z', '2024-11-06T14:51:39.044Z', '780013b0-7f59-4406-b876-94a13c09c28a');
INSERT INTO "Subscription" ("id", "planName", "startDate", "endDate", "userId") VALUES ('02afb408-2ac6-42f0-bad0-bf0e441a8c7c', 'Ouro', '2025-07-13T21:48:12.956Z', '2023-12-15T14:40:13.175Z', '99725a91-9338-4048-9f7f-244f98135eb0');
INSERT INTO "Subscription" ("id", "planName", "startDate", "endDate", "userId") VALUES ('0e767ab5-0d36-4293-972d-546bc63ac5af', 'Prata', '2024-07-24T22:25:03.175Z', '2024-06-04T17:07:07.153Z', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Subscription" ("id", "planName", "startDate", "endDate", "userId") VALUES ('b984d2c3-1640-410f-a4d8-dafee0265469', 'Platina', '2025-05-06T01:14:23.609Z', '2023-08-25T10:40:38.619Z', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Subscription" ("id", "planName", "startDate", "endDate", "userId") VALUES ('60b1c63c-7bbd-40b8-8b2c-926e550543c7', 'Diamante', '2023-11-29T10:50:37.169Z', '2025-02-03T04:00:11.008Z', '99725a91-9338-4048-9f7f-244f98135eb0');
INSERT INTO "Subscription" ("id", "planName", "startDate", "endDate", "userId") VALUES ('43c84924-09d9-4aaf-b1d1-763fb4827619', 'Platina', '2024-04-28T04:43:00.652Z', '2024-09-01T10:06:14.018Z', '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0');
INSERT INTO "Subscription" ("id", "planName", "startDate", "endDate", "userId") VALUES ('9ec5d9b0-1a7b-4b90-81fa-7bea26856391', 'Diamante', '2023-12-01T14:25:41.892Z', '2023-11-08T17:51:08.229Z', 'ad63e71f-242d-40e9-99ba-c76dd99fc8ff');

INSERT INTO "Advertisement" ("id", "content", "targetAudience", "startDate", "endDate", "brandId") VALUES ('d65d1377-01ba-47c2-ab3a-bd709a554d20', 'Novos suplementos esportivos com frete grtis.', 'Frequentadores de academia', '2023-08-22T02:31:12.375Z', '2024-05-18T06:51:52.268Z', '1b6247a6-7f89-44db-8169-38f6bf464cc0');
INSERT INTO "Advertisement" ("id", "content", "targetAudience", "startDate", "endDate", "brandId") VALUES ('0ab69668-73f7-4c55-90c1-87b048eb00cc', 'Novos suplementos esportivos com frete grtis.', 'Jogadores de futebol', '2024-01-01T11:51:11.998Z', '2024-08-12T03:57:29.086Z', '0689a340-0bd6-4086-8fea-b1a63092b5b8');
INSERT INTO "Advertisement" ("id", "content", "targetAudience", "startDate", "endDate", "brandId") VALUES ('e788c710-323f-4cf5-b6b7-54a9e854f6de', 'Desconto exclusivo em equipamentos de musculao.', 'Jogadores de futebol', '2023-08-25T06:27:13.073Z', '2025-05-10T21:19:32.173Z', '780013b0-7f59-4406-b876-94a13c09c28a');
INSERT INTO "Advertisement" ("id", "content", "targetAudience", "startDate", "endDate", "brandId") VALUES ('07347c0b-5301-4dca-aa24-8313e192d6f8', 'Desconto exclusivo em equipamentos de musculao.', 'Corredores', '2025-07-22T04:45:58.509Z', '2024-08-30T13:05:52.374Z', '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0');
INSERT INTO "Advertisement" ("id", "content", "targetAudience", "startDate", "endDate", "brandId") VALUES ('ab238908-92f8-4dd2-bb4e-0b771ee0dbec', 'Participe do nosso campeonato de futebol amador.', 'Corredores', '2025-02-01T05:40:44.508Z', '2024-08-30T13:35:57.760Z', 'ad63e71f-242d-40e9-99ba-c76dd99fc8ff');
INSERT INTO "Advertisement" ("id", "content", "targetAudience", "startDate", "endDate", "brandId") VALUES ('f92bd6d9-57fa-4259-a0ea-571b20463c61', 'Aulas de yoga online com 50 de desconto.', 'Frequentadores de academia', '2025-02-01T22:06:22.426Z', '2024-01-09T06:26:18.054Z', 'e2eb0337-0e1a-4612-95c1-b996cb2aca05');
INSERT INTO "Advertisement" ("id", "content", "targetAudience", "startDate", "endDate", "brandId") VALUES ('3af7ec62-96b3-45bc-ab9b-079b60551402', 'Novos suplementos esportivos com frete grtis.', 'Jogadores de futebol', '2024-07-16T11:45:39.980Z', '2024-07-29T17:53:48.316Z', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Advertisement" ("id", "content", "targetAudience", "startDate", "endDate", "brandId") VALUES ('9ae5481a-c610-48d2-ac17-a359dc0d591b', 'Novos suplementos esportivos com frete grtis.', 'Corredores', '2024-11-29T05:24:30.681Z', '2023-11-10T12:54:09.767Z', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Advertisement" ("id", "content", "targetAudience", "startDate", "endDate", "brandId") VALUES ('f96b3481-dac6-4358-a8ed-f0ae6a9e2215', 'Novos suplementos esportivos com frete grtis.', 'Entusiastas de suplementos', '2025-07-29T14:15:02.500Z', '2025-07-02T00:13:00.250Z', '94222af5-3406-4a6f-ac31-72c9b25244dd');
INSERT INTO "Advertisement" ("id", "content", "targetAudience", "startDate", "endDate", "brandId") VALUES ('ff482342-76b9-418a-8545-2c7dd13a5354', 'Aulas de yoga online com 50 de desconto.', 'Jogadores de futebol', '2024-09-20T14:54:42.399Z', '2025-07-04T20:29:45.851Z', '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0');

INSERT INTO "Product" ("id", "name", "description", "price", "stock", "sellerId") VALUES ('f80e53f3-bf27-41d7-90fd-da85b5835c38', 'Camiseta Esportiva Nike', 'Roupo de natao com secagem rpida e confortvel.', 181, 376, '99725a91-9338-4048-9f7f-244f98135eb0');
INSERT INTO "Product" ("id", "name", "description", "price", "stock", "sellerId") VALUES ('55ac5a5e-0db8-4960-acc9-987a1ea55fc3', 'Bola de Futebol Puma', 'Camiseta leve e respirvel ideal para treinos intensos.', 744, 309, 'f51dfe31-01ca-48ad-bb50-b7a197057aa1');
INSERT INTO "Product" ("id", "name", "description", "price", "stock", "sellerId") VALUES ('a1892d75-5c37-4cfc-9aa0-552f96cbcf77', 'Camiseta Esportiva Nike', 'Tnis com amortecimento avanado para corridas de longa distncia.', 95, 401, '780013b0-7f59-4406-b876-94a13c09c28a');
INSERT INTO "Product" ("id", "name", "description", "price", "stock", "sellerId") VALUES ('bb006488-b972-4cf6-bc71-d0b5cc71bd7e', 'Tnis de Corrida Adidas', 'Tnis com amortecimento avanado para corridas de longa distncia.', 26, 960, 'f51dfe31-01ca-48ad-bb50-b7a197057aa1');
INSERT INTO "Product" ("id", "name", "description", "price", "stock", "sellerId") VALUES ('841b61a5-822f-439f-b713-ebd23367c52d', 'Camiseta Esportiva Nike', 'Camiseta leve e respirvel ideal para treinos intensos.', 80, 431, 'f51dfe31-01ca-48ad-bb50-b7a197057aa1');
INSERT INTO "Product" ("id", "name", "description", "price", "stock", "sellerId") VALUES ('82f257dc-468c-4848-89f0-9a415fdb16ce', 'Roupo de Natao Speedo', 'Roupo de natao com secagem rpida e confortvel.', 803, 753, 'f51dfe31-01ca-48ad-bb50-b7a197057aa1');
INSERT INTO "Product" ("id", "name", "description", "price", "stock", "sellerId") VALUES ('7cd8d12a-fe37-4ad4-8f05-f6906cee70fa', 'Tnis de Corrida Adidas', 'Roupo de natao com secagem rpida e confortvel.', 386, 649, '99725a91-9338-4048-9f7f-244f98135eb0');
INSERT INTO "Product" ("id", "name", "description", "price", "stock", "sellerId") VALUES ('974d91a0-9b10-420e-bcd1-ba500ed4245c', 'Luvas de Boxe Everlast', 'Luvas de boxe profissionais usadas por campees mundiais.', 777, 665, 'f51dfe31-01ca-48ad-bb50-b7a197057aa1');
INSERT INTO "Product" ("id", "name", "description", "price", "stock", "sellerId") VALUES ('e881bef5-4fd2-421a-8b89-0f006c73f364', 'Bola de Futebol Puma', 'Roupo de natao com secagem rpida e confortvel.', 488, 999, '0689a340-0bd6-4086-8fea-b1a63092b5b8');
INSERT INTO "Product" ("id", "name", "description", "price", "stock", "sellerId") VALUES ('839de541-8856-466a-84f0-bf1257c75a87', 'Roupo de Natao Speedo', 'Roupo de natao com secagem rpida e confortvel.', 308, 322, '0689a340-0bd6-4086-8fea-b1a63092b5b8');

INSERT INTO "Order" ("id", "quantity", "orderDate", "userId", "productId") VALUES ('fcb2f4e3-5bb8-41c6-9528-3fcf96eebe91', 69, '2025-05-16T17:25:29.875Z', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '7cd8d12a-fe37-4ad4-8f05-f6906cee70fa');
INSERT INTO "Order" ("id", "quantity", "orderDate", "userId", "productId") VALUES ('bcca2567-ec11-4ed2-b9ca-6fdc70c25dbd', 763, '2024-01-18T11:56:46.359Z', '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0', '974d91a0-9b10-420e-bcd1-ba500ed4245c');
INSERT INTO "Order" ("id", "quantity", "orderDate", "userId", "productId") VALUES ('53f229b5-0e67-4512-8259-c4ae5ca60715', 769, '2024-08-21T20:14:44.840Z', '99725a91-9338-4048-9f7f-244f98135eb0', '974d91a0-9b10-420e-bcd1-ba500ed4245c');
INSERT INTO "Order" ("id", "quantity", "orderDate", "userId", "productId") VALUES ('3144185f-120f-4eff-972b-50bf00edd14f', 963, '2024-07-27T00:41:59.993Z', 'f51dfe31-01ca-48ad-bb50-b7a197057aa1', '974d91a0-9b10-420e-bcd1-ba500ed4245c');
INSERT INTO "Order" ("id", "quantity", "orderDate", "userId", "productId") VALUES ('448ffb09-102f-42a5-8817-4d4cec0522af', 508, '2023-12-13T19:14:48.969Z', '21a857f1-ba5f-4435-bcf6-f910ec07c0dc', '841b61a5-822f-439f-b713-ebd23367c52d');
INSERT INTO "Order" ("id", "quantity", "orderDate", "userId", "productId") VALUES ('3621817b-825d-4541-adbf-6d4d2f53b144', 252, '2025-06-26T07:05:33.124Z', '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0', 'bb006488-b972-4cf6-bc71-d0b5cc71bd7e');
INSERT INTO "Order" ("id", "quantity", "orderDate", "userId", "productId") VALUES ('12288bf6-eb5f-4d9a-8961-10afd499ad25', 463, '2025-04-11T16:25:42.623Z', '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0', 'e881bef5-4fd2-421a-8b89-0f006c73f364');
INSERT INTO "Order" ("id", "quantity", "orderDate", "userId", "productId") VALUES ('f06fed4f-8f4f-4d76-a481-13b54f84651a', 596, '2024-05-02T01:12:10.145Z', 'e2eb0337-0e1a-4612-95c1-b996cb2aca05', '82f257dc-468c-4848-89f0-9a415fdb16ce');
INSERT INTO "Order" ("id", "quantity", "orderDate", "userId", "productId") VALUES ('7b8470dc-be17-4692-b363-4fac0edc947d', 100, '2024-05-27T17:24:45.537Z', '780013b0-7f59-4406-b876-94a13c09c28a', '974d91a0-9b10-420e-bcd1-ba500ed4245c');
INSERT INTO "Order" ("id", "quantity", "orderDate", "userId", "productId") VALUES ('ab98cd03-a2c5-4651-96b2-fc98bc353bf6', 814, '2025-03-08T11:45:36.248Z', 'ad63e71f-242d-40e9-99ba-c76dd99fc8ff', '7cd8d12a-fe37-4ad4-8f05-f6906cee70fa');

INSERT INTO "Setting" ("id", "privacyLevel", "notificationsEnabled", "userId") VALUES ('a1629d9c-c12c-44ae-bae5-07632fb6f71b', 'Personalizado', false, 'e2eb0337-0e1a-4612-95c1-b996cb2aca05');
INSERT INTO "Setting" ("id", "privacyLevel", "notificationsEnabled", "userId") VALUES ('b00e0dce-c3eb-4a66-bfe4-e64051446bc8', 'Restrito', false, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Setting" ("id", "privacyLevel", "notificationsEnabled", "userId") VALUES ('0c63bf72-6f24-48a3-b17d-ab044969de67', 'Restrito', false, '0689a340-0bd6-4086-8fea-b1a63092b5b8');
INSERT INTO "Setting" ("id", "privacyLevel", "notificationsEnabled", "userId") VALUES ('b4af66cb-b0d6-4ac6-a619-3e24a3c900dc', 'Restrito', true, 'f51dfe31-01ca-48ad-bb50-b7a197057aa1');
INSERT INTO "Setting" ("id", "privacyLevel", "notificationsEnabled", "userId") VALUES ('60e4e214-23e6-4cbc-b4f9-d25a784d9fec', 'Personalizado', false, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');
INSERT INTO "Setting" ("id", "privacyLevel", "notificationsEnabled", "userId") VALUES ('a9ba3030-f560-4251-bd46-eba6b6b27e18', 'Privado', true, '94222af5-3406-4a6f-ac31-72c9b25244dd');
INSERT INTO "Setting" ("id", "privacyLevel", "notificationsEnabled", "userId") VALUES ('54527c5e-9d96-48a7-ba95-0586f9c8c4a9', 'Privado', true, '722c9ab4-53ac-4a12-9a15-4dc3230ff3f0');
INSERT INTO "Setting" ("id", "privacyLevel", "notificationsEnabled", "userId") VALUES ('903d0621-ba1e-43a4-a4aa-955de8833099', 'Privado', false, 'e2eb0337-0e1a-4612-95c1-b996cb2aca05');
INSERT INTO "Setting" ("id", "privacyLevel", "notificationsEnabled", "userId") VALUES ('f01f85b3-37f2-4e65-b542-5e0c97bff6f9', 'Restrito', false, 'e2eb0337-0e1a-4612-95c1-b996cb2aca05');
INSERT INTO "Setting" ("id", "privacyLevel", "notificationsEnabled", "userId") VALUES ('765e2956-613e-4889-8ee2-654c22f6f094', 'Somente Amigos', true, '21a857f1-ba5f-4435-bcf6-f910ec07c0dc');

  `

  const sqls = splitSql(sql)

  for (const sql of sqls) {
    try {
      await prisma.$executeRawUnsafe(`${sql}`)
    } catch (error) {
      console.log(`Could not insert SQL: ${error.message}`)
    }
  }
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async error => {
    console.error(error)
    await prisma.$disconnect()
    process.exit(1)
  })
