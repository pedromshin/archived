import { Document } from 'mongoose';

export class PokemonEntity extends Document {
  name: string;
  hp: number;
  type: string;
}
