import { Schema } from 'mongoose';

export const PokemonSchema = new Schema({
  name: String,
  hp: Number,
  type: String,
});
