import { Module } from '@nestjs/common';
import { PokemonRepository } from './pokemon.repository';
import { MongooseModule } from '@nestjs/mongoose';
import { PokemonSchema } from 'src/infra/mongo/schemas/pokemon.schema';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Pokemon', schema: PokemonSchema }]),
  ],
  providers: [PokemonRepository],
  exports: [PokemonRepository],
})
export class RepositoriesModule {}
