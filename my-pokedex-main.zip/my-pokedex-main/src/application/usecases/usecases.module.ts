import { Module } from '@nestjs/common';
import { CreatePokemonController } from './pokemon/create-pokemon/create-pokemon.controller';
import { CreatePokemonUsecase } from './pokemon/create-pokemon/create-pokemon.usecase';
import { MongooseModule } from '@nestjs/mongoose';
import { PokemonSchema } from 'src/infra/mongo/schemas/pokemon.schema';
import { RepositoriesModule } from '../repositories/repositories.module';
import { DeletePokemonUseCase } from './pokemon/delete-pokemon/delete-pokemon.usecase';
import { FindAllPokemonUseCase } from './pokemon/find-all-pokemon/find-all-pokemon.usecase';
import { FindAllPokemonController } from './pokemon/find-all-pokemon/find-all-pokemon.controller';
import { DeletePokemonController } from './pokemon/delete-pokemon/delete-pokemon.controller';
import { FindByIdPokemonUseCase } from './pokemon/find-by-id-pokemon/find-by-id-pokemon.usecase';
import { FindByIdPokemonController } from './pokemon/find-by-id-pokemon/find-by-id-pokemon.controller';
import { UpdatePokemonUseCase } from './pokemon/update-pokemon/update-pokemon.usecase';
import { UpdatePokemonController } from './pokemon/update-pokemon/update-pokemon.controller';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Pokemon', schema: PokemonSchema }]),
    RepositoriesModule,
  ],
  providers: [
    CreatePokemonUsecase,
    DeletePokemonUseCase,
    FindAllPokemonUseCase,
    FindByIdPokemonUseCase,
    UpdatePokemonUseCase,
  ],
  controllers: [
    CreatePokemonController,
    DeletePokemonController,
    FindAllPokemonController,
    FindByIdPokemonController,
    UpdatePokemonController,
  ],
})
export class UseCaseModule {}
