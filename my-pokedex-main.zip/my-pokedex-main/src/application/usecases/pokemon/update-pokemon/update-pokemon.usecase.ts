import { Injectable } from '@nestjs/common';
import { PokemonRepository } from 'src/application/repositories/pokemon.repository';

@Injectable()
export class UpdatePokemonUseCase {
  constructor(private readonly pokemonRepository: PokemonRepository) {}

  async execute(_id: string, payload) {
    return await this.pokemonRepository.update(_id, payload);
  }
}
