import { Body, Controller, Param, Put, UsePipes } from '@nestjs/common';
import { UpdatePokemonUseCase } from './update-pokemon.usecase';
import { z } from 'zod';
import { ZodValidationPipe, createZodDto } from '@anatine/zod-nestjs';
import { extendApi } from '@anatine/zod-openapi';

const updatePokemonDTOSchema = extendApi(
  z.object({
    name: z.string(),
    hp: z.number(),
    type: z.string(),
  }),
);

export class updatePokemonDTO extends createZodDto(updatePokemonDTOSchema) {}

@UsePipes(ZodValidationPipe)
@Controller('pokemon')
export class UpdatePokemonController {
  constructor(private updatePokemonUseCase: UpdatePokemonUseCase) {}

  @Put(':_id')
  async findById(@Param() _id: string, @Body() pokemon: updatePokemonDTO) {
    return this.updatePokemonUseCase.execute(_id, pokemon);
  }
}
