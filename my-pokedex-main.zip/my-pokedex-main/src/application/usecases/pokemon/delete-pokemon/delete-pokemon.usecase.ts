import { Injectable } from '@nestjs/common';
import { PokemonRepository } from 'src/application/repositories/pokemon.repository';

@Injectable()
export class DeletePokemonUseCase {
  constructor(private readonly pokemonRepository: PokemonRepository) {}

  async execute(payload: string) {
    const result = await this.pokemonRepository.delete(payload);
    return result;
  }
}
