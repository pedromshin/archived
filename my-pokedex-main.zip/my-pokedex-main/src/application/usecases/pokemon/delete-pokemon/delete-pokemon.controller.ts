import { Controller, Delete, Param } from '@nestjs/common';
import { DeletePokemonUseCase } from './delete-pokemon.usecase';

@Controller('pokemon')
export class DeletePokemonController {
  constructor(private deletePokemonUseCase: DeletePokemonUseCase) {}

  @Delete(':_id')
  async delete(@Param() _id: string) {
    return this.deletePokemonUseCase.execute(_id);
  }
}
