import { Injectable } from '@nestjs/common';
import { PokemonRepository } from 'src/application/repositories/pokemon.repository';

@Injectable()
export class FindByIdPokemonUseCase {
  constructor(private readonly pokemonRepository: PokemonRepository) {}

  async execute(payload: string) {
    return await this.pokemonRepository.findOne(payload);
  }
}
