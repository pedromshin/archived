import { Controller, Get, Param } from '@nestjs/common';
import { FindByIdPokemonUseCase } from './find-by-id-pokemon.usecase';

@Controller('pokemon')
export class FindByIdPokemonController {
  constructor(private findByIdUseCase: FindByIdPokemonUseCase) {}

  @Get(':_id')
  async findById(@Param() _id: string) {
    return this.findByIdUseCase.execute(_id);
  }
}
