import { Body, Controller, Post, UsePipes } from '@nestjs/common';
import { CreatePokemonUsecase } from './create-pokemon.usecase';
import { PokemonEntity } from 'src/domain/entities/pokemon.entity';
import { z } from 'zod';
import { ZodValidationPipe, createZodDto } from '@anatine/zod-nestjs';
import { extendApi } from '@anatine/zod-openapi';

const createPokemonDTOSchema = extendApi(
  z.object({
    name: z.string(),
    hp: z.number(),
    type: z.string(),
  }),
);

export class createPokemonDTO extends createZodDto(createPokemonDTOSchema) {}

@UsePipes(ZodValidationPipe)
@Controller('pokemon')
export class CreatePokemonController {
  constructor(private createPokemonUsecase: CreatePokemonUsecase) {}

  @Post()
  async create(@Body() pokemon: createPokemonDTO): Promise<PokemonEntity> {
    return this.createPokemonUsecase.execute(pokemon);
  }
}
