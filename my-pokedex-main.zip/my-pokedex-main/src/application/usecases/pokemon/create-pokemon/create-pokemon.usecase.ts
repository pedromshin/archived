import { Injectable } from '@nestjs/common';
import { PokemonRepository } from 'src/application/repositories/pokemon.repository';

@Injectable()
export class CreatePokemonUsecase {
  constructor(private readonly pokemonRepository: PokemonRepository) {}

  async execute(payload) {
    const result = await this.pokemonRepository.create(payload);
    return result;
  }
}
