import { Controller, Get, Query } from '@nestjs/common';
import { FindAllPokemonUseCase } from './find-all-pokemon.usecase';

@Controller('pokemon')
export class FindAllPokemonController {
  constructor(private findAllPokemonUseCase: FindAllPokemonUseCase) {}

  @Get()
  async findAll(@Query('name') name: string) {
    return this.findAllPokemonUseCase.execute(name);
  }
}
