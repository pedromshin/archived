import { Injectable } from '@nestjs/common';
import { PokemonRepository } from 'src/application/repositories/pokemon.repository';

@Injectable()
export class FindAllPokemonUseCase {
  constructor(private readonly pokemonRepository: PokemonRepository) {}

  async execute(name: string) {
    return await this.pokemonRepository.findAll(name);
  }
}
