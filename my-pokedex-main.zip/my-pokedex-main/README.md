## Como testar a api

<ol>
  <li>Importar collection no insomnia (solicitar ao shin pra enviar o arquivo)</li>
  <li>Se quiser rodar o endpoint LOCAL pra testar, solicitar também as váriaveis do arquivo .env que precisa tmb</li>
  <li>Seguir instruções de instalação abaixo do próprio nest</li>
  <li>Se quiser rodar o endpoint REMOTO precisa pedir pra eu ligar a instancia do elastic beanstalk, pq to deixando ela desligada pra nao dar gasto</li>
  <li>As collections do insomnia já tem os dados no formato correto, basta testar o envio</li>
</ol>

## Installation

```bash
$ yarn install
```

## Running the app

```bash
# development
$ yarn run start

# watch mode
$ yarn run start:dev

# production mode
$ yarn run start:prod
```
