import { KindeUserBase } from '@kinde-oss/kinde-auth-nextjs/dist/types'
import {
  withAuth,
  getKindeServerSession
} from '@kinde-oss/kinde-auth-nextjs/server'
import { NextRequest, NextResponse } from 'next/server'
import { Users, init } from '@kinde/management-api-js'

export default async function middleware(req: NextRequest) {
  init()
  const origin = req.nextUrl.origin
  const { isAuthenticated, getUser } = getKindeServerSession()

  if (await isAuthenticated()) {
    const user = await getUser()
    const userId = user?.id

    if (userId) {
      const userProperties = await Users.getUserPropertyValues({ userId })
      if (
        !userProperties?.properties?.some(
          property => property.key === 'username'
        )
      ) {
        const userUsername = user?.username || generateUsername(user)
        await Users.updateUserProperty({
          userId,
          propertyKey: 'username',
          value: userUsername
        })
      }
    }
  }

  return withAuth(req)
}

export const config = {
  matcher: [
    // '/((?!api|_next/static|_next/image|favicon.ico|sitemap.xml|robots.txt))'
  ]
}

function generateUsername(user: KindeUserBase) {
  if (user?.email) {
    return user?.email.split('@')[0]
  }

  if (user?.given_name && user?.family_name) {
    return `${user?.given_name.toLowerCase()}.${user?.family_name.toLowerCase()}.${Math.random().toString(36).substring(2, 10)}`
  }

  return `user_${Math.random().toString(36).substring(2, 10)}`
}
