'use client'
import {
  Avatar,
  AvatarFallback,
  AvatarImage
} from '@/registry/new-york/ui/avatar'
import { Skeleton } from '@/registry/new-york/ui/skeleton'
import MenuMessages from './menu-conversations/menu-messages'
import { useEffect, useState } from 'react'
import { trpc } from '@/server/client'
import { useKindeBrowserClient } from '@kinde-oss/kinde-auth-nextjs'

export default function Conversations({ open }: { open: boolean }) {
  const [messagesOpen, setMessagesOpen] = useState<[boolean, string]>([
    false,
    ''
  ])
  const { getUser } = useKindeBrowserClient()
  const kindeUser = getUser()

  const {
    data: conversations,
    isLoading,
    refetch
  } = trpc.conversations.getConversations.useQuery()

  useEffect(() => {
    open && refetch()
  }, [open, refetch])

  return (
    <>
      {isLoading ? (
        <div className='mt-5 flex flex-col gap-4 space-y-1 rounded-md bg-secondary p-2 px-4'>
          {/* Skeleton for the loading state */}
          {[...Array(4)].map((_, index) => (
            <div key={index} className='flex w-full items-center px-4 py-3'>
              <Skeleton className='h-10 w-10 rounded-full' />
              <div className='ml-4 flex-1 space-y-2'>
                <Skeleton className='h-4 w-1/3' />
                <Skeleton className='h-3 w-2/3' />
              </div>
            </div>
          ))}
        </div>
      ) : (
        !!conversations?.length && (
          <div className='mt-5 flex flex-col gap-4 space-y-1 rounded-md bg-secondary p-2 px-4'>
            {conversations?.map((conversation: any) => {
              const participant = conversation.participants.find(
                (participant: any) => participant.kindeId !== kindeUser?.id
              )

              return (
                <MenuMessages
                  kindeId={kindeUser?.id || ''}
                  conversationId={messagesOpen[1] as string}
                  key={conversation.id}
                  setOpen={open => setMessagesOpen([open, ''])}
                  open={messagesOpen[0] as boolean}
                  trigger={
                    <li className='flex flex-col'>
                      <button
                        type='button'
                        className='flex w-full items-center px-4 py-3 text-start'
                        onClick={() =>
                          setMessagesOpen([!messagesOpen[0], conversation?.id])
                        }
                      >
                        <div className='flex min-w-0 items-center'>
                          {participant?.picture ? (
                            <div
                              className='aspect-square min-h-10 w-10 rounded-full bg-cover bg-center bg-no-repeat'
                              style={{
                                backgroundImage: `url("${participant?.picture}"), url('https://secure.gravatar.com/avatar/46922c4d0387348f51d2c5fa76f4aec3?s=96&d=mm&r=g')`
                              }}
                            />
                          ) : (
                            <Avatar className='min-h-10 w-10'>
                              <AvatarImage
                                src={
                                  participant?.picture ??
                                  'https://secure.gravatar.com/avatar/46922c4d0387348f51d2c5fa76f4aec3?s=96&d=mm&r=g'
                                }
                                alt='participant Image'
                              />
                              <AvatarFallback>
                                {participant?.username?.slice(0, 3)}
                              </AvatarFallback>
                            </Avatar>
                          )}
                          <div className='ml-4 min-w-0 flex-1 flex-col'>
                            <p className='text-md truncate font-bold leading-tight tracking-[-0.015em]'>
                              {participant?.username}
                            </p>
                            <p className='truncate text-sm'>
                              {participant?.name}
                            </p>
                          </div>
                        </div>
                      </button>
                    </li>
                  }
                />
              )
            })}
          </div>
        )
      )}
    </>
  )
}
