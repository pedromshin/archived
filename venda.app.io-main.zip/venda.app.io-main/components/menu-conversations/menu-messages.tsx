'use client'

import { useEffect, useState } from 'react'
import { useKindeBrowserClient } from '@kinde-oss/kinde-auth-nextjs'
import { trpc } from '@/server/client'
import { Sheet, SheetContent } from '@/registry/new-york/ui/sheet'
import { Input } from '@/registry/new-york/ui/input'
import { Button } from '@/registry/new-york/ui/button'
import { ChevronRight } from 'lucide-react'
import { DialogProps } from '@radix-ui/react-dialog'

interface MenuMessagesProps {
  open?: boolean
  setOpen?: DialogProps['onOpenChange']
  hideTrigger?: boolean
  trigger?: React.ReactNode
  conversationId?: string | null
  kindeId: string
}

export default function MenuMessages({
  open,
  setOpen,
  hideTrigger,
  trigger,
  conversationId,
  kindeId
}: MenuMessagesProps) {
  const { data: user } = trpc.profile.fetchUser.useQuery({ kindeId })
  const [messageContent, setMessageContent] = useState('')
  const [messages, setMessages] = useState<any[]>([])

  // Fetch initial messages only if conversationId is valid
  const { data: initialMessages, refetch: refetchMessages } =
    trpc.messages.getMessages.useQuery(
      { conversationId: conversationId || '' },
      {
        enabled: !!conversationId // Only run query if conversationId is not null or undefined
      }
    )

  // Mutation to send a message
  const { mutate: sendMessage } = trpc.messages.sendMessage.useMutation({
    onSuccess: () => {
      refetchMessages()
    }
  })

  // Handle initial message loading when conversationId or messages change
  useEffect(() => {
    if (initialMessages) {
      setMessages(initialMessages)
    }
  }, [initialMessages])

  // Subscription to new messages, only active when conversationId is valid
  trpc.messages.onNewMessage.useSubscription(
    { conversationId: conversationId || '' },
    {
      enabled: !!conversationId, // Only subscribe if conversationId is not null or undefined
      onData: message => {
        setMessages(prevMessages => [message, ...prevMessages])
      },
      onError: err => {
        console.error('Subscription error:', err)
      }
    }
  )

  // Handle sending a message
  const handleSendMessage = () => {
    if (messageContent.trim() && user?.id && conversationId) {
      sendMessage({
        conversationId,
        senderId: user.id,
        content: messageContent.trim()
      })
      setMessageContent('')
    }
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      {!hideTrigger && trigger}
      <SheetContent>
        <div className='flex h-full flex-col'>
          <div className='flex-grow overflow-y-auto'>
            {messages.map(message => (
              <div key={message.id} className='mb-2'>
                <strong>{message.sender.username}: </strong>
                {message.content}
              </div>
            ))}
          </div>
          <div className='flex items-center p-4'>
            <Input
              value={messageContent}
              onChange={e => setMessageContent(e.target.value)}
              className='flex-grow rounded-lg p-3 text-base'
              placeholder='Type a message...'
            />
            <Button
              onClick={handleSendMessage}
              disabled={!messageContent.trim() || !conversationId}
              variant='default'
              className='ml-2'
            >
              <ChevronRight />
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
