import { Sheet, SheetContent } from '@/registry/new-york/ui/sheet'
import { ReactNode } from 'react'
import { DialogProps } from '@radix-ui/react-dialog'
import Conversations from '../conversations'

export default function MenuConversations({
  open,
  setOpen,
  hideTrigger,
  trigger
}: {
  open?: boolean
  setOpen?: DialogProps['onOpenChange']
  hideTrigger?: boolean
  trigger?: ReactNode
}) {
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      {!hideTrigger && trigger}
      <SheetContent>
        <Conversations open={!!open} />
      </SheetContent>
    </Sheet>
  )
}
