'use client'
import { cn } from '@/lib/utils'
import { Button } from '@/registry/new-york/ui/button'
import { RegisterLink } from '@kinde-oss/kinde-auth-nextjs'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ReactNode } from 'react'

export default function ClientMutedLinkButton({
  items
}: {
  items: {
    href: string
    id: string
    name: string | ReactNode
    registerAnchor?: boolean
  }[]
}) {
  const pathname = usePathname()

  return items.map(item => {
    if (item.registerAnchor) {
      return (
        <Button variant={'ghost'} key={item.id}>
          <RegisterLink target='_blank'>{item.name}</RegisterLink>
        </Button>
      )
    }
    return (
      <Link
        href={item.href}
        key={item.id}
        className={cn(
          pathname === item.href && pathname !== '/'
            ? 'bg-muted'
            : 'hover:bg-muted hover:bg-opacity-75',
          'group flex items-center rounded-md px-2 py-2 font-medium'
        )}
      >
        {item.name}
      </Link>
    )
  })
}
