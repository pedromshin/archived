import Link from "next/link";

export default function Logo() {
  return (
    <Link href="/">
      <h1 className="text-2xl font-semibold ">
        venda<span className="text-primary text-4xl leading-[0]">.</span>
      </h1>
    </Link>
  );
}
