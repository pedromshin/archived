import { MainNav } from '@/components/site-header/main-nav'
import { ModeToggle } from '@/components/site-header/mode-toggle'
import { Button } from '@/registry/new-york/ui/button'
import { LoginLink, RegisterLink } from '@kinde-oss/kinde-auth-nextjs/server'
import { getKindeServerSession } from '@kinde-oss/kinde-auth-nextjs/server'
import Logo from '../logo'
import MenuMessages from '../menu-conversations'
import { MobileMenuNotifications } from './mobile-menu-notifications'
import BackButton from './back-button'
import { SheetTrigger } from '@/registry/new-york/ui/sheet'
import { MessageCircle } from 'lucide-react'
import { Users } from '@kinde/management-api-js'
import ClientMutedLinkButton from '../client-muted-link-button'
import { desktopNavbarLinks } from '@/config/docs'

export async function SiteHeader() {
  const { getUser } = getKindeServerSession()
  const user = await getUser()
  const userId = user?.id

  let username = ''
  if (userId) {
    const userProperties = await Users.getUserPropertyValues({ userId })
    username =
      userProperties?.properties?.find(property => property.key === 'username')
        ?.value || ''
  }

  return (
    <header className='sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60'>
      <div className='container flex h-14 max-w-screen-2xl items-center justify-between'>
        {/* <BackButton /> */}
        <Logo />
        {/* {user && (
          <div className='col-span-6 mx-auto hidden flex-1 items-center justify-center gap-x-2 lg:flex'>
            <ClientMutedLinkButton items={desktopNavbarLinks(username || '')} />
          </div>
        )} */}
        <div className='absolute left-2/4 right-2/4 col-span-6 mx-auto hidden flex-1 items-center justify-center gap-x-2 lg:flex'>
          <ClientMutedLinkButton items={desktopNavbarLinks(username || '')} />
        </div>
        <div className='flex flex-1 items-center justify-end space-x-2 lg:flex-none'>
          <nav className='flex items-center gap-2'>
            <div className={`ms-auto flex items-center gap-x-3 md:col-span-3`}>
              <ModeToggle />
              {user ? (
                // <div className='flex flex-row items-center gap-4 lg:hidden'>
                //   {/* <MobileMenuNotifications /> */}
                //   <MenuMessages
                //     trigger={
                //       <SheetTrigger asChild>
                //         <MessageCircle className='h-[1.4rem] w-[1.4rem]' />
                //       </SheetTrigger>
                //     }
                //   />
                // </div>
                <></>
              ) : (
                <div className='flex items-center gap-x-2'>
                  <Button asChild>
                    <LoginLink target='_blank'>login</LoginLink>
                  </Button>
                  <Button variant='secondary' asChild>
                    <RegisterLink target='_blank'>register</RegisterLink>
                  </Button>
                </div>
              )}
            </div>
          </nav>
        </div>
      </div>
    </header>
  )
}
