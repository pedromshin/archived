import { desktopNavbarLinks } from '@/config/docs'
import { getKindeServerSession } from '@kinde-oss/kinde-auth-nextjs/server'
import ClientMutedLinkButton from '../client-muted-link-button'
import { Users } from '@kinde/management-api-js'

export async function MainNav() {
  const { getUser } = getKindeServerSession()
  const user = await getUser()
  const userId = user?.id

  let username = ''
  if (userId) {
    const userProperties = await Users.getUserPropertyValues({ userId })
    username =
      userProperties?.properties?.find(property => property.key === 'username')
        ?.value || ''
  }

  return (
    <div className='col-span-6 mx-auto hidden flex-1 items-center justify-center gap-x-2 lg:flex'>
      <ClientMutedLinkButton items={desktopNavbarLinks(username || '')} />
    </div>
  )
}
