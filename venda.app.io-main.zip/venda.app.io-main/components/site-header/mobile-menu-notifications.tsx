import { Sheet, SheetContent, SheetTrigger } from '@/registry/new-york/ui/sheet'
import { Heart } from 'lucide-react'

export function MobileMenuNotifications() {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Heart className='h-[1.4rem] w-[1.4rem]' />
      </SheetTrigger>
      <SheetContent>
        <div className='mt-5 flex flex-col space-y-1 px-2'>
          {/* {navbarLinks.map((item) => (
            <Link
              href={item.href}
              key={item.id}
              className={
                "group flex items-center px-2 py-2 font-medium rounded-md"
              }
            >
              {item.name}
            </Link>
          ))} */}
        </div>
      </SheetContent>
    </Sheet>
  )
}
