'use client'

import { ChevronLeft } from 'lucide-react'
import { usePathname, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'

const excludedRoutes = ['/home', '/search', '/']

export default function BackButton() {
  const pathname = usePathname()
  const router = useRouter()
  const [showButton, setShowButton] = useState(false)

  useEffect(() => {
    const currentPath = pathname

    if (!excludedRoutes.includes(currentPath)) {
      setShowButton(true)
    } else {
      setShowButton(false)
    }
  }, [pathname])

  const handleBackClick = () => {
    router.back()
  }

  if (!showButton) return null

  return (
    <button onClick={handleBackClick} className='mt-1'>
      <ChevronLeft />
    </button>
  )
}
