import { MainNavItem } from '@/types/nav'

export interface DocsConfig {
  mainNav: MainNavItem[]
  // sidebarNav: SidebarNavItem[]
  // chartsNav: SidebarNavItem[]
}

export const docsConfig: DocsConfig = {
  mainNav: [
    {
      id: 'start',
      name: 'Start',
      href: '/'
    }
    // {
    //   id: 'about',
    //   name: 'About',
    //   href: '/about'
    // }
    // {
    //   title: 'Blocks',
    //   href: '/blocks'
    // },
    // {
    //   title: 'Charts',
    //   href: '/charts'
    // },
    // {
    //   title: 'Themes',
    //   href: '/themes'
    // },
    // {
    //   title: 'Examples',
    //   href: '/examples'
    // },
    // {
    //   title: 'Colors',
    //   href: '/colors'
    // }
  ]
}

export const desktopNavbarLinks = (username?: string) => [
  // {
  //   id: 'home',
  //   name: 'home',
  //   href: '/home'
  // },
  {
    id: 'search',
    name: 'search',
    href: '/search'
  },
  // {
  //   id: 'sell',
  //   name: 'sell',
  //   href: '/sell'
  // },
  // {
  //   id: 'wishlist',
  //   name: 'wishlist',
  //   href: '/wishlist'
  // },
  {
    id: 'profile',
    name: 'profile',
    href: `/${username}`
  },
  // {
  //   id: 'notifications',
  //   name: 'notifications',
  //   href: '/notifications'
  // },
  {
    id: 'conversations',
    name: 'conversations',
    href: '/conversations'
  }
  // {
  //   id: 3,
  //   name: "Wishlist",
  //   href: "/wishlist",
  // },
  // {
  //   id: 5,
  //   name: "Sales",
  //   href: "/sales",
  // },
  // {
  //   id: 6,
  //   name: "Offers",
  //   href: "/offers",
  // },
  // {
  //   id: 7,
  //   name: "Notifications",
  //   href: "/notifications",
  // },
  // {
  //   id: 8,
  //   name: "Wallet",
  //   href: "/wallet",
  // },
]
