'use client'
import MenuMessages from '@/components/menu-conversations'
import { Button } from '@/registry/new-york/ui/button'
import { trpc } from '@/server/client'
import { RegisterLink } from '@kinde-oss/kinde-auth-nextjs'
import { useState, useEffect } from 'react'

export default function FollowButtons({
  profileUser,
  user
}: {
  profileUser: any
  user: any
}) {
  const [following, setFollowing] = useState(
    user?.following?.some((f: any) => f.followingId === profileUser?.id) ||
      false
  )
  const [followsYou, setFollowsYou] = useState(false)

  const [messagesDrawerOpen, setMessagesDrawerOpen] = useState(false)

  const followMutation = trpc.profile.follow.useMutation()

  const upsertConversationMutation =
    trpc.conversations.upsertConversation.useMutation()

  const { refetch: refetchConversations } =
    trpc.conversations.getConversations.useQuery(undefined, { enabled: false })

  const handleFollow = async () => {
    if (!user) return

    const action = following ? 'unfollow' : 'follow'

    setFollowing(!following)

    try {
      await followMutation.mutateAsync({
        action,
        followingId: profileUser?.id,
        followerId: user?.id
      })
    } catch (error) {
      console.error('Failed to update follow status', error)
      setFollowing(following)
    }
  }

  const handleMessage = async () => {
    if (!user) return
    try {
      setMessagesDrawerOpen(true)
      const conversation = await upsertConversationMutation.mutateAsync({
        userIds: [user?.id, profileUser?.id]
      })

      refetchConversations()
    } catch (error) {}
  }

  useEffect(() => {
    if (user && profileUser) {
      const isFollowing =
        profileUser.following?.some(
          (f: any) => f.followerId === profileUser?.id
        ) || false
      setFollowsYou(isFollowing)
    }
  }, [user, profileUser])

  return (
    <>
      <div className='flex flex-col gap-2'>
        {followsYou && (
          <span className='text-sm text-gray-500'>Follows you</span>
        )}
        <div className='flex flex-row gap-4'>
          <Button
            onClick={handleFollow}
            disabled={followMutation.isLoading}
            variant={following ? 'destructive' : 'default'}
          >
            {user ? (
              <span className='truncate'>
                {following ? 'Unfollow' : 'Follow'}
              </span>
            ) : (
              <RegisterLink target='_blank'>
                <span className='truncate'>
                  {following ? 'unfollow' : 'follow'}
                </span>
              </RegisterLink>
            )}
          </Button>
          <Button
            onClick={handleMessage}
            disabled={upsertConversationMutation.isLoading}
            variant={'secondary'}
          >
            {user ? (
              <span className='truncate'>message</span>
            ) : (
              <RegisterLink target='_blank'>
                <span className='truncate'>message</span>
              </RegisterLink>
            )}
          </Button>
        </div>
      </div>
      <MenuMessages
        open={messagesDrawerOpen}
        setOpen={setMessagesDrawerOpen}
        hideTrigger
      />
    </>
  )
}
