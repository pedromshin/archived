import { MenuSettings } from '@/app/(authenticated)/[username]/menu-settings'
import {
  Avatar,
  AvatarFallback,
  AvatarImage
} from '@/registry/new-york/ui/avatar'
import {
  getKindeServerSession,
  RegisterLink
} from '@kinde-oss/kinde-auth-nextjs/server'
import FollowButtons from './follow-buttons'
import { createCaller } from '@/server/trpc'
import { Button } from '@/registry/new-york/ui/button'

// Skeleton component for loading state
const Skeleton = () => (
  <div className='flex w-full animate-pulse flex-col items-start gap-4'>
    <div className='flex w-full flex-row items-start justify-between'>
      <div className='flex min-w-full flex-row items-stretch gap-4'>
        <div className='aspect-square min-h-24 w-24 rounded-full bg-gray-300' />
        <div className='flex w-full max-w-[calc(100vw-140px)] flex-col justify-between'>
          <div className='flex w-full flex-row justify-between'>
            <div className='h-8 w-32 rounded bg-gray-300' />
          </div>
          <div className='flex w-full max-w-[480px] gap-3'>
            <div className='h-10 w-24 rounded bg-gray-300' />
          </div>
        </div>
      </div>
    </div>
    <div className='flex flex-wrap gap-3'>
      <div className='flex min-w-[100px] flex-1 flex-col items-start'>
        <div className='h-8 w-10 rounded bg-gray-300' />
        <div className='mt-2 h-4 w-16 rounded bg-gray-300' />
      </div>
      <div className='flex min-w-[100px] flex-1 flex-col items-start'>
        <div className='h-8 w-10 rounded bg-gray-300' />
        <div className='mt-2 h-4 w-16 rounded bg-gray-300' />
      </div>
      <div className='flex min-w-[100px] flex-1 flex-col items-start'>
        <div className='h-8 w-10 rounded bg-gray-300' />
        <div className='mt-2 h-4 w-16 rounded bg-gray-300' />
      </div>
    </div>
  </div>
)

export default async function ProfileById({
  params
}: {
  params: { username: string }
}) {
  const { getUser } = getKindeServerSession()
  const caller = createCaller({})

  // Fetch all data in parallel using Promise.all
  const kindeUser = await getUser()

  const profileUser = await caller.profile.fetchProfileUser({
    username: params.username
  })

  const [user, followersCount, followingCount] = await Promise.all([
    kindeUser ? caller.profile.fetchUser({ kindeId: kindeUser?.id }) : null,
    caller.profile.countFollowers({ userId: profileUser?.id || '' }),
    caller.profile.countFollowing({ userId: profileUser?.id || '' })
  ])

  // If data is still loading (can check null cases)
  if (!followersCount || !followingCount) {
    return <Skeleton />
  }

  const isOwnPage = kindeUser?.id === profileUser?.kindeId

  return (
    <div className='mt-4 flex w-full flex-col items-start gap-4'>
      <div className='flex w-full flex-row items-start justify-between'>
        <div className='flex min-w-full flex-row items-stretch gap-4'>
          {profileUser?.picture ? (
            <div
              className='aspect-square min-h-24 w-24 rounded-full bg-cover bg-center bg-no-repeat'
              style={{
                backgroundImage: `url("${profileUser?.picture}")`
              }}
            />
          ) : (
            <Avatar className='min-h-24 min-w-24'>
              <AvatarImage
                src={
                  profileUser?.picture ??
                  `https://secure.gravatar.com/avatar/46922c4d0387348f51d2c5fa76f4aec3?s=96&d=mm&r=g`
                }
                alt='User Image'
              />
              <AvatarFallback>
                {profileUser?.username?.slice(0, 3)}
              </AvatarFallback>
            </Avatar>
          )}
          <div className='flex w-full max-w-[calc(100vw-140px)] flex-col justify-between'>
            <div className='flex w-full flex-row justify-between'>
              <p className='truncate text-[22px] font-bold leading-tight tracking-[-0.015em]'>
                {profileUser?.username}
              </p>
              {isOwnPage && <MenuSettings />}
            </div>
            <div className='@[480px]:w-auto flex w-full max-w-[480px] gap-3'>
              {!isOwnPage && (
                <FollowButtons profileUser={profileUser} user={user} />
              )}
            </div>
          </div>
        </div>
      </div>
      <div className='flex flex-wrap gap-3'>
        <div className='flex min-w-[100px] flex-1 basis-[fit-content] flex-col items-start'>
          <p className='tracking-light text-2xl font-bold leading-tight'>0</p>
          <div className='flex items-center gap-2'>
            <p className='text-sm font-normal leading-normal'>posts</p>
          </div>
        </div>
        <div className='flex min-w-[100px] flex-1 basis-[fit-content] flex-col items-start'>
          <p className='tracking-light text-2xl font-bold leading-tight'>
            {followersCount}
          </p>
          <div className='flex items-center gap-2'>
            <p className='text-sm font-normal leading-normal'>followers</p>
          </div>
        </div>
        <div className='flex min-w-4 flex-[100px] basis-[fit-content] flex-col items-start'>
          <p className='tracking-light text-2xl font-bold leading-tight'>
            {followingCount}
          </p>
          <div className='flex items-center gap-2'>
            <p className='text-sm font-normal leading-normal'>following</p>
          </div>
        </div>
      </div>
    </div>
  )
}
