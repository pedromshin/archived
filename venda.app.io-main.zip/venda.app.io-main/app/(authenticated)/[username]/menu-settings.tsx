import { Button } from '@/registry/new-york/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/registry/new-york/ui/dropdown-menu'
import { LogoutLink } from '@kinde-oss/kinde-auth-nextjs/components'
import { WrenchIcon } from 'lucide-react'
import Link from 'next/link'

interface iAppProps {
  className?: string
}

export function MenuSettings({ className }: iAppProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant='ghost'
          className={`relative h-8 w-8 rounded-full ${className}`}
        >
          <WrenchIcon className='h-[1.4rem]  min-w-[1.4rem]' />
          {/* <Avatar className={`h-8 w-8 ${className}`}>
            <AvatarImage
              src={
                user.picture ??
                `https://secure.gravatar.com/avatar/46922c4d0387348f51d2c5fa76f4aec3?s=96&d=mm&r=g`
              }
              alt="User Image"
            />
            <AvatarFallback>{user?.given_name.slice(0, 3)}</AvatarFallback>
          </Avatar> */}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className='w-56' align='end' forceMount>
        {/* <DropdownMenuLabel className='font-normal'>
          <div className='flex flex-col space-y-1'>
            <p className='text-sm font-medium leading-none'>{user?.username}</p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator /> */}
        <DropdownMenuGroup>
          <DropdownMenuItem asChild>
            <Link href='/settings'>Settings</Link>
          </DropdownMenuItem>
          {/* <DropdownMenuItem asChild>
            <Link href='/billing'>Billing</Link>
          </DropdownMenuItem> */}
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <LogoutLink>Log out</LogoutLink>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
