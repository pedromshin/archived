import { Users, init } from '@kinde/management-api-js'
import {
  HomeIcon,
  MessageCircle,
  PlusCircleIcon,
  SearchIcon,
  ShoppingBagIcon,
  UserIcon
} from 'lucide-react'
import React from 'react'
import ClientMutedLinkButton from '../../components/client-muted-link-button'
import {
  getKindeServerSession,
  RegisterLink
} from '@kinde-oss/kinde-auth-nextjs/server'
import MenuConversations from '@/components/menu-conversations'
import { SheetTrigger } from '@/registry/new-york/ui/sheet'
import MenuConversation from '@/components/menu-conversations'

init()

export async function MobileNavbar({ className }: any) {
  const { getUser } = getKindeServerSession()
  const kindeUser = await getUser()
  const kindeId = kindeUser?.id

  let username = ''
  if (kindeId) {
    const userProperties = await Users.getUserPropertyValues({
      userId: kindeId
    })
    username =
      userProperties?.properties?.find(property => property.key === 'username')
        ?.value || ''
  }

  const menuItems = [
    // { href: '/home', name: <HomeIcon />, id: '1' },
    { href: '/search', name: <SearchIcon />, id: '2' },
    // { href: '/sell', name: <PlusCircleIcon />, id: '3' },
    // { href: '/wishlist', name: <ShoppingBagIcon />, id: '4' },
    {
      href: '/conversations',
      name: <MessageCircle className='h-[1.4rem] w-[1.4rem]' />,
      registerAnchor: !kindeUser,
      id: '3'
    },

    {
      href: `/${username}`,
      name: <UserIcon />,
      id: '5',
      registerAnchor: !kindeUser
    }
  ]

  return (
    <nav
      className={`fixed bottom-0 left-0 right-0 border-t border-border/40 bg-background/95 shadow-lg backdrop-blur supports-[backdrop-filter]:bg-background/60 lg:hidden ${className}`}
    >
      <div className='mx-4 flex justify-around py-2'>
        <ClientMutedLinkButton items={menuItems} />
      </div>
    </nav>
  )
}
