import { MobileNavbar } from '@/app/(authenticated)/mobile-navbar'
import { ReactNode } from 'react'

type Props = { children: ReactNode }

export default async function AuthenticatedLayout({ children }: Props) {
  return (
    <div className='container max-w-screen-2xl overflow-x-hidden pb-16'>
      {children}
      {<MobileNavbar />}
    </div>
  )
}
