'use client'
import { useEffect, useState } from 'react'
import { trpc } from '@/server/client'
import {
  Avatar,
  AvatarFallback,
  AvatarImage
} from '@/registry/new-york/ui/avatar'
import { Skeleton } from '@/registry/new-york/ui/skeleton'
import Link from 'next/link'

export default function RecentUsers() {
  const {
    data: users,
    isLoading,
    refetch
  } = trpc.profile.getRecentUsers.useQuery()

  useEffect(() => {
    refetch()
  }, [refetch])

  return (
    <div className='mt-5 flex flex-col gap-4 space-y-1'>
      {isLoading
        ? [...Array(5)].map((_, index) => (
            <div key={index} className='flex w-full items-center px-4 py-3'>
              <Skeleton className='h-10 w-10 rounded-full' />
              <div className='ml-4 flex-1 space-y-2'>
                <Skeleton className='h-4 w-1/3' />
                <Skeleton className='h-3 w-2/3' />
              </div>
            </div>
          ))
        : !!users?.length &&
          users.map(user => (
            <li key={user.id} className='flex flex-col rounded-md bg-secondary'>
              <Link
                href={`/${user.username}`}
                className='flex w-full items-center px-4 py-3 text-start'
              >
                <div className='flex min-w-0 items-center'>
                  {user.picture ? (
                    <div
                      className='aspect-square min-h-10 w-10 rounded-full bg-cover bg-center bg-no-repeat'
                      style={{
                        backgroundImage: `url("${user.picture}"), url('https://secure.gravatar.com/avatar/46922c4d0387348f51d2c5fa76f4aec3?s=96&d=mm&r=g')`
                      }}
                    />
                  ) : (
                    <Avatar className='min-h-10 w-10'>
                      <AvatarImage
                        src={
                          user.picture ??
                          'https://secure.gravatar.com/avatar/46922c4d0387348f51d2c5fa76f4aec3?s=96&d=mm&r=g'
                        }
                        alt='User Image'
                      />
                      <AvatarFallback>
                        {user.username.slice(0, 3)}
                      </AvatarFallback>
                    </Avatar>
                  )}
                  <div className='ml-4 min-w-0 flex-1 flex-col'>
                    <p className='text-md truncate font-bold leading-tight tracking-[-0.015em]'>
                      {user.username}
                    </p>
                    <p className='truncate text-sm'>{user.name || 'No Name'}</p>
                  </div>
                </div>
              </Link>
            </li>
          ))}
    </div>
  )
}
