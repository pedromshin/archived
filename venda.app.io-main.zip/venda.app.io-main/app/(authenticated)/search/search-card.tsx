'use client'
import { Input } from '@/registry/new-york/ui/input'
import {
  Avatar,
  AvatarFallback,
  AvatarImage
} from '@/registry/new-york/ui/avatar'
import { CardContent } from '@/registry/new-york/ui/card'
import { trpc } from '@/server/client'
import Link from 'next/link'
import { useEffect, useState } from 'react'

export default function SearchCard() {
  const [users, setUsers] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [debouncedTerm, setDebouncedTerm] = useState('') // New state for debounced search term
  const searchUsers = trpc.profile.searchUsers.useQuery(
    { query: debouncedTerm },
    { enabled: false }
  ) // Disable automatic query

  // Debounce logic: Update debouncedTerm after a delay
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedTerm(searchTerm)
    }, 250) // Delay of 500ms

    return () => {
      clearTimeout(handler)
    }
  }, [searchTerm])

  const handleSearch = (event: any) => {
    const term = event.target.value
    setSearchTerm(term)
  }

  // Load search term from local storage on component mount
  useEffect(() => {
    const savedSearchTerm = localStorage.getItem('searchTerm')
    if (savedSearchTerm) {
      setSearchTerm(savedSearchTerm)
      searchUsers.refetch() // Trigger search for the saved term
    }
  }, [])

  // Fetch users whenever the debounced search term changes
  useEffect(() => {
    localStorage.setItem('searchTerm', searchTerm)
    if (debouncedTerm.length >= 1) {
      searchUsers
        .refetch()
        .then(data => {
          setUsers(data.data || [])
        })
        .catch(error => {
          console.error('Error fetching users:', error)
          setUsers([])
        })
    } else {
      setUsers([])
    }
  }, [debouncedTerm])

  return (
    <>
      <Input
        placeholder='find people'
        value={searchTerm}
        onChange={handleSearch}
      />
      {!!users.length && (
        <CardContent className='mt-4 flex flex-col gap-6 rounded-md bg-secondary pt-4'>
          {users.map((user: any) => (
            <Link key={user?.id} href={`/${user?.username}`}>
              <li className='flex min-w-full flex-row items-stretch gap-4'>
                {user?.picture ? (
                  <div
                    className='aspect-square min-h-10 w-10 rounded-full bg-cover bg-center bg-no-repeat'
                    style={{ backgroundImage: `url("${user?.picture}")` }}
                  />
                ) : (
                  <Avatar className='min-h-10 w-10'>
                    <AvatarImage
                      src={
                        user?.picture ??
                        'https://secure.gravatar.com/avatar/46922c4d0387348f51d2c5fa76f4aec3?s=96&d=mm&r=g'
                      }
                      alt='User Image'
                    />
                    <AvatarFallback>
                      {user?.username?.slice(0, 3)}
                    </AvatarFallback>
                  </Avatar>
                )}
                <div className='flex w-full max-w-[calc(100vw-128px)] flex-col justify-between'>
                  <div className='flex w-full flex-col justify-between'>
                    <p className='text-md truncate font-bold leading-tight tracking-[-0.015em]'>
                      {user?.username}
                    </p>
                    <p className='truncate text-sm'>{user?.name}</p>
                  </div>
                </div>
              </li>
            </Link>
          ))}
        </CardContent>
      )}
    </>
  )
}
