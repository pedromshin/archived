import RecentUsers from './recent-registers'
import SearchCard from './search-card'

export default function Search() {
  return (
    <div className='mt-4'>
      <SearchCard />
      <RecentUsers />
    </div>
  )
}
