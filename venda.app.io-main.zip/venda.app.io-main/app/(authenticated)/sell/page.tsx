export default function Sell() {
  return <>Sell</>
}
