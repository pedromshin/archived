export default function Wishlist() {
  return <>Wishlist</>
}
