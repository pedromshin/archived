import LandingPage from '@/components/landing-page'

export default async function Home() {
  return <LandingPage />
}
