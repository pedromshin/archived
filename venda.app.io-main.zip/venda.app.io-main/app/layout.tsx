import type { Metadata, Viewport } from 'next'
import 'public/registry/themes.css'
import '@/styles/globals.css'
import { ThemeProvider } from '@/providers/theme-provider'
import { Analytics } from '@vercel/analytics/react'
import { ThemeWrapper } from '@/app/theme-wrapper'
import { cn } from '@/lib/utils'
import { fontSans } from '@/lib/fonts'
import { siteConfig } from '@/config/site'

import { SiteHeader } from '@/components/site-header'
import { TRPCProvider } from '@/providers/trpc-provider'

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: 'white' },
    { media: '(prefers-color-scheme: dark)', color: 'black' }
  ]
}

export const metadata: Metadata = {
  title: {
    default: siteConfig.name,
    template: `%s - ${siteConfig.name}`
  },
  metadataBase: new URL(siteConfig.url || ''),
  description: siteConfig.description,
  keywords: ['Social', 'Marketplace', 'Sales', 'Network'],
  authors: [
    {
      name: 'pedro shin',
      url: 'https://pedroshin.dev'
    }
  ],
  creator: 'shadcn',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: siteConfig.url,
    title: siteConfig.name,
    description: siteConfig.description,
    siteName: siteConfig.name
  },
  icons: {
    icon: '/icon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png'
  },
  manifest: `${siteConfig.url}/site.webmanifest`
}

export default async function RootLayout({
  children
}: {
  children: React.ReactNode
}) {
  return (
    <html lang='en' suppressHydrationWarning>
      <body
        className={cn(
          'min-h-screen bg-background font-sans antialiased',
          fontSans.variable
        )}
      >
        <TRPCProvider>
          <ThemeProvider
            attribute='class'
            defaultTheme='system'
            enableSystem
            disableTransitionOnChange
          >
            <ThemeWrapper>
              <SiteHeader />
              {children}
            </ThemeWrapper>
            <Analytics />
          </ThemeProvider>
        </TRPCProvider>
      </body>
    </html>
  )
}
