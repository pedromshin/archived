// src/app/api/searchUsers/route.js

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET(request: any) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get('query')

  if (!query || query.length < 3) {
    return new Response(
      JSON.stringify({ message: 'Query must be at least 3 characters long' }),
      { status: 400 }
    )
  }

  try {
    const users = await prisma.user.findMany({
      where: {
        OR: [
          { name: { contains: query, mode: 'insensitive' } },
          { email: { contains: query, mode: 'insensitive' } }
        ]
      }
    })
    return new Response(JSON.stringify(users), { status: 200 })
  } catch (error) {
    return new Response(
      JSON.stringify({ message: 'Error retrieving users', error }),
      { status: 500 }
    )
  }
}
