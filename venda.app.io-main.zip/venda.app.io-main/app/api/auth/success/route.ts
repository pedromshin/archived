import { PrismaClient } from '@prisma/client'
import { getKindeServerSession } from '@kinde-oss/kinde-auth-nextjs/server'
import { NextResponse } from 'next/server'
import { Users } from '@kinde/management-api-js'

const prisma = new PrismaClient()

export async function GET() {
  const { getUser } = getKindeServerSession()
  const user = await getUser()
  const kindeId = user?.id

  if (!user || !user.id) {
    return NextResponse.json(
      { error: 'User not found or not authenticated' },
      { status: 401 }
    )
  } else {
    let dbUser = await prisma.user.findUnique({
      where: { kindeId }
    })

    const kindeUserProperties = await Users.getUserPropertyValues({
      userId: user?.id
    })

    const kindeUsername =
      kindeUserProperties?.properties?.find(
        property => property?.key === 'username'
      )?.value || ''

    if (!dbUser) {
      dbUser = await prisma.user.create({
        data: {
          kindeId,
          email: user?.email || '',
          family_name: user?.family_name || '',
          given_name: user?.given_name || '',
          picture: user?.picture || '',
          name: (user?.given_name || '') + ' ' + (user?.family_name || ''),
          phone_number: user?.phone_number || '',
          username: kindeUsername,
          properties: undefined,
          followers: undefined,
          following: undefined,
          conversations: undefined,
          message: undefined
        }
      })
    }
  }

  return NextResponse.redirect('/home')
}
