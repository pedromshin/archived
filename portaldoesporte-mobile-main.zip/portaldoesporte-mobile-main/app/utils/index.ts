export const endpoint = process.env.EXPO_PUBLIC_ENDPOINT;
