import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { NavigationContainer } from "@react-navigation/native";

// import Feed from "./feed";
// import PrivacyPolicy from "./privacy-policy";
// import Forums from "./forums";
// import Map from "./map";
// import Memberships from "./memberships";
// import Register from "./register";
// import Login from "./login";
// import CreateSubscribable from "./create-subscribable";
import withLayout from "../components/withLayout";
import Register from "../screens/register";

export const routes = {
  pageRoot: "Root",
  pageFeed: "Feed",
  pageForums: "Forums",
  pageMap: "Map",
  pageMemberships: "Memberships",
  pageRegister: "Register",
  pageLogin: "Login",
  pageCreateSubscribable: "CreateSubscribable",
  pagePrivacyPolicy: "PrivacyPolicy",
} as const;

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// const TabNavigator = () => {
//   return (
//     <Tab.Navigator>
//       <Tab.Screen name={routes.pageFeed} component={withLayout(Feed)} />
//       <Tab.Screen name={routes.pageForums} component={withLayout(Forums)} />
//       <Tab.Screen name={routes.pageMap} component={withLayout(Map)} />
//       <Tab.Screen
//         name={routes.pageMemberships}
//         component={withLayout(Memberships)}
//       />
//     </Tab.Navigator>
//   );
// };

const AppNavigator = () => {
  return (
    <Stack.Navigator initialRouteName={routes.pageRoot}>
      {/* <Stack.Screen
        name={routes.pageRoot}
        component={TabNavigator}
        options={{ headerShown: false }}
      /> */}
      <Stack.Screen
        name={routes.pageRegister}
        component={withLayout(Register)}
      />
      {/* <Stack.Screen name={routes.pageLogin} component={withLayout(Login)} />
      <Stack.Screen
        name={routes.pageCreateSubscribable}
        component={withLayout(CreateSubscribable)}
      />
      <Stack.Screen
        name={routes.pagePrivacyPolicy}
        component={withLayout(PrivacyPolicy)}
      /> */}
    </Stack.Navigator>
  );
};

const Navigation = () => {
  return (
    <NavigationContainer independent>
      <AppNavigator />
    </NavigationContainer>
  );
};

export default Navigation;
