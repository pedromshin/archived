// types.ts
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { BottomTabNavigationProp } from "@react-navigation/bottom-tabs";

export type RootStackParamList = {
  Root: undefined;
  Register: undefined;
  Login: undefined;
  CreateSubscribable: undefined;
  PrivacyPolicy: undefined;
};

export type RootTabParamList = {
  Feed: undefined;
  Forums: undefined;
  Map: undefined;
  Memberships: undefined;
};

export type StackNavigationProps =
  NativeStackNavigationProp<RootStackParamList>;
export type TabNavigationProps = BottomTabNavigationProp<RootTabParamList>;
