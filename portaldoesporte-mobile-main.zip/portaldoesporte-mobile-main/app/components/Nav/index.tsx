import React from "react";
import { View, TouchableOpacity, StyleSheet } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import {
  IconHome,
  IconMap,
  IconSubtask,
  IconComponents,
} from "@tabler/icons-react";
import { routes } from "../../../app/navigation";
import { BottomTabNavigationProp } from "@react-navigation/bottom-tabs";
import { RootTabParamList } from "@/app/navigation/types";

import Icon from "react-native-vector-icons/MaterialIcons";

const Nav = () => {
  const navigation = useNavigation<BottomTabNavigationProp<RootTabParamList>>();
  const route = useRoute();
  const pathname = route.name;

  return (
    <View style={styles.container}>
      <View style={styles.list}>
        <TouchableOpacity
          style={[styles.item, pathname === routes.pageFeed && styles.selected]}
          onPress={() => navigation.navigate(routes.pageFeed)}
        >
          <Icon name="home" size={24} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.item,
            pathname === routes.pageForums && styles.selected,
          ]}
          onPress={() => navigation.navigate(routes.pageForums)}
        >
          <Icon name="task" size={24} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.item, pathname === routes.pageMap && styles.selected]}
          onPress={() => navigation.navigate(routes.pageMap)}
        >
          <Icon name="map" size={24} />
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.item,
            pathname === routes.pageMemberships && styles.selected,
          ]}
          onPress={() => navigation.navigate(routes.pageMemberships)}
        >
          <Icon name="widgets" size={24} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    bottom: 0,
    width: "100%",
    backgroundColor: "white",
  },
  list: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 10,
  },
  item: {
    alignItems: "center",
    padding: 12,
  },
  selected: {
    borderColor: "red",
    borderWidth: 1,
  },
});

export default Nav;
