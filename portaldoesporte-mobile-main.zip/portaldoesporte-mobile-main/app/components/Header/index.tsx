import React, { useState, useEffect, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Linking,
} from "react-native";
import { useAuth } from "../../hooks/useAuth";

const Header = ({ navigation }: any) => {
  const { auth, logout } = useAuth();
  const [confirmLogout, setConfirmLogout] = useState(false);
  const buttonRef = useRef<any>(null);

  const handleLogout = () => {
    setConfirmLogout(false);
    logout();
  };

  useEffect(() => {
    if (confirmLogout) {
      buttonRef.current?.focus();
    }
  }, [confirmLogout]);

  return (
    <View style={styles.headerWrapper}>
      <TouchableOpacity onPress={() => Linking.openURL("your-external-link")}>
        <Text style={styles.styledLink}>
          É atleta ou dono de academia, clube, centro de treinamento, etc? Abra
          agora sua página oficial!
        </Text>
      </TouchableOpacity>
      <View style={styles.authActions}>
        {!auth ? (
          <>
            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.navigate("Login")}
            >
              <Text style={styles.buttonText}>Fazer login</Text>
            </TouchableOpacity>
            <Text style={styles.text}>ou</Text>
            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.navigate("Register")}
            >
              <Text style={styles.buttonText}>Cadastrar</Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <Text style={styles.text}>
              Olá, {auth?.decodedToken?.username}!
            </Text>
            {!confirmLogout ? (
              <TouchableOpacity
                style={styles.button}
                onPress={() => setConfirmLogout(true)}
              >
                <Text style={styles.buttonText}>Logout</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                ref={buttonRef}
                style={styles.confirmLogout}
                onPress={handleLogout}
                onBlur={() => setConfirmLogout(false)}
              >
                <Text style={styles.buttonText}>Confirmar</Text>
              </TouchableOpacity>
            )}
          </>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  headerWrapper: {
    width: "100%",
    padding: 20,
    backgroundColor: "#f8f9fa",
    borderBottomWidth: 1,
    borderBottomColor: "#ddd",
  },
  styledLink: {
    color: "#007bff",
    fontSize: 16,
    marginBottom: 20,
  },
  authActions: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
  },
  button: {
    backgroundColor: "#007bff",
    borderRadius: 5,
    padding: 10,
    margin: 5,
  },
  confirmLogout: {
    backgroundColor: "crimson",
    borderRadius: 5,
    padding: 10,
    margin: 5,
  },
  buttonText: {
    color: "white",
    fontSize: 16,
  },
  text: {
    fontSize: 16,
    marginHorizontal: 10,
  },
});

export default Header;
