import React from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";
import { useForm, Controller } from "react-hook-form";
import axios from "axios";
import { endpoint } from "../../utils";
import { useAuth } from "../../hooks/useAuth";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from "@react-navigation/native";

// Constants
const fixedText = "@";

// Registration Page Component
const Register = () => {
  const { setDecodedToken } = useAuth();
  const {
    control,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();
  const navigation = useNavigation();

  const handleUsernameChange = (value: string) => {
    if (!value.startsWith(fixedText)) {
      setValue("username", fixedText + value);
    } else {
      setValue("username", value);
    }
  };

  const onSubmit = async (data: any) => {
    try {
      const response = await axios.post(`${endpoint}/user`, data);
      const { access_token } = response.data;
      await AsyncStorage.setItem("access_token", access_token);
      setDecodedToken(access_token);
      //   navigation.navigate("Memberships");
    } catch (error: any) {
      console.error("Registration error:", error?.response?.data);
      Alert.alert("Registration failed", "Please try again.");
    }
  };

  return (
    <View style={styles.pageWrapper}>
      <Text style={styles.title}>Criar uma conta</Text>
      {/*  */}
      <View style={styles.form}>
        <Controller
          control={control}
          name="username"
          rules={{ required: "Username is required." }}
          render={({ field: { onChange, onBlur, value } }) => (
            <View style={styles.formGroup}>
              <Text style={styles.label}>Username</Text>
              <TextInput
                style={[styles.input, errors.username && styles.errorInput]}
                onBlur={onBlur}
                onChangeText={(value) => {
                  onChange(value);
                  handleUsernameChange(value);
                }}
                value={value}
                placeholder="@"
              />
              {errors.username && (
                <Text style={styles.errorMessage}>
                  {String(errors.username.message)}
                </Text>
              )}
            </View>
          )}
        />
        <Controller
          control={control}
          name="name"
          rules={{ required: "Name is required." }}
          render={({ field: { onChange, onBlur, value } }) => (
            <View style={styles.formGroup}>
              <Text style={styles.label}>Nome</Text>
              <TextInput
                style={[styles.input, errors.name && styles.errorInput]}
                onBlur={onBlur}
                onChangeText={onChange}
                value={value}
                placeholder="Nome"
              />
              {errors.name && (
                <Text style={styles.errorMessage}>
                  {String(errors.name.message)}
                </Text>
              )}
            </View>
          )}
        />
        <Controller
          control={control}
          name="email"
          rules={{
            required: "Email is required.",
            pattern: {
              value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
              message: "Enter a valid email address.",
            },
          }}
          render={({ field: { onChange, onBlur, value } }) => (
            <View style={styles.formGroup}>
              <Text style={styles.label}>E-mail</Text>
              <TextInput
                style={[styles.input, errors.email && styles.errorInput]}
                onBlur={onBlur}
                onChangeText={onChange}
                value={value}
                placeholder="E-mail"
                keyboardType="email-address"
              />
              {errors.email && (
                <Text style={styles.errorMessage}>
                  {String(errors.email.message)}
                </Text>
              )}
            </View>
          )}
        />
        <Controller
          control={control}
          name="phoneNumber"
          rules={{
            required: "Phone number is required.",
            pattern: {
              value: /^\d{10,15}$/,
              message: "Enter a valid phone number (10-15 digits).",
            },
          }}
          render={({ field: { onChange, onBlur, value } }) => (
            <View style={styles.formGroup}>
              <Text style={styles.label}>Celular</Text>
              <TextInput
                style={[styles.input, errors.phoneNumber && styles.errorInput]}
                onBlur={onBlur}
                onChangeText={onChange}
                value={value}
                placeholder="Celular"
                keyboardType="phone-pad"
              />
              {errors.phoneNumber && (
                <Text style={styles.errorMessage}>
                  {String(errors.phoneNumber.message)}
                </Text>
              )}
            </View>
          )}
        />
        <Controller
          control={control}
          name="otp"
          render={({ field: { onChange, onBlur, value } }) => (
            <View style={styles.formGroup}>
              <Text style={styles.label}>Código de verificação</Text>
              <TextInput
                style={styles.input}
                onBlur={onBlur}
                onChangeText={onChange}
                value={value}
                placeholder="Código de verificação enviado ao e-mail ou celular"
                editable={false}
              />
            </View>
          )}
        />
        <Controller
          control={control}
          name="password"
          rules={{
            required: "Password is required.",
            minLength: {
              value: 8,
              message: "Password must be at least 8 characters long.",
            },
          }}
          render={({ field: { onChange, onBlur, value } }) => (
            <View style={styles.formGroup}>
              <Text style={styles.label}>Senha</Text>
              <TextInput
                style={[styles.input, errors.password && styles.errorInput]}
                onBlur={onBlur}
                onChangeText={onChange}
                value={value}
                placeholder="Crie uma senha (mínimo 8 caracteres)"
                secureTextEntry
              />
              {errors.password && (
                <Text style={styles.errorMessage}>
                  {String(errors.password.message)}
                </Text>
              )}
            </View>
          )}
        />
        <TouchableOpacity
          style={styles.submitButton}
          onPress={handleSubmit(onSubmit)}
        >
          <Text style={styles.buttonText}>Confirmar cadastro</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.buttonText}>Voltar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

// Styles
const styles = StyleSheet.create({
  pageWrapper: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#ffffff",
  },
  title: {
    fontSize: 24,
    color: "#333",
    marginBottom: 20,
  },
  form: {
    width: "100%",
  },
  formGroup: {
    marginBottom: 15,
  },
  label: {
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5,
  },
  input: {
    width: "100%",
    padding: 10,
    borderColor: "#ddd",
    borderWidth: 1,
    borderRadius: 4,
    fontSize: 16,
  },
  errorInput: {
    borderColor: "red",
  },
  errorMessage: {
    color: "red",
    fontSize: 14,
    marginTop: 5,
  },
  submitButton: {
    marginTop: 10,
    padding: 10,
    backgroundColor: "#007bff",
    borderRadius: 4,
    alignItems: "center",
  },
  backButton: {
    marginTop: 10,
    padding: 10,
    backgroundColor: "#6c757d",
    borderRadius: 4,
    alignItems: "center",
  },
  buttonText: {
    color: "white",
    fontSize: 16,
  },
});

export default Register;
