import { Baloo_2, Outfit } from "next/font/google";

export const baloo2 = Baloo_2({ subsets: ["latin"] });
export const outfit = Outfit({ subsets: ["latin"] });
