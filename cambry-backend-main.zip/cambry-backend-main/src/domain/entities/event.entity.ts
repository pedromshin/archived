import { Document } from 'mongoose';

export class EventEntity extends Document {
  name: string;
}
