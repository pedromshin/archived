import { Body, Controller, Param, Put, UsePipes } from '@nestjs/common';
import { UpdateEventUseCase } from './update-event.usecase';
import { z } from 'zod';
import { ZodValidationPipe, createZodDto } from '@anatine/zod-nestjs';
import { extendApi } from '@anatine/zod-openapi';

const updateEventDTOSchema = extendApi(
  z.object({
    name: z.string(),
  }),
);

export class updateEventDTO extends createZodDto(updateEventDTOSchema) {}

@UsePipes(ZodValidationPipe)
@Controller('events')
export class UpdateEventController {
  constructor(private updateEventUseCase: UpdateEventUseCase) {}

  @Put(':_id')
  async findById(@Param() _id: string, @Body() event: updateEventDTO) {
    return this.updateEventUseCase.execute(_id, event);
  }
}
