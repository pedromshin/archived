import { Controller, Get, Param } from '@nestjs/common';
import { FindByIdEventUseCase } from './find-by-id-event.usecase';

@Controller('events')
export class FindByIdEventController {
  constructor(private findByIdUseCase: FindByIdEventUseCase) {}

  @Get(':_id')
  async findById(@Param() _id: string) {
    return this.findByIdUseCase.execute(_id);
  }
}
