import { Injectable } from '@nestjs/common';
import { EventRepository } from 'src/application/repositories/event.repository';

@Injectable()
export class FindByIdEventUseCase {
  constructor(private readonly eventRepository: EventRepository) {}

  async execute(payload: string) {
    return await this.eventRepository.findOne(payload);
  }
}
