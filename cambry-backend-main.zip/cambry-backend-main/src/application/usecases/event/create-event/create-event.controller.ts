import { Body, Controller, Post, UsePipes } from '@nestjs/common';
import { CreateEventUsecase } from './create-event.usecase';
import { EventEntity } from 'src/domain/entities/event.entity';
import { z } from 'zod';
import { ZodValidationPipe, createZodDto } from '@anatine/zod-nestjs';
import { extendApi } from '@anatine/zod-openapi';

const createEventDTOSchema = extendApi(
  z.object({
    name: z.string(),
  }),
);

export class createEventDTO extends createZodDto(createEventDTOSchema) {}

@UsePipes(ZodValidationPipe)
@Controller('events')
export class CreateEventController {
  constructor(private createEventUsecase: CreateEventUsecase) {}

  @Post()
  async create(@Body() event: createEventDTO): Promise<EventEntity> {
    return this.createEventUsecase.execute(event);
  }
}
