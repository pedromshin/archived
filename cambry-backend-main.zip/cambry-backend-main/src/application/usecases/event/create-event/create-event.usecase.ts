import { Injectable } from '@nestjs/common';
import { EventRepository } from 'src/application/repositories/event.repository';

@Injectable()
export class CreateEventUsecase {
  constructor(private readonly eventRepository: EventRepository) {}

  async execute(payload) {
    const result = await this.eventRepository.create(payload);
    return result;
  }
}
