import { Injectable } from '@nestjs/common';
import { EventRepository } from 'src/application/repositories/event.repository';

@Injectable()
export class DeleteEventUseCase {
  constructor(private readonly eventRepository: EventRepository) {}

  async execute(payload: string) {
    const result = await this.eventRepository.delete(payload);
    return result;
  }
}
