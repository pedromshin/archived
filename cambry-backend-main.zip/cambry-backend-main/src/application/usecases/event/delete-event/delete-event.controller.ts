import { Controller, Delete, Param } from '@nestjs/common';
import { DeleteEventUseCase } from './delete-event.usecase';

@Controller('events')
export class DeleteEventController {
  constructor(private deleteEventUseCase: DeleteEventUseCase) {}

  @Delete(':_id')
  async delete(@Param() _id: string) {
    return this.deleteEventUseCase.execute(_id);
  }
}
