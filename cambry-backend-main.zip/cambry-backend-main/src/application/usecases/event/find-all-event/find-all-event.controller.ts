import { Controller, Get, Query } from '@nestjs/common';
import { FindAllEventUseCase } from './find-all-event.usecase';

@Controller('events')
export class FindAllEventController {
  constructor(private findAllEventUseCase: FindAllEventUseCase) {}

  @Get()
  async findAll(@Query('name') name: string) {
    return this.findAllEventUseCase.execute(name);
  }
}
