import { Injectable } from '@nestjs/common';
import { EventRepository } from 'src/application/repositories/event.repository';

@Injectable()
export class FindAllEventUseCase {
  constructor(private readonly eventRepository: EventRepository) {}

  async execute(name: string) {
    return await this.eventRepository.findAll(name);
  }
}
