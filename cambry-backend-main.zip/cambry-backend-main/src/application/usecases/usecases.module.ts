import { Module } from '@nestjs/common';

import { MongooseModule } from '@nestjs/mongoose';
import { EventSchema } from 'src/infra/mongo/schemas/event.schema';
import { RepositoriesModule } from '../repositories/repositories.module';
import { CreateEventUsecase } from './event/create-event/create-event.usecase';
import { CreateEventController } from './event/create-event/create-event.controller';
import { DeleteEventUseCase } from './event/delete-event/delete-event.usecase';
import { DeleteEventController } from './event/delete-event/delete-event.controller';
import { FindAllEventUseCase } from './event/find-all-event/find-all-event.usecase';
import { FindByIdEventUseCase } from './event/find-by-id-event/find-by-id-event.usecase';
import { UpdateEventUseCase } from './event/update-event/update-event.usecase';
import { FindAllEventController } from './event/find-all-event/find-all-event.controller';
import { FindByIdEventController } from './event/find-by-id-event/find-by-id-event.controller';
import { UpdateEventController } from './event/update-event/update-event.controller';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Event', schema: EventSchema }]),
    RepositoriesModule,
  ],
  controllers: [
    CreateEventController,
    DeleteEventController,
    FindAllEventController,
    FindByIdEventController,
    UpdateEventController,
  ],
  providers: [
    CreateEventUsecase,
    DeleteEventUseCase,
    FindAllEventUseCase,
    FindByIdEventUseCase,
    UpdateEventUseCase,
  ],
})
export class UseCaseModule {}
