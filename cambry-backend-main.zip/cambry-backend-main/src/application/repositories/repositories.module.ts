import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { EventSchema } from 'src/infra/mongo/schemas/event.schema';
import { EventRepository } from './event.repository';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Event', schema: EventSchema }]),
  ],
  providers: [EventRepository],
  exports: [EventRepository],
})
export class RepositoriesModule {}
