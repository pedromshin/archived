import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { EventEntity } from 'src/domain/entities/event.entity';

@Injectable()
export class EventRepository {
  constructor(
    @InjectModel('Event') private readonly model: Model<EventEntity>,
  ) {}

  async findAll(name: string): Promise<EventEntity[]> {
    const query = {};
    if (name) query['name'] = name;

    return await this.model.find(query);
  }

  async findOne(id: string): Promise<EventEntity> {
    return await this.model.findById(id).exec();
  }

  async create(event: EventEntity) {
    const newEvent = new this.model(event);

    return await newEvent.save();
  }

  async update(_id: string, event: EventEntity) {
    await this.model.updateOne({ _id: _id }, event);
    return await this.findOne(_id);
  }

  async delete(_id: string) {
    return await this.model.deleteOne({ _id: _id }).exec();
  }
}
