import { githubClient } from "@/app/clients/githubClient"

export async function POST(req: Request) {
    const body = await req.json()

    const PROJECT_NAME = body.projectName

    try {
        const repository = await githubClient.request('POST /repos/pedromshin/propsite.preview/generate', {
            owner: 'pedromshin',
            name: PROJECT_NAME,
            description: 'This is your first repository',
            include_all_branches: false,
            private: true,
            headers: {
                'X-GitHub-Api-Version': '2022-11-28'
            }
        })

        try {
            const result =  await fetch(`${process.env.NEXT_PUBLIC_URL}/api/create-project`, { method: "POST", body: JSON.stringify({ projectName: PROJECT_NAME }) }).then((res) => res.json())

            return Response.json(result)
        } catch (e) {
            console.log(e)
            return Response.json(e)
        }
    } catch (e) {
        console.log(e)
        return Response.json(e)
    }
}