export async function POST(req: Request) {
    const body = await req.json()

    const PROJECT_NAME = body.projectName

    try {
        const project = await fetch("https://api.vercel.com/v9/projects?teamId=pedromshin", {
            body: JSON.stringify({
                name: PROJECT_NAME,
                framework: "nextjs",
                gitRepository: {
                    repo: PROJECT_NAME,
                    type: "github"
                },
            }),
            headers: {
                Authorization: `Bearer ${process.env.VERCEL_TOKEN}`
            },
            method: "post"
        }).then((res) => res.json())

        try {
            const result = await fetch(`${process.env.NEXT_PUBLIC_URL}/api/create-deployment`, { method: "POST", body: JSON.stringify({ projectName: PROJECT_NAME }) }).then((res) => res.json())

            return Response.json(result)
        } catch (e) {
            console.log(e)
            return Response.json(e)
        }
    } catch (e) {
        console.log(e)
        return Response.json(e)
    }
}