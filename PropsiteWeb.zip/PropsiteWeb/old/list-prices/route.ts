import { route53DomainsClient } from "@/app/clients/route53DomainsClient"
import { ListPricesCommand, } from "@aws-sdk/client-route-53-domains"

const listPricesCommand = new ListPricesCommand({ MaxItems: 1000 })

export async function GET() {
    try {
        const listPrices = await route53DomainsClient.send(listPricesCommand)

        return Response.json(listPrices)
    } catch (e) {
        console.log(e)
        return Response.json(e)
    }
}