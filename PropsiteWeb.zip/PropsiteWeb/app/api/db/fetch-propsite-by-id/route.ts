import prisma from '@/lib/prisma'
import { notFound } from 'next/navigation'

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url)
    const name = searchParams.get('name') ?? undefined

    const propsite = await prisma.propsite.findFirst({
        where: {
                name
            },
        include: { pages: { where: { propsiteId: { equals: name || undefined } } } },
    })


    if (!propsite) {
        Response.json({
            error: 'Name already in use.',
        })
    }

    return Response.json(propsite)
}