import type { Prisma } from "@prisma/client"
import prisma from '@/lib/prisma'

export async function POST(req: Request) {
    try {
        if (!(req.body as any).name) {
            const post = await prisma.propsite.create({
                data: {},
                select: {
                    id: true,
                },
            })

            return Response.json(post)
        }

        const data: Prisma.PropsiteCreateInput = await req.json()

        const post = await prisma.propsite.create({
            data,
        })

        return Response.json(post)
    } catch (e) {
        throw e
    }
}