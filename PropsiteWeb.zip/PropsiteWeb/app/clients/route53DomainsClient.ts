import { Route53DomainsClient } from "@aws-sdk/client-route-53-domains";

export const route53DomainsClient = new Route53DomainsClient({
    region: "us-east-1",
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID ?? "",
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY ?? "",
    },
})