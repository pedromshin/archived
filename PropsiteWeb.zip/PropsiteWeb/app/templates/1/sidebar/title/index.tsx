"use client"
export default function Title({data}: {data: any}) {
    return (
        <>
            <span className='font-medium'>{data?.title}</span>
            <span className='text-xs'>{data?.subtitle}</span>
        </>
    )
}