import Preview1 from "../templates/1"
 
export default async function Page({ params }: { params: { name: string } }) {
  const data = await fetch(`${process.env.NEXT_PUBLIC_URL}/api/db/fetch-propsite-by-id?name=${params.name}`, { method: "GET" }).then((res) => res.json())
  
  return <Preview1 data={data}/>
}