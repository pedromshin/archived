export async function POST(req: Request) {
    const body = await req.json()

    const PROJECT_NAME = body.projectName

    try {
        const result = await fetch("https://api.vercel.com/v13/deployments?forceNew=0&skipAutoDetectionConfirmation=0&teamId=pedromshin", {
            body: JSON.stringify({
                name: PROJECT_NAME,
                gitSource: {
                    org: "pedromshin",
                    ref: "main",
                    repo: PROJECT_NAME,
                    type: "github",
                }
            }),
            headers: {
                Authorization: `Bearer ${process.env.VERCEL_TOKEN}`
            },
            method: "post"
        }).then((res) => res.json())

        return Response.json(result)
    } catch (e) {
        console.log(e)
        return Response.json(e)
    }
}