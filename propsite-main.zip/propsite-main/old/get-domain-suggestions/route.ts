import { route53DomainsClient } from "@/app/clients/route53DomainsClient"
import { GetDomainSuggestionsCommand, } from "@aws-sdk/client-route-53-domains"

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url)
    const DomainName = searchParams.get('DomainName') ?? ""

    try {
        const getDomainSuggestionsCommand = new GetDomainSuggestionsCommand({ DomainName, OnlyAvailable: true, SuggestionCount: 10 })
        const domainSuggestions = await route53DomainsClient.send(getDomainSuggestionsCommand)

        return Response.json(domainSuggestions)
    } catch (e) {
        console.log(e)
        return Response.json(e)
    }
}