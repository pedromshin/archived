export async function DELETE(req: Request) {
    const body = await req.json()

    const PROJECT_NAME = body.projectName

    try {
        const result = await fetch(`https://api.vercel.com/v9/projects/${PROJECT_NAME}?teamId=pedromshin`, {
            headers: {
                Authorization: `Bearer ${process.env.VERCEL_TOKEN}`
            },
            method: "delete"
        }).then((res) => res.json())

        return Response.json(result)
    } catch (e) {
        console.log(e)
        return Response.json(e)
    }
}