// const contactDetail: ContactDetail = { CountryCode: "BR", FirstName: "Pedro", LastName: "Shin", PhoneNumber: "+55.11991035010", ContactType: "PERSON", Email: "propsite.venda@gmail.com", City: "Sao Paulo", AddressLine1: "Rua Costa Carvalho", ZipCode: "05429-130" };
// const AdminContact: ContactDetail = { ...contactDetail };
// const RegistrantContact: ContactDetail = { ...contactDetail };
// const TechContact: ContactDetail = { ...contactDetail };
// const registerDomainCommand = new RegisterDomainCommand({ AdminContact, DomainName: selectedDomain?.DomainName, DurationInYears: 1, RegistrantContact, TechContact, PrivacyProtectAdminContact: true, PrivacyProtectBillingContact: true, PrivacyProtectRegistrantContact: true, PrivacyProtectTechContact: true })

// await route53DomainsClient.send(registerDomainCommand)

export async function POST() {
    try {

    } catch (e) {
        console.log(e)
        return Response.json(e)
    }
}