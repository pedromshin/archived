"use client"
import { SubmitHandler, useForm } from "react-hook-form";
import { DomainSuggestion, GetDomainSuggestionsCommandOutput, ListPricesCommandOutput } from "@aws-sdk/client-route-53-domains";
import { useEffect, useState } from "react";
import { Resizable, ResizableProps } from 'react-resizable';
import 'react-resizable/css/styles.css';
import { Prisma } from "@prisma/client";

type FormFields = {
    name: string;
    autoRenew: boolean;
    topLevelDomain: string;
    title: string;
    subtitle: string;
    description: string;
    pages: string;
}

export default function Home() {
    const [listPrices, setListPrices] = useState<ListPricesCommandOutput>()
    const [domainSuggestions, setDomainSuggestions] = useState<GetDomainSuggestionsCommandOutput>()
    const [selectedDomain, setSelectedDomain] = useState<DomainSuggestion>()
    const [deployedURL, setDeployedURL] = useState<string>()
    const [propsite, setPropsite] = useState<any>()
    const [size, setSize] = useState<{ width: number; height: number }>({ width: 300, height: 300 })

    const {
        register,
        handleSubmit,
        formState: { errors },
        watch
    } = useForm<FormFields>()

    const PROJECT_NAME = watch("name")
    const topLevelDomain = watch("topLevelDomain");
    let DomainName = "";

    if (PROJECT_NAME && topLevelDomain) {
        DomainName = PROJECT_NAME + "." + topLevelDomain;
    }

    const previewUrl = process.env.NEXT_PUBLIC_URL + (propsite ? `/${PROJECT_NAME}` : `/preview?name=${PROJECT_NAME}&?title=${watch("title")}&subtitle=${watch("subtitle")}&pages=${watch("pages")}`)

    const payload: Prisma.PropsiteCreateInput = {
        name: PROJECT_NAME,
        title: watch("title"),
        subtitle: watch("subtitle"),
        description: watch("description"),
        pages: {
            createMany: {
                data: watch("pages")?.split(",")?.map((item, index) => ({name: item, title: "", subtitle: "", description: "", order: index}))
            }
        }
    }


    const onResize: ResizableProps["onResize"] = (event, { node, size, handle }) => {
        setSize({ width: size.width, height: size.height });
    };

    const onSubmit: SubmitHandler<FormFields> = async () => {
        try {
            const domainSuggestions = await fetch(`${process.env.NEXT_PUBLIC_URL}/api/get-domain-suggestions?DomainName=${DomainName}`, { method: "GET" }).then((res) => res.json())
            setDomainSuggestions(domainSuggestions)
        } catch (e) {
            console.log(e)
        }
    }

    const registerDomain = async () => {

    }

    const createDeployment = async () => {
        try {
            await fetch(`${process.env.NEXT_PUBLIC_URL}/api/create-deployment`, { method: "POST", body: JSON.stringify({ projectName: PROJECT_NAME }) })
        } catch (e) {
            console.log(e)
        }
    }

    const createRepository = async () => {
        try {
            const pages = createPropsite()
            const repository = await fetch(`${process.env.NEXT_PUBLIC_URL}/api/create-repository`, { method: "POST", body: JSON.stringify({ projectName: PROJECT_NAME }) }).then(res => res.json())

            setDeployedURL("https://" + repository.url)
        } catch (e) {
            console.log(e)
        }
    }


    const createProject = async () => {
        try {
            await fetch(`${process.env.NEXT_PUBLIC_URL}/api/create-project`, { method: "POST", body: JSON.stringify({ projectName: PROJECT_NAME }) })
        } catch (e) {
            console.log(e)
        }
    }

    const deleteRepository = async () => {
        try {
            await fetch(`${process.env.NEXT_PUBLIC_URL}/api/delete-repository`, { method: "DELETE", body: JSON.stringify({ projectName: PROJECT_NAME }) })
        } catch (e) {
            console.log(e)
        }
    }

    const createPropsite = async () => {
        try {
            const propsite = await fetch(`${process.env.NEXT_PUBLIC_URL}/api/db/create-propsite`, { method: "POST", body: JSON.stringify(payload) })

            setPropsite(propsite)
        } catch (e) {
            console.log(e)
        }
    }

    useEffect(() => {
        (async () => {
            const listPrices: ListPricesCommandOutput = await fetch(`${process.env.NEXT_PUBLIC_URL}/api/list-prices`, { method: "get" }).then((res) => res.json());
            setListPrices(listPrices);
        })()

        if (typeof window !== "undefined") {
            setSize((prev) => ({ ...prev, width: window.innerWidth }))
        }
    }, [])


    return (
        <main>
            <div className="flex flex-col min-h-screen justify-between p-24">
            <div className="max-w-md mx-auto">

                <form onSubmit={handleSubmit(onSubmit)} className="mb-8">
                    <label className="block text-sm font-semibold mb-2">Name:</label>
                    <div className="flex flex-row p-2">
                        <input
                            className="w-full border border-gray-300 rounded py-2 px-3 focus:outline-none focus:border-blue-500"
                            {...register("name", { required: true })}
                        />
                        {errors.name && <span className="text-red-500 text-sm">This field is required</span>}
                        <select {...register("topLevelDomain", { required: false })} id="topLevelDomain" multiple className="border-2 border-black min-w-fit">
                            {listPrices?.Prices?.map(price => (<option key={price.Name} value={price.Name}>.{price.Name}</option>))}
                        </select>
                    </div>
                    <button
                        type="submit"
                        className="mt-4 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 focus:outline-none focus:shadow-outline-blue"
                    >
                        Submit
                    </button>
                </form>
                {!!domainSuggestions?.SuggestionsList && (
                    <div className="flex flex-col p-2">
                        {domainSuggestions.SuggestionsList.map((item) => {
                            const domainPrice = listPrices?.Prices?.find(price => price.Name === item.DomainName?.split(".")[1])?.RegistrationPrice

                            return <button
                                type="button"
                                className={`border-2 ${item.DomainName === selectedDomain?.DomainName ? "border-red-500" : "border-gray-300"
                                    } rounded py-2 px-4 mb-2`}
                                onClick={() => setSelectedDomain(item)}
                                key={item.DomainName}
                            >
                                {item.DomainName} - {domainPrice?.Currency} {domainPrice?.Price}
                            </button>
                        })}

                    </div>
                )}
                {selectedDomain && (
                    <button onClick={registerDomain}>registrar</button>
                )}
                <div className="flex flex-col p-2">
                    {/* <button onClick={createRepository} className="mt-2 border-2 border-black">criar repositorio e projeto {PROJECT_NAME}</button>
                    <button onClick={deleteRepository} className="mt-2 border-2 border-black">deletar repositorio e projeto {PROJECT_NAME}</button>
                    <button onClick={createDeployment} className="mt-2 border-2 border-black">criar deployment</button>
                    <button onClick={createProject} className="mt-2 border-2 border-black">criar projeto {PROJECT_NAME}</button> */}
                    <button onClick={createPropsite} className="mt-2 border-2 border-black">criar propsite {PROJECT_NAME}</button>
                </div>
                <input
                    className="w-full border border-gray-300 rounded py-2 px-3 focus:outline-none focus:border-blue-500 mt-2"
                    {...register("title", { required: true })}
                    placeholder="Título"
                />
                <input
                    className="w-full border border-gray-300 rounded py-2 px-3 focus:outline-none focus:border-blue-500 mt-2"
                    {...register("subtitle", { required: true })}
                    placeholder="Subtítulo"
                />
                <input
                    className="w-full border border-gray-300 rounded py-2 px-3 focus:outline-none focus:border-blue-500 mt-2"
                    {...register("description", { required: true })}
                    placeholder="Descricao"
                />
                <input
                    className="w-full border border-gray-300 rounded py-2 px-3 focus:outline-none focus:border-blue-500 mt-2"
                    {...register("pages", { required: true })}
                    placeholder="Páginas - separe por vírgula"
                />
            </div>
            <a className="my-2" href={deployedURL} target="_blank">{deployedURL}</a>
            {!!propsite && <a className="my-2" href={previewUrl} target="_blank">{previewUrl}</a>}
            <Resizable height={size.height} width={size.width} onResize={onResize}>
                <div className="box" style={{ width: size.width + 'px', height: size.height + 'px' }}>
                    <iframe src={`${previewUrl}`} style={{ width: size.width + 'px', height: size.height + 'px' }} className="border-2 border-black" />
                </div>
            </Resizable>
            </div>
        </main>
    )
}