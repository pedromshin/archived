import prisma from '@/lib/prisma'
import { notFound } from 'next/navigation'

export async function POST(req: Request) {
    const body = await req.json()

    const id: string = body.id

    const post = await prisma.propsite.delete({
       where: {
        id
       }
    })

    if (!post) {
        notFound()
    }

    return Response.json(post)
}