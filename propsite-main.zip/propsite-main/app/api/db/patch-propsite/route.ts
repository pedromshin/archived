import prisma from '@/lib/prisma'

export async function PATCH(req: Request) {
    try {
        const data = await req.json()

        const name = await prisma.propsite.findFirst({
            where: {
                name: data.name
            }
        })

        if (name) return Response.json({
            error: 'Name already in use.',
          })
    
        const propsite = await prisma.propsite.update({
            where: {
                id: data.id
            },
            data
        })

        return Response.json(propsite)
    } catch (e) {
        throw e
    }
}