import type { Identifier, XYCoord } from 'dnd-core'

import {  buttonVariants } from '@/app/components/button'
import { cn } from '@/app/utils/cn'
import { useDrag, useDrop } from 'react-dnd'
import { DragItem, ItemTypes, NavLinkProps } from '..'
import { useRef } from 'react'
import { Icon } from '@/app/components/icon';

export function NavLink({
    title,
    icon,
    label,
    href,
    closeNav,
    index,
    moveCard
  }: NavLinkProps) {
    const ref = useRef<HTMLAnchorElement>(null)

    const [{ handlerId }, drop] = useDrop<
        DragItem,
        void,
        { handlerId: Identifier | null }
    >({
        accept: ItemTypes.NavItem,
        collect(monitor) {
            return {
                handlerId: monitor.getHandlerId(),
            }
        },
        hover(item: DragItem, monitor) {
            if (!ref.current) {
                return
            }
            const dragIndex = item.index
            const hoverIndex = index
            if (dragIndex === hoverIndex) {
                return
            }
            const hoverBoundingRect = ref.current?.getBoundingClientRect()
            const hoverMiddleY =
                (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2
            const clientOffset = monitor.getClientOffset()
            const hoverClientY = (clientOffset as XYCoord).y - hoverBoundingRect.top
            if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
                return
            }
            if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
                return
            }
            moveCard(dragIndex, hoverIndex)
            item.index = hoverIndex
        },
    })
  
    const [{ isDragging }, drag] = useDrag({
      type: ItemTypes.NavItem,
      item: () => {
        return { title, index }
      },
      collect: (monitor: any) => ({
        isDragging: monitor.isDragging(),
      }),
    })

    const opacity = isDragging ? 0 : 1
    drag(drop(ref))

    return (
      <a
        style={{ opacity }}
        data-handler-id={handlerId}
        ref={ref}
        href={href}
        onClick={closeNav}
        className={cn(
          buttonVariants({
            variant: 'secondary',
            size: 'sm',
          }),
          'h-12 justify-start text-wrap rounded-none px-6',
        )}
        aria-current={'page'}
      >
        <div className='mr-2'>
          <Icon icon={icon}/>
        </div>
        {title}
        {label && (
          <div className='ml-2 rounded-lg bg-primary px-1 text-[0.625rem] text-primary-foreground'>
            {label}
          </div>
        )}
      </a>
    )
  }
  