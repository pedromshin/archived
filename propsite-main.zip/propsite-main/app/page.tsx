"use client"
import dynamic from 'next/dynamic'
import { useForm } from "react-hook-form";
import { useCallback, useEffect, useRef, useState } from "react";
import useLocalStorage from "./hooks/use-local-storage";
import { IconDeviceLaptop, IconDeviceMobile } from '@tabler/icons-react';
import { Button } from './components/button';

type FormFields = {
    name: string;
    autoRenew: boolean;
    topLevelDomain: string;
    title: string;
    subtitle: string;
    description: string;
    pages: string;
}

function Page() {
    const resizableRef = useRef<HTMLDivElement>(null)
    const [previewWidth, setPreviewWidth] = useState<number>()

    const [propsite, setPropsite] = useLocalStorage<any>({
        key: 'propsite-data',
        defaultValue: localStorage?.getItem('propsite-data')
    })

    const {
        register,
        handleSubmit,
        formState: { errors },
        watch,
        setValue,
        setError,
        clearErrors
    } = useForm<FormFields>({
        defaultValues: propsite
    })

    const previewURL = process.env.NEXT_PUBLIC_URL + (!!watch("name") ? ("/" + watch("name")) : "/preview")

    const onSubmit = () => { }

    const createPropsite = async () => {
        try {
            const propsite = await fetch(`${process.env.NEXT_PUBLIC_URL}/api/db/create-propsite`, { method: "POST" }).then(res => res.json())

            setPropsite(propsite)
        } catch (e) {
            console.log(e)
        }
    }

    const patchPropsite = async () => {
        if (!watch("name").length) return;

        const payload = {
            id: propsite?.id,
            name: watch("name")
        }

        try {
            const result = await fetch(`${process.env.NEXT_PUBLIC_URL}/api/db/patch-propsite`, { method: "PATCH", body: JSON.stringify(payload) }).then(res => res.json())

            if (result.error) {
                setError("name", { message: "Já existe um Propsite com este nome." })
            } else {
                clearErrors("name")
                setPropsite(result)
            }
        } catch (e) {
            console.log(e)
        }
    }

    const handleChange = (e: any) => {
        setValue("name", e.target.value);
        patchPropsite()
    }

    const setPreviewMobileSize = () => {
        setPreviewWidth(375)
    }

    const setPreviewDesktopSize = () => {
        setPreviewWidth(window.innerWidth > 1280 ? 1024 : 780)
    }

    const updatePreviewHeight = useCallback(() => {
        setPreviewWidth(window.innerWidth > 1024 ? 780 : 375)
      }, []);

    useEffect(() => {
        updatePreviewHeight()

        const handleResize = () => {
            updatePreviewHeight()
          };
      
          window.addEventListener('resize', handleResize);
      
          return () => {
            window.removeEventListener('resize', handleResize);
          };
    }, [updatePreviewHeight])

    useEffect(() => {
        if (!!propsite) return;

        createPropsite()
    }, [])

    return (
        <main className={`flex h-full items-center justify-start p-10 gap-10 flex-col lg:flex-row lg:justify-evenly`}>
            <div className="">
                <form onSubmit={handleSubmit(onSubmit)} className="mb-8">
                    <label className="block text-sm font-semibold mb-2">Name:</label>
                    <div className="flex flex-col p-2">
                        <input
                            className="w-full border border-gray-300 rounded py-2 px-3 focus:outline-none focus:border-blue-500"
                            {...register("name", { required: true })}
                            onChange={handleChange}
                        />
                        {errors.name && <span className="text-red-500 text-sm">{errors.name.message}</span>}
                    </div>
                </form>
            </div>
            <div className="relative gap-2 flex flex-col items-center w-full h-full">
                <div className='flex flex-row justify-center gap-4'>
                    <Button onClick={setPreviewMobileSize} ><IconDeviceMobile /></Button>
                    <Button onClick={setPreviewDesktopSize} ><IconDeviceLaptop /></Button>
                </div>
                {!!watch("name") && <a className={`my-2 text-center`} href={previewURL} target="_blank" suppressHydrationWarning>{previewURL}</a>}
                <div className={`border-2 border-black w-full h-full`} style={{ maxWidth: previewWidth + 'px' }}>
                    <div ref={resizableRef} className={`box w-full h-full`}>
                        <iframe src={previewURL} className={`h-full w-full`}/>
                    </div>
                </div>
            </div>
        </main>
    )
}

export default dynamic(() => Promise.resolve(Page), { ssr: false })