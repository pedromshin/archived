import { Octokit } from "octokit";

export const githubClient = new Octokit({
    auth: process.env.GH_TOKEN
})