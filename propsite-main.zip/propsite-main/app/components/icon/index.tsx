import * as TablerIcons from '@tabler/icons-react';

export type IconType = keyof typeof TablerIcons 

export const Icon = ( { icon }: {icon: IconType}) => {
    const Component = (TablerIcons as any)[icon]

    return <Component />
}