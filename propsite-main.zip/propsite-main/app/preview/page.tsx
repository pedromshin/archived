"use client"
import { Suspense} from "react"
import Preview1 from "../templates/1"

  export default function Page() {
    return (
      <Suspense>
        <Preview1 />
      </Suspense>
    )
  }