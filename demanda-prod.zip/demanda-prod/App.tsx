import React from 'react';

import { Amplify } from 'aws-amplify';
import awsconfig from './src/aws-exports';
import Signin from './src/screens/Signin/Signin';
import Signup from './src/screens/Signup/Singup';
import Home from './src/screens/Home/Home';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Verify from './src/screens/Verify/Verify';

const Stack = createNativeStackNavigator();
Amplify.configure(awsconfig);

function App() {
	return (
		<NavigationContainer>
			<Stack.Navigator initialRouteName='Signin'>
				<Stack.Screen name="Signin" component={Signin} />
				<Stack.Screen name="Signup" component={Signup} />
				<Stack.Screen name="Verify" component={Verify} />
				<Stack.Screen name="Home" component={Home} />
			</Stack.Navigator>
		</NavigationContainer>
	);
}

export default App;
