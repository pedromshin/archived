/* tslint:disable */
/* eslint-disable */
//  This file was automatically generated and should not be edited.

export type CreateBasicTestInput = {
  id?: string | null,
  NameTest?: string | null,
  DescriptionTest?: string | null,
  _version?: number | null,
};

export type ModelBasicTestConditionInput = {
  NameTest?: ModelStringInput | null,
  DescriptionTest?: ModelStringInput | null,
  and?: Array< ModelBasicTestConditionInput | null > | null,
  or?: Array< ModelBasicTestConditionInput | null > | null,
  not?: ModelBasicTestConditionInput | null,
};

export type ModelStringInput = {
  ne?: string | null,
  eq?: string | null,
  le?: string | null,
  lt?: string | null,
  ge?: string | null,
  gt?: string | null,
  contains?: string | null,
  notContains?: string | null,
  between?: Array< string | null > | null,
  beginsWith?: string | null,
  attributeExists?: boolean | null,
  attributeType?: ModelAttributeTypes | null,
  size?: ModelSizeInput | null,
};

export enum ModelAttributeTypes {
  binary = "binary",
  binarySet = "binarySet",
  bool = "bool",
  list = "list",
  map = "map",
  number = "number",
  numberSet = "numberSet",
  string = "string",
  stringSet = "stringSet",
  _null = "_null",
}


export type ModelSizeInput = {
  ne?: number | null,
  eq?: number | null,
  le?: number | null,
  lt?: number | null,
  ge?: number | null,
  gt?: number | null,
  between?: Array< number | null > | null,
};

export type BasicTest = {
  __typename: "BasicTest",
  id: string,
  NameTest?: string | null,
  DescriptionTest?: string | null,
  createdAt: string,
  updatedAt: string,
  _version: number,
  _deleted?: boolean | null,
  _lastChangedAt: number,
};

export type UpdateBasicTestInput = {
  id: string,
  NameTest?: string | null,
  DescriptionTest?: string | null,
  _version?: number | null,
};

export type DeleteBasicTestInput = {
  id: string,
  _version?: number | null,
};

export type ModelBasicTestFilterInput = {
  id?: ModelIDInput | null,
  NameTest?: ModelStringInput | null,
  DescriptionTest?: ModelStringInput | null,
  and?: Array< ModelBasicTestFilterInput | null > | null,
  or?: Array< ModelBasicTestFilterInput | null > | null,
  not?: ModelBasicTestFilterInput | null,
};

export type ModelIDInput = {
  ne?: string | null,
  eq?: string | null,
  le?: string | null,
  lt?: string | null,
  ge?: string | null,
  gt?: string | null,
  contains?: string | null,
  notContains?: string | null,
  between?: Array< string | null > | null,
  beginsWith?: string | null,
  attributeExists?: boolean | null,
  attributeType?: ModelAttributeTypes | null,
  size?: ModelSizeInput | null,
};

export type ModelBasicTestConnection = {
  __typename: "ModelBasicTestConnection",
  items:  Array<BasicTest | null >,
  nextToken?: string | null,
  startedAt?: number | null,
};

export type CreateBasicTestMutationVariables = {
  input: CreateBasicTestInput,
  condition?: ModelBasicTestConditionInput | null,
};

export type CreateBasicTestMutation = {
  createBasicTest?:  {
    __typename: "BasicTest",
    id: string,
    NameTest?: string | null,
    DescriptionTest?: string | null,
    createdAt: string,
    updatedAt: string,
    _version: number,
    _deleted?: boolean | null,
    _lastChangedAt: number,
  } | null,
};

export type UpdateBasicTestMutationVariables = {
  input: UpdateBasicTestInput,
  condition?: ModelBasicTestConditionInput | null,
};

export type UpdateBasicTestMutation = {
  updateBasicTest?:  {
    __typename: "BasicTest",
    id: string,
    NameTest?: string | null,
    DescriptionTest?: string | null,
    createdAt: string,
    updatedAt: string,
    _version: number,
    _deleted?: boolean | null,
    _lastChangedAt: number,
  } | null,
};

export type DeleteBasicTestMutationVariables = {
  input: DeleteBasicTestInput,
  condition?: ModelBasicTestConditionInput | null,
};

export type DeleteBasicTestMutation = {
  deleteBasicTest?:  {
    __typename: "BasicTest",
    id: string,
    NameTest?: string | null,
    DescriptionTest?: string | null,
    createdAt: string,
    updatedAt: string,
    _version: number,
    _deleted?: boolean | null,
    _lastChangedAt: number,
  } | null,
};

export type GetBasicTestQueryVariables = {
  id: string,
};

export type GetBasicTestQuery = {
  getBasicTest?:  {
    __typename: "BasicTest",
    id: string,
    NameTest?: string | null,
    DescriptionTest?: string | null,
    createdAt: string,
    updatedAt: string,
    _version: number,
    _deleted?: boolean | null,
    _lastChangedAt: number,
  } | null,
};

export type ListBasicTestsQueryVariables = {
  filter?: ModelBasicTestFilterInput | null,
  limit?: number | null,
  nextToken?: string | null,
};

export type ListBasicTestsQuery = {
  listBasicTests?:  {
    __typename: "ModelBasicTestConnection",
    items:  Array< {
      __typename: "BasicTest",
      id: string,
      NameTest?: string | null,
      DescriptionTest?: string | null,
      createdAt: string,
      updatedAt: string,
      _version: number,
      _deleted?: boolean | null,
      _lastChangedAt: number,
    } | null >,
    nextToken?: string | null,
    startedAt?: number | null,
  } | null,
};

export type SyncBasicTestsQueryVariables = {
  filter?: ModelBasicTestFilterInput | null,
  limit?: number | null,
  nextToken?: string | null,
  lastSync?: number | null,
};

export type SyncBasicTestsQuery = {
  syncBasicTests?:  {
    __typename: "ModelBasicTestConnection",
    items:  Array< {
      __typename: "BasicTest",
      id: string,
      NameTest?: string | null,
      DescriptionTest?: string | null,
      createdAt: string,
      updatedAt: string,
      _version: number,
      _deleted?: boolean | null,
      _lastChangedAt: number,
    } | null >,
    nextToken?: string | null,
    startedAt?: number | null,
  } | null,
};

export type OnCreateBasicTestSubscription = {
  onCreateBasicTest?:  {
    __typename: "BasicTest",
    id: string,
    NameTest?: string | null,
    DescriptionTest?: string | null,
    createdAt: string,
    updatedAt: string,
    _version: number,
    _deleted?: boolean | null,
    _lastChangedAt: number,
  } | null,
};

export type OnUpdateBasicTestSubscription = {
  onUpdateBasicTest?:  {
    __typename: "BasicTest",
    id: string,
    NameTest?: string | null,
    DescriptionTest?: string | null,
    createdAt: string,
    updatedAt: string,
    _version: number,
    _deleted?: boolean | null,
    _lastChangedAt: number,
  } | null,
};

export type OnDeleteBasicTestSubscription = {
  onDeleteBasicTest?:  {
    __typename: "BasicTest",
    id: string,
    NameTest?: string | null,
    DescriptionTest?: string | null,
    createdAt: string,
    updatedAt: string,
    _version: number,
    _deleted?: boolean | null,
    _lastChangedAt: number,
  } | null,
};
