import { ModelInit, MutableModel, PersistentModelConstructor } from "@aws-amplify/datastore";





type BasicTestMetaData = {
  readOnlyFields: 'createdAt' | 'updatedAt';
}

export declare class BasicTest {
  readonly id: string;
  readonly NameTest?: string | null;
  readonly DescriptionTest?: string | null;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
  constructor(init: ModelInit<BasicTest, BasicTestMetaData>);
  static copyOf(source: BasicTest, mutator: (draft: MutableModel<BasicTest, BasicTestMetaData>) => MutableModel<BasicTest, BasicTestMetaData> | void): BasicTest;
}