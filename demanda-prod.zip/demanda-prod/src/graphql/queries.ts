/* tslint:disable */
/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const getBasicTest = /* GraphQL */ `
  query GetBasicTest($id: ID!) {
    getBasicTest(id: $id) {
      id
      NameTest
      DescriptionTest
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
export const listBasicTests = /* GraphQL */ `
  query ListBasicTests(
    $filter: ModelBasicTestFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listBasicTests(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        NameTest
        DescriptionTest
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
export const syncBasicTests = /* GraphQL */ `
  query SyncBasicTests(
    $filter: ModelBasicTestFilterInput
    $limit: Int
    $nextToken: String
    $lastSync: AWSTimestamp
  ) {
    syncBasicTests(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      lastSync: $lastSync
    ) {
      items {
        id
        NameTest
        DescriptionTest
        createdAt
        updatedAt
        _version
        _deleted
        _lastChangedAt
      }
      nextToken
      startedAt
    }
  }
`;
