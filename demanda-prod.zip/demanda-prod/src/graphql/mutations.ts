/* tslint:disable */
/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const createBasicTest = /* GraphQL */ `
  mutation CreateBasicTest(
    $input: CreateBasicTestInput!
    $condition: ModelBasicTestConditionInput
  ) {
    createBasicTest(input: $input, condition: $condition) {
      id
      NameTest
      DescriptionTest
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
export const updateBasicTest = /* GraphQL */ `
  mutation UpdateBasicTest(
    $input: UpdateBasicTestInput!
    $condition: ModelBasicTestConditionInput
  ) {
    updateBasicTest(input: $input, condition: $condition) {
      id
      NameTest
      DescriptionTest
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
export const deleteBasicTest = /* GraphQL */ `
  mutation DeleteBasicTest(
    $input: DeleteBasicTestInput!
    $condition: ModelBasicTestConditionInput
  ) {
    deleteBasicTest(input: $input, condition: $condition) {
      id
      NameTest
      DescriptionTest
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
