/* tslint:disable */
/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateBasicTest = /* GraphQL */ `
  subscription OnCreateBasicTest {
    onCreateBasicTest {
      id
      NameTest
      DescriptionTest
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
export const onUpdateBasicTest = /* GraphQL */ `
  subscription OnUpdateBasicTest {
    onUpdateBasicTest {
      id
      NameTest
      DescriptionTest
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
export const onDeleteBasicTest = /* GraphQL */ `
  subscription OnDeleteBasicTest {
    onDeleteBasicTest {
      id
      NameTest
      DescriptionTest
      createdAt
      updatedAt
      _version
      _deleted
      _lastChangedAt
    }
  }
`;
