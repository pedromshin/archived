import React from 'react';
import { View, TextInput, Button, Alert } from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import styles from './styles';

import { Auth } from '@aws-amplify/auth';

export default function Signup({ navigation }: any) {
	const { control, handleSubmit, formState: { errors } } = useForm({
		defaultValues: {
			email: '',
			OTP: '',
		}
	});

	const verifyOTP = async (data: any) => {
		try {
			const res = await Auth.confirmSignUp((await Auth.currentCredentials()).identityId, data.OTP);
			console.log(res);
		} catch (error: any) {
			Alert.alert('Error', error.message);
		}
	};

	return (
		<View style={styles.container}>
			<Controller
				control={control}
				render={({ field: { onChange, onBlur, value } }) => (
					<TextInput
						onBlur={onBlur}
						onChangeText={onChange}
						value={value}
						placeholder="OTP"
					/>
				)}
				name="OTP"
			/>
			<Button title="Verificar senha temporária" onPress={handleSubmit(verifyOTP)} />
			<Button
				title="Voltar"
				onPress={() => navigation.navigate('Signup')}
			/>
		</View>
	);
}