import React from 'react';
import { Text, View, TextInput, Button, Alert } from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import styles from './styles';

import { Auth } from '@aws-amplify/auth';

export default function Signin( { navigation }: any) {
	const { control, handleSubmit, formState: { errors } } = useForm({
		defaultValues: {
			email: '',
			password: ''
		}
	});

	const onSubmit = async (data: any) => {
		try {
			const res = await Auth.signIn(data.email, data.password);
			console.log('Signin response', res);
			if (res) {
				navigation.navigate('Home');
			}
		} catch (error: any) {
			console.log(error);
		}
	};

	return (
		<View style={styles.container}>
			<Controller
				control={control}
				rules={{
					required: true,
				}}
				render={({ field: { onChange, onBlur, value } }) => (
					<TextInput
						onBlur={onBlur}
						onChangeText={onChange}
						value={value}
						placeholder="E-mail"
					/>
				)}
				name="email"
			/>
			{errors.email && <Text>Insira um e-mail válido</Text>}

			<Controller
				control={control}
				rules={{
					maxLength: 100,
				}}
				render={({ field: { onChange, onBlur, value } }) => (
					<TextInput
						onBlur={onBlur}
						onChangeText={onChange}
						value={value}
						placeholder="Senha"
						secureTextEntry
					/>
				)}
				name="password"
			/>
			{errors.password && <Text>Senha inválida</Text>}


			<Button title="Login" onPress={handleSubmit(onSubmit)} />

			<Button
				title="Criar uma conta"
				onPress={() => navigation.navigate('Signup')}
			/>
		</View>
	);
}