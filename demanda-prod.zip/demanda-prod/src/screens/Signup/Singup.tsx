import React from 'react';
import { Text, View, TextInput, Button, Alert } from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import styles from './styles';

import { Auth } from '@aws-amplify/auth';

export default function Signup({ navigation }: any) {
	const { control, handleSubmit, formState: { errors } } = useForm({
		defaultValues: {
			email: '',
			password: '',
		}
	});

	const sendOTP = async (data: any) => {
		try {
			await Auth.signUp({
				username: data.email,
				password: data.password,
			});
			navigation.navigate('Verify');
		} catch (error: any) {
			Alert.alert('Error', error.message);
		}
	};

	return (
		<View style={styles.container}>
			<Controller
				control={control}
				rules={{
					required: true,
				}}
				render={({ field: { onChange, onBlur, value } }) => (
					<TextInput
						onBlur={onBlur}
						onChangeText={onChange}
						value={value}
						placeholder="E-mail"
					/>
				)}
				name="email"
			/>
			{errors.email && <Text>Insira um e-mail válido</Text>}

			<Controller
				control={control}
				rules={{
					required: true,
				}}
				render={({ field: { onChange, onBlur, value } }) => (
					<TextInput
						onBlur={onBlur}
						onChangeText={onChange}
						value={value}
						placeholder="Senha"
						secureTextEntry
					/>
				)}
				name="password"
			/>
			{errors.password && <Text>Senha inválida</Text>}

			<Button title="Enviar OTP" onPress={handleSubmit(sendOTP)} />
			<Button
				title="Voltar"
				onPress={() => navigation.navigate('Signin')}
			/>
		</View>
	);
}