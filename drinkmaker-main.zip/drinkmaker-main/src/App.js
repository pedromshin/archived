import React, { useState, useEffect } from "react";
import "./App.css";
import DrinkTable from "./DrinkTable";
import DrinkForm from "./DrinkForm";
import DrinkSearch from "./DrinkSearch";

function App() {
  const [data, setData] = useState([]);
  const [searchId, setSearchId] = useState("");

  const endpoint =
    process.env.REACT_APP_ENV_VAR === "production"
      ? process.env.REACT_APP_ENDPOINT_PRODUCTION
      : process.env.REACT_APP_ENV_VAR === "preview"
      ? process.env.REACT_APP_ENDPOINT_STAGING
      : process.env.REACT_APP_ENDPOINT_LOCAL;

  const fetchData = async (id = "") => {
    const url = id ? `${endpoint}/drink/${id}` : `${endpoint}/drink`;

    try {
      const response = await fetch(url, {
        method: "GET",
      });
      const result = await response.json();
      setData(Array.isArray(result) ? result : [result]);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleSearch = (id) => {
    setSearchId(id);
    fetchData(id);
  };

  const handleDelete = async (id) => {
    const url = `${endpoint}/drink/${id}`;
    try {
      await fetch(url, {
        method: "DELETE",
      });
      fetchData();
    } catch (error) {
      console.error("Error deleting data:", error);
    }
  };

  useEffect(() => {
    fetchData();
  }, [endpoint]);

  return (
    <div className="App">
      <DrinkSearch onSearch={handleSearch} />
      <DrinkTable data={data} onDelete={handleDelete} />
      <DrinkForm onFormSubmit={fetchData} />
    </div>
  );
}

export default App;
